import basePlayer from "./basePlayer";
import actionData from "./actionData";
export default class actionItem
{
    public _CurrentItem:basePlayer;
    constructor() {
        
    }
    public endBack:Function;
    public init(data:actionData):void{
        this._CurrentItem = new basePlayer();
        this._CurrentItem.init(data);
    }
    public enter(endback:Function):void{
        this.endBack = endback;
        this.Execute();
    }
    public Execute():void{
        let that = this;
        this._CurrentItem.play(function(){that.end()});
    }
    public end():void{
        this.endBack();
    }
}