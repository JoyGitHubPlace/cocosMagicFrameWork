export default class actionData {
    public name: string;
    public TNum: number;
}