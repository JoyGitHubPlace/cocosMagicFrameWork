export default class handler{
    public static create(obj:any,func:Function):any{
        return {
            this:obj,
            runwith:func,
        }
    }
    
}