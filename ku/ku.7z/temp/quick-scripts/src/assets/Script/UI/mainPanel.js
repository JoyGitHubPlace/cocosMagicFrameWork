"use strict";
cc._RF.push(module, '4de08/dikdBAJzlopZJzXlK', 'mainPanel');
// Script/UI/mainPanel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var configManager_1 = require("../configManager");
var poolManager_1 = require("../Manager/poolManager");
var Global_1 = require("../Manager/Global");
var levelItem = /** @class */ (function () {
    function levelItem() {
    }
    return levelItem;
}());
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var mainPanel = /** @class */ (function (_super) {
    __extends(mainPanel, _super);
    function mainPanel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.prefabs = [];
        _this.px = 0;
        return _this;
        // update (dt) {}
    }
    mainPanel.prototype.OnItemRender = function (item, idx) {
        console.log("idx", idx);
        if (configManager_1.default.instance["level"] != null) {
            var jsondata = configManager_1.default.instance["level"];
            console.log(jsondata[idx]);
            var testitem = item.getComponent("testItem");
            testitem.init(jsondata[idx]);
        }
    };
    mainPanel.prototype.addnode = function () {
        var that = this;
        if (that.prefabs != null) {
            var node = poolManager_1.default.instance.getNode("goldPrefab");
            node.parent = that.node;
            node.setPosition(this.px, 0, 0);
            this.px += 50;
        }
    };
    mainPanel.prototype._destroyEvent = function (data) {
        console.log("event:", data);
        Global_1.default.instance.off("destory", this._destroyEvent, this);
    };
    mainPanel.prototype.start = function () {
        var that = this;
        window["main"] = this;
        configManager_1.default.instance.load(function () {
            if (that.levelView != null) {
                if (configManager_1.default.instance["level"] != null) {
                    var jsondata = configManager_1.default.instance["level"];
                    var lon = jsondata.length;
                    that.levelViewList = that.levelView.getComponent("List");
                    that.levelViewList.numItems = lon;
                    that.levelViewList.updateAll();
                }
            }
        });
        /*if(configManager.instance["action"]!=null){
                actionManager.instance.init(configManager.instance["action"]);
                actionManager.instance.runActionlist();
            }*/
        poolManager_1.default.instance.init(that.prefabs);
        Global_1.default.instance.init();
        Global_1.default.instance.on("destory", this._destroyEvent, this);
    };
    __decorate([
        property({ type: cc.Node, displayName: "levelView" })
    ], mainPanel.prototype, "levelView", void 0);
    __decorate([
        property({ type: [cc.Prefab], displayName: "prefabs" })
    ], mainPanel.prototype, "prefabs", void 0);
    mainPanel = __decorate([
        ccclass
    ], mainPanel);
    return mainPanel;
}(cc.Component));
exports.default = mainPanel;

cc._RF.pop();