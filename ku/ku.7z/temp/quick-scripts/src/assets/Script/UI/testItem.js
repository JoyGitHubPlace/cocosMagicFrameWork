"use strict";
cc._RF.push(module, 'f9621lj7jZJnqLtikcEjQkj', 'testItem');
// Script/UI/testItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Global_1 = require("../Manager/Global");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var testitem = /** @class */ (function (_super) {
    __extends(testitem, _super);
    function testitem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.levelItemObj = null;
        return _this;
        // update (dt) {}
    }
    testitem.prototype.start = function () {
        this.btn_icon.node.on('click', this.levelItem, this);
    };
    testitem.prototype.init = function (data) {
        this._itemdata = data;
        this.levelItemObj.setPosition(data.posX, data.posY, 0);
    };
    testitem.prototype.levelItem = function () {
        console.log(this._itemdata.name);
        Global_1.default.instance.event("destory", "123");
    };
    __decorate([
        property({ type: cc.Node, displayName: "levelItemObj" })
    ], testitem.prototype, "levelItemObj", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "levelItemObj" })
    ], testitem.prototype, "btn_icon", void 0);
    testitem = __decorate([
        ccclass
    ], testitem);
    return testitem;
}(cc.Component));
exports.default = testitem;

cc._RF.pop();