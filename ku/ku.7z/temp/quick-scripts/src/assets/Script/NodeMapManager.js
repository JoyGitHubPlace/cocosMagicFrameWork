"use strict";
cc._RF.push(module, '5d029CRkJxPm65zu/TmhepX', 'NodeMapManager');
// Script/NodeMapManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NodeMapManager = /** @class */ (function (_super) {
    __extends(NodeMapManager, _super);
    function NodeMapManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.text = 'hello';
        // LIFE-CYCLE CALLBACKS:
        _this.nodePrefab = null;
        _this.parentNode = null;
        return _this;
        // update (dt) {}
    }
    NodeMapManager.prototype.start = function () {
        var node = cc.instantiate(this.nodePrefab);
        node.position = new cc.Vec3(0, 0, 0);
        node.parent = this.parentNode;
        var item = node.getComponent("NodeItem");
        item.text = "nodetest";
    };
    __decorate([
        property
    ], NodeMapManager.prototype, "text", void 0);
    __decorate([
        property({ type: cc.Prefab, displayName: "预制体" })
    ], NodeMapManager.prototype, "nodePrefab", void 0);
    __decorate([
        property({ type: cc.Node, displayName: "父物体" })
    ], NodeMapManager.prototype, "parentNode", void 0);
    NodeMapManager = __decorate([
        ccclass
    ], NodeMapManager);
    return NodeMapManager;
}(cc.Component));
exports.default = NodeMapManager;

cc._RF.pop();