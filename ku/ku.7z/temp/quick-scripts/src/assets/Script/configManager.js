"use strict";
cc._RF.push(module, 'cff79PEXYZE7bSATJdY9Bq+', 'configManager');
// Script/configManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PClass = /** @class */ (function () {
    function PClass() {
    }
    return PClass;
}());
;
var leveldata = /** @class */ (function () {
    function leveldata() {
    }
    return leveldata;
}());
var configManager = /** @class */ (function () {
    function configManager(pc) {
    }
    Object.defineProperty(configManager, "instance", {
        get: function () {
            if (!configManager._instance) {
                configManager._instance = new configManager(new PClass());
            }
            return configManager._instance;
        },
        enumerable: true,
        configurable: true
    });
    configManager.prototype.load = function (callback) {
        this.loadConfigReses(function () { window["aa"] = configManager._instance; callback(); });
    };
    configManager.prototype.loadConfigReses = function (successFun) {
        if (successFun === void 0) { successFun = function () { }; }
        var that = this;
        cc.loader.loadResDir("GameData", function (err, jsons, urls) {
            if (err) {
                cc.error(err.message || err);
                return;
            }
            for (var i = 0; i < jsons.length; ++i) {
                var jsonAsset = jsons[i];
                var url = urls[i];
                var name = url.split("/")[1];
                that[name] = jsonAsset.json;
            }
            successFun();
        });
    };
    return configManager;
}());
exports.default = configManager;

cc._RF.pop();