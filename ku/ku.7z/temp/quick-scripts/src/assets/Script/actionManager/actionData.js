"use strict";
cc._RF.push(module, '130b6irvXFALrvLjQgQjVdW', 'actionData');
// Script/actionManager/actionData.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var actionData = /** @class */ (function () {
    function actionData() {
    }
    return actionData;
}());
exports.default = actionData;

cc._RF.pop();