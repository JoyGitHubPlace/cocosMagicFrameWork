"use strict";
cc._RF.push(module, '588aeDXjW9NVJZbAUQqF+bh', 'actionManager');
// Script/actionManager/actionManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var actionItem_1 = require("./actionItem");
var handler_1 = require("./handler");
var actionManager = /** @class */ (function () {
    function actionManager() {
        this._curIndex = 0;
    }
    Object.defineProperty(actionManager, "instance", {
        get: function () {
            if (!actionManager._instance) {
                actionManager._instance = new actionManager();
            }
            return actionManager._instance;
        },
        enumerable: true,
        configurable: true
    });
    actionManager.prototype.init = function (data) {
        var lon = data.length;
        for (var i = 0; i < lon; i++) {
            if (i == 0) {
                this._NextAction = new actionItem_1.default();
                this._NextAction.init(data[i]);
            }
        }
        this._actionDataList = data;
    };
    actionManager.prototype.moveNext = function () {
        this._curIndex++;
        this.runActionlist();
    };
    actionManager.prototype.runActionlist = function () {
        var that = this;
        var lon = this._actionDataList.length;
        if (this._NextAction != null) {
            this._currentAction = this._NextAction;
            this._currentAction.enter(handler_1.default.create(that, that.moveNext));
        }
        else {
            return;
        }
        if (this._curIndex + 1 < lon) {
            var action = new actionItem_1.default();
            action.init(this._actionDataList[this._curIndex + 1]);
            this._NextAction = action;
        }
        else {
            this._NextAction = null;
        }
    };
    return actionManager;
}());
exports.default = actionManager;

cc._RF.pop();