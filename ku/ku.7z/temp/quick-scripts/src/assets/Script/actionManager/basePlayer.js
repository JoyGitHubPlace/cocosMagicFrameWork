"use strict";
cc._RF.push(module, '01d5fXdUfVC9ZGobfQohaXF', 'basePlayer');
// Script/actionManager/basePlayer.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var basePlayer = /** @class */ (function () {
    function basePlayer() {
    }
    basePlayer.prototype.init = function (data) {
        this.name = data.name;
        this.tnum = data.TNum;
    };
    basePlayer.prototype.play = function (callback) {
        var that = this;
        setTimeout(function () {
            console.log(that.name);
            callback();
        }, this.tnum);
    };
    basePlayer.prototype.destroy = function () {
    };
    return basePlayer;
}());
exports.default = basePlayer;

cc._RF.pop();