"use strict";
cc._RF.push(module, '06e09asUUxFCrzI9rM5H8Ma', 'handler');
// Script/actionManager/handler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var handler = /** @class */ (function () {
    function handler() {
    }
    handler.create = function (obj, func) {
        return {
            this: obj,
            runwith: func,
        };
    };
    return handler;
}());
exports.default = handler;

cc._RF.pop();