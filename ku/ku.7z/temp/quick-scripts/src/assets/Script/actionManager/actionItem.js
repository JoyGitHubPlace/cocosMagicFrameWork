"use strict";
cc._RF.push(module, '3d385irLTBEoJgK9VgTecoN', 'actionItem');
// Script/actionManager/actionItem.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var basePlayer_1 = require("./basePlayer");
var actionItem = /** @class */ (function () {
    function actionItem() {
    }
    actionItem.prototype.init = function (data) {
        this._CurrentItem = new basePlayer_1.default();
        this._CurrentItem.init(data);
    };
    actionItem.prototype.enter = function (endback) {
        this.endBack = endback;
        this.Execute();
    };
    actionItem.prototype.Execute = function () {
        var that = this;
        this._CurrentItem.play(function () { that.end(); });
    };
    actionItem.prototype.end = function () {
        this.endBack();
    };
    return actionItem;
}());
exports.default = actionItem;

cc._RF.pop();