"use strict";
cc._RF.push(module, '462d3puY3lC74e8bV91PuGR', 'EventSetting');
// Script/Event/EventSetting.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventMode;
(function (EventMode) {
    var EventSetting = /** @class */ (function () {
        function EventSetting() {
            this._initNum = 1;
            this._initString = "abc";
            console.log(this._initString);
        }
        return EventSetting;
    }());
    EventMode.EventSetting = EventSetting;
})(EventMode = exports.EventMode || (exports.EventMode = {}));

cc._RF.pop();