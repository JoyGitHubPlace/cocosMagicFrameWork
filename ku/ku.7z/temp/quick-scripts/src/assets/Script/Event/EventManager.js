"use strict";
cc._RF.push(module, 'e2663it5KxEiIS1NkuB1rVI', 'EventManager');
// Script/Event/EventManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventMode;
(function (EventMode) {
    var EventManager = /** @class */ (function () {
        function EventManager() {
            this._initNum = 1;
            this._initString = "123";
            console.log(this._initNum);
        }
        return EventManager;
    }());
    EventMode.EventManager = EventManager;
})(EventMode = exports.EventMode || (exports.EventMode = {}));

cc._RF.pop();