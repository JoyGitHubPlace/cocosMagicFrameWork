"use strict";
cc._RF.push(module, 'fc7a2OfEOFOxaOl9GJtTwuy', 'nodePool');
// Script/Manager/nodePool.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var nodePool = /** @class */ (function () {
    function nodePool() {
        /**
         * author by Joy
         * object pool
         */
        this._pool = [];
    }
    nodePool.prototype.size = function () {
        return this._pool.length;
    };
    nodePool.prototype.clear = function () {
        var count = this._pool.length;
        for (var i = 0; i < count; ++i) {
            this._pool[i].destroy();
        }
        this._pool.length = 0;
    };
    nodePool.prototype.put = function (obj) {
        if (obj && this._pool.indexOf(obj) === -1) {
            obj.removeFromParent(false);
        }
        this._pool.push(obj);
    };
    nodePool.prototype.get = function () {
        var last = this._pool.length - 1;
        if (last < 0) {
            return null;
        }
        else {
            var obj = this._pool[last];
            this._pool[last] = null;
            this._pool.length = last;
            return obj;
        }
    };
    return nodePool;
}());
exports.default = nodePool;

cc._RF.pop();