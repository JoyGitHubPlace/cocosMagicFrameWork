"use strict";
cc._RF.push(module, 'e18adlTid9KRpWDckSQ1mh3', 'Global');
// Script/Manager/Global.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Global = /** @class */ (function () {
    function Global() {
    }
    Object.defineProperty(Global, "instance", {
        get: function () {
            if (!Global._instance) {
                Global._instance = new Global();
            }
            return Global._instance;
        },
        enumerable: true,
        configurable: true
    });
    Global.prototype._initEventCenter = function () {
        this.EventCenter = this.EventCenter || new cc.EventTarget();
    };
    Global.prototype.init = function () {
        this._initEventCenter();
    };
    Global.prototype.on = function (eventName, callback, target) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.on(eventName, callback, target);
    };
    Global.prototype.off = function (eventName, callback, target) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.off(eventName, callback, target);
    };
    Global.prototype.once = function (eventName, callback, target) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.once(eventName, callback, target);
    };
    Global.prototype.event = function (eventName, data) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.emit(eventName, data);
    };
    return Global;
}());
exports.default = Global;

cc._RF.pop();