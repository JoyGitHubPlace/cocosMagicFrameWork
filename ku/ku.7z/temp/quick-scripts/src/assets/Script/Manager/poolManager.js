"use strict";
cc._RF.push(module, '6abd5/qKWJGdoRCGiPbdPn9', 'poolManager');
// Script/Manager/poolManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var nodePool_1 = require("./nodePool");
var poolManager = /** @class */ (function () {
    function poolManager() {
        this._poolItems = [];
        this._nodesPool = [];
        this._maxSize = 0;
    }
    Object.defineProperty(poolManager, "instance", {
        get: function () {
            if (!poolManager._instance) {
                poolManager._instance = new poolManager();
            }
            return poolManager._instance;
        },
        enumerable: true,
        configurable: true
    });
    poolManager.prototype.init = function (prefabs, max) {
        var _this = this;
        if (max === void 0) { max = 3; }
        this._maxSize = max;
        prefabs.forEach(function (element) {
            _this._poolItems[element.name] = element;
            var np = new nodePool_1.default();
            _this._nodesPool[element.name] = np;
            _this.genNode(element.name, max);
        });
    };
    poolManager.prototype.genNode = function (type, num) {
        for (var i = 0; i < num; ++i) {
            var prefab = this._poolItems[type];
            var node = cc.instantiate(prefab);
            node.active = false;
            this._nodesPool[type].put(node);
        }
    };
    poolManager.prototype.getNode = function (type) {
        var node = null;
        var size = this._nodesPool[type].size();
        if (size > 0) {
            node = this._nodesPool[type].get();
        }
        else {
            node = cc.instantiate(this._poolItems[type]);
        }
        node.name = type;
        node.active = true;
        return node;
    };
    poolManager.prototype.putNode = function (node) {
        node.active = false;
        if (node.name == null) {
            return;
        }
        if (this._nodesPool[node.name].size() + 1 > this._maxSize) {
            node = null;
        }
        else {
            this._nodesPool[node.name].put(node);
        }
    };
    poolManager.prototype.clearAllNode = function (type) {
        this._nodesPool[type].clear();
    };
    return poolManager;
}());
exports.default = poolManager;

cc._RF.pop();