
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/actionManager/actionManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '588aeDXjW9NVJZbAUQqF+bh', 'actionManager');
// Script/actionManager/actionManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var actionItem_1 = require("./actionItem");
var handler_1 = require("./handler");
var actionManager = /** @class */ (function () {
    function actionManager() {
        this._curIndex = 0;
    }
    Object.defineProperty(actionManager, "instance", {
        get: function () {
            if (!actionManager._instance) {
                actionManager._instance = new actionManager();
            }
            return actionManager._instance;
        },
        enumerable: true,
        configurable: true
    });
    actionManager.prototype.init = function (data) {
        var lon = data.length;
        for (var i = 0; i < lon; i++) {
            if (i == 0) {
                this._NextAction = new actionItem_1.default();
                this._NextAction.init(data[i]);
            }
        }
        this._actionDataList = data;
    };
    actionManager.prototype.moveNext = function () {
        this._curIndex++;
        this.runActionlist();
    };
    actionManager.prototype.runActionlist = function () {
        var that = this;
        var lon = this._actionDataList.length;
        if (this._NextAction != null) {
            this._currentAction = this._NextAction;
            this._currentAction.enter(handler_1.default.create(that, that.moveNext));
        }
        else {
            return;
        }
        if (this._curIndex + 1 < lon) {
            var action = new actionItem_1.default();
            action.init(this._actionDataList[this._curIndex + 1]);
            this._NextAction = action;
        }
        else {
            this._NextAction = null;
        }
    };
    return actionManager;
}());
exports.default = actionManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxhY3Rpb25NYW5hZ2VyXFxhY3Rpb25NYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsMkNBQXNDO0FBRXRDLHFDQUFnQztBQUNoQztJQVdJO1FBUFEsY0FBUyxHQUFHLENBQUMsQ0FBQztJQVN0QixDQUFDO0lBUkQsc0JBQWtCLHlCQUFRO2FBQTFCO1lBQ0ksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUU7Z0JBQzFCLGFBQWEsQ0FBQyxTQUFTLEdBQUcsSUFBSSxhQUFhLEVBQUUsQ0FBQzthQUNqRDtZQUNELE9BQU8sYUFBYSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxDQUFDOzs7T0FBQTtJQVNNLDRCQUFJLEdBQVgsVUFBWSxJQUFnQjtRQUN4QixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3RCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNSLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxvQkFBVSxFQUFFLENBQUM7Z0JBQ3BDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2xDO1NBRUo7UUFDRCxJQUFJLENBQUMsZUFBZSxHQUFDLElBQUksQ0FBQztJQUU5QixDQUFDO0lBQ08sZ0NBQVEsR0FBaEI7UUFDSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFDTSxxQ0FBYSxHQUFwQjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQztRQUN0QyxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxFQUFFO1lBQzFCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUN2QyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxpQkFBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDakU7YUFBTTtZQUNILE9BQU87U0FDVjtRQUVELElBQUksSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFFO1lBQzFCLElBQUksTUFBTSxHQUFlLElBQUksb0JBQVUsRUFBRSxDQUFDO1lBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEQsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUM7U0FDN0I7YUFBTTtZQUNILElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1NBQzNCO0lBRUwsQ0FBQztJQUNMLG9CQUFDO0FBQUQsQ0F0REEsQUFzREMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBhY3Rpb25JdGVtIGZyb20gXCIuL2FjdGlvbkl0ZW1cIjtcclxuaW1wb3J0IGFjdGlvbkRhdGEgZnJvbSBcIi4vYWN0aW9uRGF0YVwiO1xyXG5pbXBvcnQgaGFuZGxlciBmcm9tIFwiLi9oYW5kbGVyXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGFjdGlvbk1hbmFnZXIge1xyXG5cclxuXHJcbiAgICBwcml2YXRlIHN0YXRpYyBfaW5zdGFuY2U6IGFjdGlvbk1hbmFnZXI7XHJcbiAgICBwcml2YXRlIF9jdXJJbmRleCA9IDA7XHJcbiAgICBwdWJsaWMgc3RhdGljIGdldCBpbnN0YW5jZSgpOiBhY3Rpb25NYW5hZ2VyIHtcclxuICAgICAgICBpZiAoIWFjdGlvbk1hbmFnZXIuX2luc3RhbmNlKSB7XHJcbiAgICAgICAgICAgIGFjdGlvbk1hbmFnZXIuX2luc3RhbmNlID0gbmV3IGFjdGlvbk1hbmFnZXIoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGFjdGlvbk1hbmFnZXIuX2luc3RhbmNlO1xyXG4gICAgfVxyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2FjdGlvbkRhdGFMaXN0OiBBcnJheTxhY3Rpb25EYXRhPjtcclxuICAgIHByaXZhdGUgX2N1cnJlbnRBY3Rpb246IGFjdGlvbkl0ZW07XHJcbiAgICBwcml2YXRlIF9OZXh0QWN0aW9uOiBhY3Rpb25JdGVtO1xyXG5cclxuICAgIHB1YmxpYyBpbml0KGRhdGE6IEFycmF5PGFueT4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgbG9uID0gZGF0YS5sZW5ndGg7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsb247IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoaSA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9OZXh0QWN0aW9uID0gbmV3IGFjdGlvbkl0ZW0oKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX05leHRBY3Rpb24uaW5pdChkYXRhW2ldKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fYWN0aW9uRGF0YUxpc3Q9ZGF0YTtcclxuXHJcbiAgICB9XHJcbiAgICBwcml2YXRlIG1vdmVOZXh0KCl7XHJcbiAgICAgICAgdGhpcy5fY3VySW5kZXgrKztcclxuICAgICAgICB0aGlzLnJ1bkFjdGlvbmxpc3QoKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBydW5BY3Rpb25saXN0KCk6IHZvaWQge1xyXG4gICAgICAgIHZhciB0aGF0ID0gdGhpcztcclxuICAgICAgICBsZXQgbG9uID0gdGhpcy5fYWN0aW9uRGF0YUxpc3QubGVuZ3RoO1xyXG4gICAgICAgIGlmICh0aGlzLl9OZXh0QWN0aW9uICE9IG51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudEFjdGlvbiA9IHRoaXMuX05leHRBY3Rpb247XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRBY3Rpb24uZW50ZXIoaGFuZGxlci5jcmVhdGUodGhhdCx0aGF0Lm1vdmVOZXh0KSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2N1ckluZGV4ICsgMSA8IGxvbikge1xyXG4gICAgICAgICAgICBsZXQgYWN0aW9uOiBhY3Rpb25JdGVtID0gbmV3IGFjdGlvbkl0ZW0oKTtcclxuICAgICAgICAgICAgYWN0aW9uLmluaXQodGhpcy5fYWN0aW9uRGF0YUxpc3RbdGhpcy5fY3VySW5kZXggKyAxXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX05leHRBY3Rpb24gPSBhY3Rpb247XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fTmV4dEFjdGlvbiA9IG51bGw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxufSJdfQ==