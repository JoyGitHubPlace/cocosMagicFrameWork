
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/actionManager/handler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '06e09asUUxFCrzI9rM5H8Ma', 'handler');
// Script/actionManager/handler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var handler = /** @class */ (function () {
    function handler() {
    }
    handler.create = function (obj, func) {
        return {
            this: obj,
            runwith: func,
        };
    };
    return handler;
}());
exports.default = handler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxhY3Rpb25NYW5hZ2VyXFxoYW5kbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7SUFBQTtJQVFBLENBQUM7SUFQaUIsY0FBTSxHQUFwQixVQUFxQixHQUFPLEVBQUMsSUFBYTtRQUN0QyxPQUFPO1lBQ0gsSUFBSSxFQUFDLEdBQUc7WUFDUixPQUFPLEVBQUMsSUFBSTtTQUNmLENBQUE7SUFDTCxDQUFDO0lBRUwsY0FBQztBQUFELENBUkEsQUFRQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgaGFuZGxlcntcclxuICAgIHB1YmxpYyBzdGF0aWMgY3JlYXRlKG9iajphbnksZnVuYzpGdW5jdGlvbik6YW55e1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHRoaXM6b2JqLFxyXG4gICAgICAgICAgICBydW53aXRoOmZ1bmMsXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbn0iXX0=