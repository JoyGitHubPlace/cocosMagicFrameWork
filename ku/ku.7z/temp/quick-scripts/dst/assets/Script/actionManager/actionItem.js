
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/actionManager/actionItem.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3d385irLTBEoJgK9VgTecoN', 'actionItem');
// Script/actionManager/actionItem.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var basePlayer_1 = require("./basePlayer");
var actionItem = /** @class */ (function () {
    function actionItem() {
    }
    actionItem.prototype.init = function (data) {
        this._CurrentItem = new basePlayer_1.default();
        this._CurrentItem.init(data);
    };
    actionItem.prototype.enter = function (endback) {
        this.endBack = endback;
        this.Execute();
    };
    actionItem.prototype.Execute = function () {
        var that = this;
        this._CurrentItem.play(function () { that.end(); });
    };
    actionItem.prototype.end = function () {
        this.endBack();
    };
    return actionItem;
}());
exports.default = actionItem;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxhY3Rpb25NYW5hZ2VyXFxhY3Rpb25JdGVtLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsMkNBQXNDO0FBRXRDO0lBR0k7SUFFQSxDQUFDO0lBRU0seUJBQUksR0FBWCxVQUFZLElBQWU7UUFDdkIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLG9CQUFVLEVBQUUsQ0FBQztRQUNyQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBQ00sMEJBQUssR0FBWixVQUFhLE9BQWdCO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBQ00sNEJBQU8sR0FBZDtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFXLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQSxDQUFBLENBQUMsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFDTSx3QkFBRyxHQUFWO1FBQ0ksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ25CLENBQUM7SUFDTCxpQkFBQztBQUFELENBdEJBLEFBc0JDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYmFzZVBsYXllciBmcm9tIFwiLi9iYXNlUGxheWVyXCI7XHJcbmltcG9ydCBhY3Rpb25EYXRhIGZyb20gXCIuL2FjdGlvbkRhdGFcIjtcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgYWN0aW9uSXRlbVxyXG57XHJcbiAgICBwdWJsaWMgX0N1cnJlbnRJdGVtOmJhc2VQbGF5ZXI7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBcclxuICAgIH1cclxuICAgIHB1YmxpYyBlbmRCYWNrOkZ1bmN0aW9uO1xyXG4gICAgcHVibGljIGluaXQoZGF0YTphY3Rpb25EYXRhKTp2b2lke1xyXG4gICAgICAgIHRoaXMuX0N1cnJlbnRJdGVtID0gbmV3IGJhc2VQbGF5ZXIoKTtcclxuICAgICAgICB0aGlzLl9DdXJyZW50SXRlbS5pbml0KGRhdGEpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGVudGVyKGVuZGJhY2s6RnVuY3Rpb24pOnZvaWR7XHJcbiAgICAgICAgdGhpcy5lbmRCYWNrID0gZW5kYmFjaztcclxuICAgICAgICB0aGlzLkV4ZWN1dGUoKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBFeGVjdXRlKCk6dm9pZHtcclxuICAgICAgICBsZXQgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgdGhpcy5fQ3VycmVudEl0ZW0ucGxheShmdW5jdGlvbigpe3RoYXQuZW5kKCl9KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBlbmQoKTp2b2lke1xyXG4gICAgICAgIHRoaXMuZW5kQmFjaygpO1xyXG4gICAgfVxyXG59Il19