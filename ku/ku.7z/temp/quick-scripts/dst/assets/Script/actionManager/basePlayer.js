
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/actionManager/basePlayer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '01d5fXdUfVC9ZGobfQohaXF', 'basePlayer');
// Script/actionManager/basePlayer.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var basePlayer = /** @class */ (function () {
    function basePlayer() {
    }
    basePlayer.prototype.init = function (data) {
        this.name = data.name;
        this.tnum = data.TNum;
    };
    basePlayer.prototype.play = function (callback) {
        var that = this;
        setTimeout(function () {
            console.log(that.name);
            callback();
        }, this.tnum);
    };
    basePlayer.prototype.destroy = function () {
    };
    return basePlayer;
}());
exports.default = basePlayer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxhY3Rpb25NYW5hZ2VyXFxiYXNlUGxheWVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7SUFJSTtJQUVBLENBQUM7SUFDTSx5QkFBSSxHQUFYLFVBQVksSUFBZTtRQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdEIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzFCLENBQUM7SUFDTSx5QkFBSSxHQUFYLFVBQVksUUFBaUI7UUFDekIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLFVBQVUsQ0FBQztZQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3ZCLFFBQVEsRUFBRSxDQUFDO1FBQ2YsQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNsQixDQUFDO0lBRU0sNEJBQU8sR0FBZDtJQUVBLENBQUM7SUFFTCxpQkFBQztBQUFELENBdkJBLEFBdUJDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYWN0aW9uRGF0YSBmcm9tIFwiLi9hY3Rpb25EYXRhXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGJhc2VQbGF5ZXJcclxue1xyXG4gICAgcHVibGljIG5hbWU6c3RyaW5nO1xyXG4gICAgcHVibGljIHRudW06bnVtYmVyO1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgICBwdWJsaWMgaW5pdChkYXRhOmFjdGlvbkRhdGEpe1xyXG4gICAgICAgIHRoaXMubmFtZSA9IGRhdGEubmFtZTtcclxuICAgICAgICB0aGlzLnRudW0gPSBkYXRhLlROdW07XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgcGxheShjYWxsYmFjazpGdW5jdGlvbik6dm9pZHtcclxuICAgICAgICBsZXQgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoYXQubmFtZSk7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgfSwgdGhpcy50bnVtKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZGVzdHJveSgpOnZvaWR7XHJcblxyXG4gICAgfVxyXG5cclxufSJdfQ==