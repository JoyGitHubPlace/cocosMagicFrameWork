
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/UI/testItem.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f9621lj7jZJnqLtikcEjQkj', 'testItem');
// Script/UI/testItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Global_1 = require("../Manager/Global");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var testitem = /** @class */ (function (_super) {
    __extends(testitem, _super);
    function testitem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.levelItemObj = null;
        return _this;
        // update (dt) {}
    }
    testitem.prototype.start = function () {
        this.btn_icon.node.on('click', this.levelItem, this);
    };
    testitem.prototype.init = function (data) {
        this._itemdata = data;
        this.levelItemObj.setPosition(data.posX, data.posY, 0);
    };
    testitem.prototype.levelItem = function () {
        console.log(this._itemdata.name);
        Global_1.default.instance.event("destory", "123");
    };
    __decorate([
        property({ type: cc.Node, displayName: "levelItemObj" })
    ], testitem.prototype, "levelItemObj", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "levelItemObj" })
    ], testitem.prototype, "btn_icon", void 0);
    testitem = __decorate([
        ccclass
    ], testitem);
    return testitem;
}(cc.Component));
exports.default = testitem;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxVSVxcdGVzdEl0ZW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7QUFDbEYsNENBQXVDO0FBQ2pDLElBQUEsa0JBQW1DLEVBQWxDLG9CQUFPLEVBQUUsc0JBQXlCLENBQUM7QUFHMUM7SUFBc0MsNEJBQVk7SUFEbEQ7UUFBQSxxRUFxQkM7UUFqQlUsa0JBQVksR0FBVyxJQUFJLENBQUM7O1FBZ0JuQyxpQkFBaUI7SUFDckIsQ0FBQztJQVpHLHdCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNNLHVCQUFJLEdBQVgsVUFBWSxJQUFRO1FBQ2hCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ08sNEJBQVMsR0FBakI7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDakMsZ0JBQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBQyxLQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBZkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsY0FBYyxFQUFFLENBQUM7a0RBQ3RCO0lBR25DO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLGNBQWMsRUFBRSxDQUFDOzhDQUNqQztJQU5ULFFBQVE7UUFENUIsT0FBTztPQUNhLFFBQVEsQ0FvQjVCO0lBQUQsZUFBQztDQXBCRCxBQW9CQyxDQXBCcUMsRUFBRSxDQUFDLFNBQVMsR0FvQmpEO2tCQXBCb0IsUUFBUSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuaW1wb3J0IEdsb2JhbCBmcm9tIFwiLi4vTWFuYWdlci9HbG9iYWxcIjtcclxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyB0ZXN0aXRlbSBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogY2MuTm9kZSwgZGlzcGxheU5hbWU6IFwibGV2ZWxJdGVtT2JqXCIgfSlcclxuICAgIHB1YmxpYyBsZXZlbEl0ZW1PYmo6Y2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogY2MuQnV0dG9uLCBkaXNwbGF5TmFtZTogXCJsZXZlbEl0ZW1PYmpcIiB9KVxyXG4gICAgcHVibGljIGJ0bl9pY29uOmNjLkJ1dHRvbjtcclxuICAgIHB1YmxpYyBfaXRlbWRhdGE6YW55O1xyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuYnRuX2ljb24ubm9kZS5vbignY2xpY2snLCB0aGlzLmxldmVsSXRlbSwgdGhpcyk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgaW5pdChkYXRhOmFueSk6dm9pZHtcclxuICAgICAgICB0aGlzLl9pdGVtZGF0YSA9IGRhdGE7IFxyXG4gICAgICAgIHRoaXMubGV2ZWxJdGVtT2JqLnNldFBvc2l0aW9uKGRhdGEucG9zWCxkYXRhLnBvc1ksMCk7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGxldmVsSXRlbSgpOnZvaWR7XHJcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5faXRlbWRhdGEubmFtZSk7XHJcbiAgICAgICAgR2xvYmFsLmluc3RhbmNlLmV2ZW50KFwiZGVzdG9yeVwiLFwiMTIzXCIpO1xyXG4gICAgfVxyXG4gICAgLy8gdXBkYXRlIChkdCkge31cclxufVxyXG4iXX0=