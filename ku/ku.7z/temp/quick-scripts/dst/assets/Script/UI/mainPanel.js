
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/UI/mainPanel.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4de08/dikdBAJzlopZJzXlK', 'mainPanel');
// Script/UI/mainPanel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var configManager_1 = require("../configManager");
var poolManager_1 = require("../Manager/poolManager");
var Global_1 = require("../Manager/Global");
var levelItem = /** @class */ (function () {
    function levelItem() {
    }
    return levelItem;
}());
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var mainPanel = /** @class */ (function (_super) {
    __extends(mainPanel, _super);
    function mainPanel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.prefabs = [];
        _this.px = 0;
        return _this;
        // update (dt) {}
    }
    mainPanel.prototype.OnItemRender = function (item, idx) {
        console.log("idx", idx);
        if (configManager_1.default.instance["level"] != null) {
            var jsondata = configManager_1.default.instance["level"];
            console.log(jsondata[idx]);
            var testitem = item.getComponent("testItem");
            testitem.init(jsondata[idx]);
        }
    };
    mainPanel.prototype.addnode = function () {
        var that = this;
        if (that.prefabs != null) {
            var node = poolManager_1.default.instance.getNode("goldPrefab");
            node.parent = that.node;
            node.setPosition(this.px, 0, 0);
            this.px += 50;
        }
    };
    mainPanel.prototype._destroyEvent = function (data) {
        console.log("event:", data);
        Global_1.default.instance.off("destory", this._destroyEvent, this);
    };
    mainPanel.prototype.start = function () {
        var that = this;
        window["main"] = this;
        configManager_1.default.instance.load(function () {
            if (that.levelView != null) {
                if (configManager_1.default.instance["level"] != null) {
                    var jsondata = configManager_1.default.instance["level"];
                    var lon = jsondata.length;
                    that.levelViewList = that.levelView.getComponent("List");
                    that.levelViewList.numItems = lon;
                    that.levelViewList.updateAll();
                }
            }
        });
        /*if(configManager.instance["action"]!=null){
                actionManager.instance.init(configManager.instance["action"]);
                actionManager.instance.runActionlist();
            }*/
        poolManager_1.default.instance.init(that.prefabs);
        Global_1.default.instance.init();
        Global_1.default.instance.on("destory", this._destroyEvent, this);
    };
    __decorate([
        property({ type: cc.Node, displayName: "levelView" })
    ], mainPanel.prototype, "levelView", void 0);
    __decorate([
        property({ type: [cc.Prefab], displayName: "prefabs" })
    ], mainPanel.prototype, "prefabs", void 0);
    mainPanel = __decorate([
        ccclass
    ], mainPanel);
    return mainPanel;
}(cc.Component));
exports.default = mainPanel;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxVSVxcbWFpblBhbmVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGtEQUE2QztBQUU3QyxzREFBaUQ7QUFDakQsNENBQXVDO0FBQ3ZDO0lBQUE7SUFLQSxDQUFDO0lBQUQsZ0JBQUM7QUFBRCxDQUxBLEFBS0MsSUFBQTtBQUNLLElBQUEsa0JBQXFDLEVBQW5DLG9CQUFPLEVBQUUsc0JBQTBCLENBQUM7QUFHNUM7SUFBdUMsNkJBQVk7SUFEbkQ7UUFBQSxxRUFnRUM7UUF2RFUsYUFBTyxHQUFnQixFQUFFLENBQUM7UUFDMUIsUUFBRSxHQUFXLENBQUMsQ0FBQzs7UUFxRHRCLGlCQUFpQjtJQUNyQixDQUFDO0lBcERVLGdDQUFZLEdBQW5CLFVBQW9CLElBQVMsRUFBRSxHQUFXO1FBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLElBQUksdUJBQWEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxFQUFFO1lBQ3pDLElBQUksUUFBUSxHQUFHLHVCQUFhLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDM0IsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUU3QyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO0lBRUwsQ0FBQztJQUNNLDJCQUFPLEdBQWQ7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksRUFBRTtZQUN0QixJQUFJLElBQUksR0FBRyxxQkFBVyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUM7U0FDakI7SUFDTCxDQUFDO0lBQ08saUNBQWEsR0FBckIsVUFBc0IsSUFBUztRQUMzQixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM1QixnQkFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELHlCQUFLLEdBQUw7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQztRQUN0Qix1QkFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDeEIsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRTtnQkFDeEIsSUFBSSx1QkFBYSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLEVBQUU7b0JBQ3pDLElBQUksUUFBUSxHQUFHLHVCQUFhLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUMvQyxJQUFJLEdBQUcsR0FBVyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUNsQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6RCxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLENBQUE7aUJBQ2pDO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVIOzs7ZUFHTztRQUVQLHFCQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFeEMsZ0JBQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDdkIsZ0JBQU0sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBRTVELENBQUM7SUF4REQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLENBQUM7Z0RBQzVCO0lBSTFCO1FBREMsUUFBUSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQzs4Q0FDdkI7SUFSaEIsU0FBUztRQUQ3QixPQUFPO09BQ2EsU0FBUyxDQStEN0I7SUFBRCxnQkFBQztDQS9ERCxBQStEQyxDQS9Ec0MsRUFBRSxDQUFDLFNBQVMsR0ErRGxEO2tCQS9Eb0IsU0FBUyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjb25maWdNYW5hZ2VyIGZyb20gXCIuLi9jb25maWdNYW5hZ2VyXCI7XHJcbmltcG9ydCBhY3Rpb25NYW5hZ2VyIGZyb20gXCIuLi9hY3Rpb25NYW5hZ2VyL2FjdGlvbk1hbmFnZXJcIjtcclxuaW1wb3J0IHBvb2xNYW5hZ2VyIGZyb20gXCIuLi9NYW5hZ2VyL3Bvb2xNYW5hZ2VyXCI7XHJcbmltcG9ydCBHbG9iYWwgZnJvbSBcIi4uL01hbmFnZXIvR2xvYmFsXCI7XHJcbmNsYXNzIGxldmVsSXRlbSB7XHJcbiAgICBwdWJsaWMgaWQ6IG51bWJlcjtcclxuICAgIHB1YmxpYyBuYW1lOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgbGV2ZWxJbmRleDogbnVtYmVyO1xyXG4gICAgcHVibGljIGNvc3Q6IG51bWJlcjtcclxufVxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgbWFpblBhbmVsIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBwdWJsaWMgbGV2ZWxEYXRhOiBBcnJheTxsZXZlbEl0ZW0+O1xyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogY2MuTm9kZSwgZGlzcGxheU5hbWU6IFwibGV2ZWxWaWV3XCIgfSlcclxuICAgIHB1YmxpYyBsZXZlbFZpZXc6IGNjLk5vZGU7XHJcbiAgICBwdWJsaWMgbGV2ZWxWaWV3TGlzdDogYW55O1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IFtjYy5QcmVmYWJdLCBkaXNwbGF5TmFtZTogXCJwcmVmYWJzXCIgfSlcclxuICAgIHB1YmxpYyBwcmVmYWJzOiBjYy5QcmVmYWJbXSA9IFtdO1xyXG4gICAgcHVibGljIHB4OiBudW1iZXIgPSAwO1xyXG5cclxuICAgIHB1YmxpYyBPbkl0ZW1SZW5kZXIoaXRlbTogYW55LCBpZHg6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiaWR4XCIsIGlkeCk7XHJcbiAgICAgICAgaWYgKGNvbmZpZ01hbmFnZXIuaW5zdGFuY2VbXCJsZXZlbFwiXSAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIGxldCBqc29uZGF0YSA9IGNvbmZpZ01hbmFnZXIuaW5zdGFuY2VbXCJsZXZlbFwiXTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coanNvbmRhdGFbaWR4XSk7XHJcbiAgICAgICAgICAgIGxldCB0ZXN0aXRlbSA9IGl0ZW0uZ2V0Q29tcG9uZW50KFwidGVzdEl0ZW1cIik7XHJcblxyXG4gICAgICAgICAgICB0ZXN0aXRlbS5pbml0KGpzb25kYXRhW2lkeF0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbiAgICBwdWJsaWMgYWRkbm9kZSgpIHtcclxuICAgICAgICB2YXIgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgaWYgKHRoYXQucHJlZmFicyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgIGxldCBub2RlID0gcG9vbE1hbmFnZXIuaW5zdGFuY2UuZ2V0Tm9kZShcImdvbGRQcmVmYWJcIik7XHJcbiAgICAgICAgICAgIG5vZGUucGFyZW50ID0gdGhhdC5ub2RlO1xyXG4gICAgICAgICAgICBub2RlLnNldFBvc2l0aW9uKHRoaXMucHgsIDAsIDApO1xyXG4gICAgICAgICAgICB0aGlzLnB4ICs9IDUwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHByaXZhdGUgX2Rlc3Ryb3lFdmVudChkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImV2ZW50OlwiLCBkYXRhKTtcclxuICAgICAgICBHbG9iYWwuaW5zdGFuY2Uub2ZmKFwiZGVzdG9yeVwiLCB0aGlzLl9kZXN0cm95RXZlbnQsIHRoaXMpO1xyXG4gICAgfVxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgdmFyIHRoYXQgPSB0aGlzO1xyXG4gICAgICAgIHdpbmRvd1tcIm1haW5cIl0gPSB0aGlzO1xyXG4gICAgICAgIGNvbmZpZ01hbmFnZXIuaW5zdGFuY2UubG9hZChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGF0LmxldmVsVmlldyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnTWFuYWdlci5pbnN0YW5jZVtcImxldmVsXCJdICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQganNvbmRhdGEgPSBjb25maWdNYW5hZ2VyLmluc3RhbmNlW1wibGV2ZWxcIl07XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxvbjogbnVtYmVyID0ganNvbmRhdGEubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQubGV2ZWxWaWV3TGlzdCA9IHRoYXQubGV2ZWxWaWV3LmdldENvbXBvbmVudChcIkxpc3RcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhhdC5sZXZlbFZpZXdMaXN0Lm51bUl0ZW1zID0gbG9uO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoYXQubGV2ZWxWaWV3TGlzdC51cGRhdGVBbGwoKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8qaWYoY29uZmlnTWFuYWdlci5pbnN0YW5jZVtcImFjdGlvblwiXSE9bnVsbCl7XHJcbiAgICAgICAgICAgICAgICBhY3Rpb25NYW5hZ2VyLmluc3RhbmNlLmluaXQoY29uZmlnTWFuYWdlci5pbnN0YW5jZVtcImFjdGlvblwiXSk7XHJcbiAgICAgICAgICAgICAgICBhY3Rpb25NYW5hZ2VyLmluc3RhbmNlLnJ1bkFjdGlvbmxpc3QoKTtcclxuICAgICAgICAgICAgfSovXHJcblxyXG4gICAgICAgIHBvb2xNYW5hZ2VyLmluc3RhbmNlLmluaXQodGhhdC5wcmVmYWJzKTtcclxuXHJcbiAgICAgICAgR2xvYmFsLmluc3RhbmNlLmluaXQoKTtcclxuICAgICAgICBHbG9iYWwuaW5zdGFuY2Uub24oXCJkZXN0b3J5XCIsIHRoaXMuX2Rlc3Ryb3lFdmVudCwgdGhpcyk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9XHJcbn1cclxuIl19