
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/NodeMapManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5d029CRkJxPm65zu/TmhepX', 'NodeMapManager');
// Script/NodeMapManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NodeMapManager = /** @class */ (function (_super) {
    __extends(NodeMapManager, _super);
    function NodeMapManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.text = 'hello';
        // LIFE-CYCLE CALLBACKS:
        _this.nodePrefab = null;
        _this.parentNode = null;
        return _this;
        // update (dt) {}
    }
    NodeMapManager.prototype.start = function () {
        var node = cc.instantiate(this.nodePrefab);
        node.position = new cc.Vec3(0, 0, 0);
        node.parent = this.parentNode;
        var item = node.getComponent("NodeItem");
        item.text = "nodetest";
    };
    __decorate([
        property
    ], NodeMapManager.prototype, "text", void 0);
    __decorate([
        property({ type: cc.Prefab, displayName: "预制体" })
    ], NodeMapManager.prototype, "nodePrefab", void 0);
    __decorate([
        property({ type: cc.Node, displayName: "父物体" })
    ], NodeMapManager.prototype, "parentNode", void 0);
    NodeMapManager = __decorate([
        ccclass
    ], NodeMapManager);
    return NodeMapManager;
}(cc.Component));
exports.default = NodeMapManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxOb2RlTWFwTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDTSxJQUFBLGtCQUFxQyxFQUFuQyxvQkFBTyxFQUFFLHNCQUEwQixDQUFDO0FBRzVDO0lBQTRDLGtDQUFZO0lBRHhEO1FBQUEscUVBc0JDO1FBbEJHLFVBQUksR0FBVyxPQUFPLENBQUM7UUFFdkIsd0JBQXdCO1FBRWpCLGdCQUFVLEdBQWMsSUFBSSxDQUFDO1FBRzdCLGdCQUFVLEdBQVksSUFBSSxDQUFDOztRQVVsQyxpQkFBaUI7SUFDckIsQ0FBQztJQVZHLDhCQUFLLEdBQUw7UUFDSSxJQUFJLElBQUksR0FBWSxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUNuRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUM5QixJQUFJLElBQUksR0FBYSxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDO0lBRTNCLENBQUM7SUFmRDtRQURDLFFBQVE7Z0RBQ2M7SUFJdkI7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLENBQUM7c0RBQ2Q7SUFHcEM7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLENBQUM7c0RBQ2Q7SUFWakIsY0FBYztRQURsQyxPQUFPO09BQ2EsY0FBYyxDQXFCbEM7SUFBRCxxQkFBQztDQXJCRCxBQXFCQyxDQXJCMkMsRUFBRSxDQUFDLFNBQVMsR0FxQnZEO2tCQXJCb0IsY0FBYyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBOb2RlSXRlbSBmcm9tIFwiLi9Ob2RlSXRlbVwiO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTm9kZU1hcE1hbmFnZXIgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgdGV4dDogc3RyaW5nID0gJ2hlbGxvJztcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLlByZWZhYiwgZGlzcGxheU5hbWU6IFwi6aKE5Yi25L2TXCIgfSlcclxuICAgIHB1YmxpYyBub2RlUHJlZmFiOiBjYy5QcmVmYWIgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLk5vZGUsIGRpc3BsYXlOYW1lOiBcIueItueJqeS9k1wiIH0pXHJcbiAgICBwdWJsaWMgcGFyZW50Tm9kZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICBsZXQgbm9kZTogY2MuTm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMubm9kZVByZWZhYilcclxuICAgICAgICBub2RlLnBvc2l0aW9uID0gbmV3IGNjLlZlYzMoMCwgMCwgMCk7XHJcbiAgICAgICAgbm9kZS5wYXJlbnQgPSB0aGlzLnBhcmVudE5vZGU7XHJcbiAgICAgICAgbGV0IGl0ZW06IE5vZGVJdGVtID0gbm9kZS5nZXRDb21wb25lbnQoXCJOb2RlSXRlbVwiKTtcclxuICAgICAgICBpdGVtLnRleHQgPSBcIm5vZGV0ZXN0XCI7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9XHJcbn1cclxuIl19