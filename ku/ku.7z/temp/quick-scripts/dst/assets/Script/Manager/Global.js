
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Manager/Global.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e18adlTid9KRpWDckSQ1mh3', 'Global');
// Script/Manager/Global.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Global = /** @class */ (function () {
    function Global() {
    }
    Object.defineProperty(Global, "instance", {
        get: function () {
            if (!Global._instance) {
                Global._instance = new Global();
            }
            return Global._instance;
        },
        enumerable: true,
        configurable: true
    });
    Global.prototype._initEventCenter = function () {
        this.EventCenter = this.EventCenter || new cc.EventTarget();
    };
    Global.prototype.init = function () {
        this._initEventCenter();
    };
    Global.prototype.on = function (eventName, callback, target) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.on(eventName, callback, target);
    };
    Global.prototype.off = function (eventName, callback, target) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.off(eventName, callback, target);
    };
    Global.prototype.once = function (eventName, callback, target) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.once(eventName, callback, target);
    };
    Global.prototype.event = function (eventName, data) {
        if (this.EventCenter == null) {
            console.warn("EventCenter is not init");
        }
        this.EventCenter.emit(eventName, data);
    };
    return Global;
}());
exports.default = Global;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxNYW5hZ2VyXFxHbG9iYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtJQWNJO0lBQ0EsQ0FBQztJQVBELHNCQUFrQixrQkFBUTthQUExQjtZQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO2dCQUNuQixNQUFNLENBQUMsU0FBUyxHQUFHLElBQUksTUFBTSxFQUFFLENBQUM7YUFDbkM7WUFDRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUM7UUFDNUIsQ0FBQzs7O09BQUE7SUFJTyxpQ0FBZ0IsR0FBeEI7UUFDSSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDaEUsQ0FBQztJQUNNLHFCQUFJLEdBQVg7UUFDSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU0sbUJBQUUsR0FBVCxVQUFVLFNBQWlCLEVBQUUsUUFBa0IsRUFBRSxNQUFZO1FBQ3pELElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLEVBQUU7WUFDMUIsT0FBTyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1NBQzNDO1FBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBQ00sb0JBQUcsR0FBVixVQUFXLFNBQWlCLEVBQUUsUUFBbUIsRUFBRSxNQUFZO1FBQzNELElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLEVBQUU7WUFDMUIsT0FBTyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1NBQzNDO1FBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ00scUJBQUksR0FBWCxVQUFZLFNBQWlCLEVBQUUsUUFBa0IsRUFBRSxNQUFZO1FBQzNELElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLEVBQUU7WUFDMUIsT0FBTyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1NBQzNDO1FBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBQ00sc0JBQUssR0FBWixVQUFhLFNBQWlCLEVBQUMsSUFBUTtRQUNuQyxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxFQUFFO1lBQzFCLE9BQU8sQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQztTQUMzQztRQUNELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0wsYUFBQztBQUFELENBaERBLEFBZ0RDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBjbGFzcyBHbG9iYWwge1xyXG4gICAgLyoqXHJcbiAgICAgKiBhdXRob3IgYnkgSm95XHJcbiAgICAgKiBHbG9iYWwgaW5zdGFuY2VcclxuICAgICAqIFxyXG4gICAgICogMTpldmVudENlbnRlciAgZXZlbnQub24gb2ZmIG9uY2Ugc2VuZFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHN0YXRpYyBfaW5zdGFuY2U6IEdsb2JhbDtcclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0IGluc3RhbmNlKCk6IEdsb2JhbCB7XHJcbiAgICAgICAgaWYgKCFHbG9iYWwuX2luc3RhbmNlKSB7XHJcbiAgICAgICAgICAgIEdsb2JhbC5faW5zdGFuY2UgPSBuZXcgR2xvYmFsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBHbG9iYWwuX2luc3RhbmNlO1xyXG4gICAgfVxyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB9XHJcbiAgICBwcml2YXRlIEV2ZW50Q2VudGVyOiBhbnk7XHJcbiAgICBwcml2YXRlIF9pbml0RXZlbnRDZW50ZXIoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5FdmVudENlbnRlciA9IHRoaXMuRXZlbnRDZW50ZXIgfHwgbmV3IGNjLkV2ZW50VGFyZ2V0KCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgaW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0RXZlbnRDZW50ZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb24oZXZlbnROYW1lOiBzdHJpbmcsIGNhbGxiYWNrOiBGdW5jdGlvbiwgdGFyZ2V0PzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuRXZlbnRDZW50ZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCJFdmVudENlbnRlciBpcyBub3QgaW5pdFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5FdmVudENlbnRlci5vbihldmVudE5hbWUsIGNhbGxiYWNrLCB0YXJnZXQpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIG9mZihldmVudE5hbWU6IHN0cmluZywgY2FsbGJhY2s/OiBGdW5jdGlvbiwgdGFyZ2V0PzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuRXZlbnRDZW50ZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCJFdmVudENlbnRlciBpcyBub3QgaW5pdFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5FdmVudENlbnRlci5vZmYoZXZlbnROYW1lLCBjYWxsYmFjaywgdGFyZ2V0KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBvbmNlKGV2ZW50TmFtZTogc3RyaW5nLCBjYWxsYmFjazogRnVuY3Rpb24sIHRhcmdldD86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLkV2ZW50Q2VudGVyID09IG51bGwpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKFwiRXZlbnRDZW50ZXIgaXMgbm90IGluaXRcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuRXZlbnRDZW50ZXIub25jZShldmVudE5hbWUsIGNhbGxiYWNrLCB0YXJnZXQpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGV2ZW50KGV2ZW50TmFtZTogc3RyaW5nLGRhdGE6YW55KSB7XHJcbiAgICAgICAgaWYgKHRoaXMuRXZlbnRDZW50ZXIgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCJFdmVudENlbnRlciBpcyBub3QgaW5pdFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5FdmVudENlbnRlci5lbWl0KGV2ZW50TmFtZSxkYXRhKTtcclxuICAgIH1cclxufSJdfQ==