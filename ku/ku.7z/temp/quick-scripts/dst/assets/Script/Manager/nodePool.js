
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Manager/nodePool.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fc7a2OfEOFOxaOl9GJtTwuy', 'nodePool');
// Script/Manager/nodePool.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var nodePool = /** @class */ (function () {
    function nodePool() {
        /**
         * author by Joy
         * object pool
         */
        this._pool = [];
    }
    nodePool.prototype.size = function () {
        return this._pool.length;
    };
    nodePool.prototype.clear = function () {
        var count = this._pool.length;
        for (var i = 0; i < count; ++i) {
            this._pool[i].destroy();
        }
        this._pool.length = 0;
    };
    nodePool.prototype.put = function (obj) {
        if (obj && this._pool.indexOf(obj) === -1) {
            obj.removeFromParent(false);
        }
        this._pool.push(obj);
    };
    nodePool.prototype.get = function () {
        var last = this._pool.length - 1;
        if (last < 0) {
            return null;
        }
        else {
            var obj = this._pool[last];
            this._pool[last] = null;
            this._pool.length = last;
            return obj;
        }
    };
    return nodePool;
}());
exports.default = nodePool;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxNYW5hZ2VyXFxub2RlUG9vbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0lBTUk7UUFMQTs7O1dBR0c7UUFDSyxVQUFLLEdBQVEsRUFBRSxDQUFDO0lBRXhCLENBQUM7SUFFTSx1QkFBSSxHQUFYO1FBQ0ksT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztJQUM3QixDQUFDO0lBQ00sd0JBQUssR0FBWjtRQUNJLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQzlCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMzQjtRQUNELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBQ00sc0JBQUcsR0FBVixVQUFXLEdBQVE7UUFDZixJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtZQUN2QyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDL0I7UUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRU0sc0JBQUcsR0FBVjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNqQyxJQUFJLElBQUksR0FBRyxDQUFDLEVBQUU7WUFDVixPQUFPLElBQUksQ0FBQztTQUNmO2FBQ0k7WUFDRCxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUN6QixPQUFPLEdBQUcsQ0FBQztTQUNkO0lBQ0wsQ0FBQztJQUNMLGVBQUM7QUFBRCxDQXRDQSxBQXNDQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3Mgbm9kZVBvb2wge1xyXG4gICAgLyoqXHJcbiAgICAgKiBhdXRob3IgYnkgSm95XHJcbiAgICAgKiBvYmplY3QgcG9vbFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9wb29sOiBhbnkgPSBbXTtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzaXplKCk6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3Bvb2wubGVuZ3RoO1xyXG4gICAgfVxyXG4gICAgcHVibGljIGNsZWFyKCk6IHZvaWQge1xyXG4gICAgICAgIHZhciBjb3VudCA9IHRoaXMuX3Bvb2wubGVuZ3RoO1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY291bnQ7ICsraSkge1xyXG4gICAgICAgICAgICB0aGlzLl9wb29sW2ldLmRlc3Ryb3koKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fcG9vbC5sZW5ndGggPSAwO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHB1dChvYmo6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmIChvYmogJiYgdGhpcy5fcG9vbC5pbmRleE9mKG9iaikgPT09IC0xKSB7XHJcbiAgICAgICAgICAgIG9iai5yZW1vdmVGcm9tUGFyZW50KGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fcG9vbC5wdXNoKG9iaik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldCgpOiBhbnkge1xyXG4gICAgICAgIHZhciBsYXN0ID0gdGhpcy5fcG9vbC5sZW5ndGggLSAxO1xyXG4gICAgICAgIGlmIChsYXN0IDwgMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBvYmogPSB0aGlzLl9wb29sW2xhc3RdO1xyXG4gICAgICAgICAgICB0aGlzLl9wb29sW2xhc3RdID0gbnVsbDtcclxuICAgICAgICAgICAgdGhpcy5fcG9vbC5sZW5ndGggPSBsYXN0O1xyXG4gICAgICAgICAgICByZXR1cm4gb2JqO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ==