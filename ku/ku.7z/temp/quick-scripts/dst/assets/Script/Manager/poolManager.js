
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Manager/poolManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6abd5/qKWJGdoRCGiPbdPn9', 'poolManager');
// Script/Manager/poolManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var nodePool_1 = require("./nodePool");
var poolManager = /** @class */ (function () {
    function poolManager() {
        this._poolItems = [];
        this._nodesPool = [];
        this._maxSize = 0;
    }
    Object.defineProperty(poolManager, "instance", {
        get: function () {
            if (!poolManager._instance) {
                poolManager._instance = new poolManager();
            }
            return poolManager._instance;
        },
        enumerable: true,
        configurable: true
    });
    poolManager.prototype.init = function (prefabs, max) {
        var _this = this;
        if (max === void 0) { max = 3; }
        this._maxSize = max;
        prefabs.forEach(function (element) {
            _this._poolItems[element.name] = element;
            var np = new nodePool_1.default();
            _this._nodesPool[element.name] = np;
            _this.genNode(element.name, max);
        });
    };
    poolManager.prototype.genNode = function (type, num) {
        for (var i = 0; i < num; ++i) {
            var prefab = this._poolItems[type];
            var node = cc.instantiate(prefab);
            node.active = false;
            this._nodesPool[type].put(node);
        }
    };
    poolManager.prototype.getNode = function (type) {
        var node = null;
        var size = this._nodesPool[type].size();
        if (size > 0) {
            node = this._nodesPool[type].get();
        }
        else {
            node = cc.instantiate(this._poolItems[type]);
        }
        node.name = type;
        node.active = true;
        return node;
    };
    poolManager.prototype.putNode = function (node) {
        node.active = false;
        if (node.name == null) {
            return;
        }
        if (this._nodesPool[node.name].size() + 1 > this._maxSize) {
            node = null;
        }
        else {
            this._nodesPool[node.name].put(node);
        }
    };
    poolManager.prototype.clearAllNode = function (type) {
        this._nodesPool[type].clear();
    };
    return poolManager;
}());
exports.default = poolManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxNYW5hZ2VyXFxwb29sTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHVDQUFrQztBQUNsQztJQVlJO1FBR1EsZUFBVSxHQUFRLEVBQUUsQ0FBQztRQUN0QixlQUFVLEdBQVEsRUFBRSxDQUFDO1FBQ3BCLGFBQVEsR0FBVyxDQUFDLENBQUM7SUFKN0IsQ0FBQztJQVBELHNCQUFrQix1QkFBUTthQUExQjtZQUNJLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFO2dCQUN4QixXQUFXLENBQUMsU0FBUyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUM7YUFDN0M7WUFDRCxPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUM7UUFDakMsQ0FBQzs7O09BQUE7SUFRTSwwQkFBSSxHQUFYLFVBQVksT0FBb0IsRUFBRSxHQUFlO1FBQWpELGlCQVNDO1FBVGlDLG9CQUFBLEVBQUEsT0FBZTtRQUM3QyxJQUFJLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQztRQUNwQixPQUFPLENBQUMsT0FBTyxDQUFDLFVBQUEsT0FBTztZQUNuQixLQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUM7WUFDeEMsSUFBSSxFQUFFLEdBQWEsSUFBSSxrQkFBUSxFQUFFLENBQUM7WUFDbEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBRW5DLEtBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyw2QkFBTyxHQUFmLFVBQWdCLElBQVksRUFBRSxHQUFXO1FBQ3JDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDMUIsSUFBSSxNQUFNLEdBQWMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM5QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ25DO0lBQ0wsQ0FBQztJQUNNLDZCQUFPLEdBQWQsVUFBZSxJQUFZO1FBQ3ZCLElBQUksSUFBSSxHQUFRLElBQUksQ0FBQztRQUNyQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3hDLElBQUksSUFBSSxHQUFHLENBQUMsRUFBRTtZQUNWLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQ3RDO2FBQU07WUFDSCxJQUFJLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDaEQ7UUFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUNuQixPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBQ00sNkJBQU8sR0FBZCxVQUFlLElBQVM7UUFDcEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDcEIsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRTtZQUNuQixPQUFPO1NBQ1Y7UUFDRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ3ZELElBQUksR0FBRyxJQUFJLENBQUM7U0FDZjthQUFNO1lBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3hDO0lBRUwsQ0FBQztJQUNNLGtDQUFZLEdBQW5CLFVBQW9CLElBQVk7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBQ0wsa0JBQUM7QUFBRCxDQWpFQSxBQWlFQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG5vZGVQb29sIGZyb20gXCIuL25vZGVQb29sXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIHBvb2xNYW5hZ2VyIHtcclxuICAgIC8qKlxyXG4gICAgICogYXV0aG9yIGJ5IEpveVxyXG4gICAgICogb2JqZWN0IHBvb2wgbWFuYWdlclxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHN0YXRpYyBfaW5zdGFuY2U6IHBvb2xNYW5hZ2VyO1xyXG4gICAgcHVibGljIHN0YXRpYyBnZXQgaW5zdGFuY2UoKTogcG9vbE1hbmFnZXIge1xyXG4gICAgICAgIGlmICghcG9vbE1hbmFnZXIuX2luc3RhbmNlKSB7XHJcbiAgICAgICAgICAgIHBvb2xNYW5hZ2VyLl9pbnN0YW5jZSA9IG5ldyBwb29sTWFuYWdlcigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcG9vbE1hbmFnZXIuX2luc3RhbmNlO1xyXG4gICAgfVxyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcG9vbEl0ZW1zOiBhbnkgPSBbXTtcclxuICAgIHB1YmxpYyBfbm9kZXNQb29sOiBhbnkgPSBbXTtcclxuICAgIHByaXZhdGUgX21heFNpemU6IG51bWJlciA9IDA7XHJcblxyXG4gICAgcHVibGljIGluaXQocHJlZmFiczogY2MuUHJlZmFiW10sIG1heDogbnVtYmVyID0gMyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX21heFNpemUgPSBtYXg7XHJcbiAgICAgICAgcHJlZmFicy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9wb29sSXRlbXNbZWxlbWVudC5uYW1lXSA9IGVsZW1lbnQ7XHJcbiAgICAgICAgICAgIGxldCBucDogbm9kZVBvb2wgPSBuZXcgbm9kZVBvb2woKTtcclxuICAgICAgICAgICAgdGhpcy5fbm9kZXNQb29sW2VsZW1lbnQubmFtZV0gPSBucDtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuZ2VuTm9kZShlbGVtZW50Lm5hbWUsIG1heCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBnZW5Ob2RlKHR5cGU6IHN0cmluZywgbnVtOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG51bTsgKytpKSB7XHJcbiAgICAgICAgICAgIGxldCBwcmVmYWI6IGNjLlByZWZhYiA9IHRoaXMuX3Bvb2xJdGVtc1t0eXBlXTtcclxuICAgICAgICAgICAgbGV0IG5vZGUgPSBjYy5pbnN0YW50aWF0ZShwcmVmYWIpO1xyXG4gICAgICAgICAgICBub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9ub2Rlc1Bvb2xbdHlwZV0ucHV0KG5vZGUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXROb2RlKHR5cGU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgbGV0IG5vZGU6IGFueSA9IG51bGw7XHJcbiAgICAgICAgbGV0IHNpemUgPSB0aGlzLl9ub2Rlc1Bvb2xbdHlwZV0uc2l6ZSgpO1xyXG4gICAgICAgIGlmIChzaXplID4gMCkge1xyXG4gICAgICAgICAgICBub2RlID0gdGhpcy5fbm9kZXNQb29sW3R5cGVdLmdldCgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLl9wb29sSXRlbXNbdHlwZV0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBub2RlLm5hbWUgPSB0eXBlO1xyXG4gICAgICAgIG5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICByZXR1cm4gbm9kZTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBwdXROb2RlKG5vZGU6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIG5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKG5vZGUubmFtZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX25vZGVzUG9vbFtub2RlLm5hbWVdLnNpemUoKSArIDEgPiB0aGlzLl9tYXhTaXplKSB7XHJcbiAgICAgICAgICAgIG5vZGUgPSBudWxsO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX25vZGVzUG9vbFtub2RlLm5hbWVdLnB1dChub2RlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG4gICAgcHVibGljIGNsZWFyQWxsTm9kZSh0eXBlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9ub2Rlc1Bvb2xbdHlwZV0uY2xlYXIoKTtcclxuICAgIH1cclxufSJdfQ==