
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Third/VirtualList/List.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '882f21gGzBJ9pC43GkTnEzp', 'List');
// Script/Third/VirtualList/List.js

"use strict";

/******************************************
 * @author kL <klk0@qq.com>
 * @date 2019/1/5
 * @doc 列表组件.
 * @end
 ******************************************/
var TemplateType = cc.Enum({
  'NODE': 1,
  'PREFAB': 2
});
var SlideType = cc.Enum({
  'NORMAL': 1,
  //普通
  'ADHERING': 2,
  //粘附模式，将强制关闭滚动惯性
  'PAGE': 3 //页面模式，将强制关闭滚动惯性

});
var SelectedType = cc.Enum({
  'NONE': 0,
  'SINGLE': 1,
  //单选
  'MULT': 2 //多选

});

var ListItem = require('ListItem');

cc.Class({
  "extends": cc.Component,
  editor: {
    disallowMultiple: false,
    menu: '自定义组件/List',
    requireComponent: cc.ScrollView,
    //脚本生命周期回调的执行优先级。小于 0 的脚本将优先执行，大于 0 的脚本将最后执行。该优先级只对 onLoad, onEnable, start, update 和 lateUpdate 有效，对 onDisable 和 onDestroy 无效。
    executionOrder: -5000
  },
  properties: {
    templateType: {
      "default": TemplateType.NODE,
      type: TemplateType
    },
    tmpNode: {
      "default": null,
      type: cc.Node,
      tooltip: CC_DEV && 'Item模版，type:cc.Node',
      visible: function visible() {
        var bool = this.templateType == TemplateType.NODE;
        if (!bool) this.tmpNode = null;
        return bool;
      }
    },
    tmpPrefab: {
      "default": null,
      type: cc.Prefab,
      tooltip: CC_DEV && 'Item模版，type:cc.Prefab',
      visible: function visible() {
        var bool = this.templateType == TemplateType.PREFAB;
        if (!bool) this.tmpPrefab = null;
        return bool;
      }
    },
    _slideMode: 1,
    slideMode: {
      type: SlideType,
      tooltip: CC_DEV && '滑动模式',
      get: function get() {
        return this._slideMode;
      },
      set: function set(val) {
        if (val != null) this._slideMode = val;
      }
    },
    pageDistance: {
      "default": .3,
      type: cc.Float,
      range: [0, 1, .1],
      tooltip: CC_DEV && '翻页作用距离',
      slide: true,
      visible: function visible() {
        return this._slideMode == SlideType.PAGE;
      }
    },
    pageChangeEvent: {
      "default": null,
      type: cc.Component.EventHandler,
      tooltip: CC_DEV && '页面改变事件',
      visible: function visible() {
        var bool = this._slideMode == SlideType.PAGE;
        if (!bool) this.pageChangeEvent = null;
        return bool;
      }
    },
    _virtual: true,
    virtual: {
      tooltip: CC_DEV && '是否为虚拟列表（动态列表）',
      get: function get() {
        return this._virtual;
      },
      set: function set(val) {
        if (val != null) this._virtual = val;

        if (!CC_DEV && this._numItems != 0) {
          this._onScrolling();
        }
      }
    },
    cyclic: {
      "default": false,
      tooltip: CC_DEV && '是否为循环列表',
      visible: function visible() {
        var val = this.virtual && this.slideMode == SlideType.NORMAL;
        if (!val) this.cyclic = false;
        return val;
      }
    },
    lackCenter: {
      "default": false,
      tooltip: CC_DEV && 'Item数量不足以填满Content时，是否居中显示Item（不支持Grid布局）',
      visible: function visible() {
        return this.virtual;
      }
    },
    lackSlide: {
      "default": false,
      tooltip: CC_DEV && 'Item数量不足以填满Content时，是否可滑动',
      visible: function visible() {
        var val = this.virtual && !this.lackCenter;
        if (!val) this.lackSlide = false;
        return val;
      }
    },
    _updateRate: 0,
    updateRate: {
      type: cc.Integer,
      range: [0, 6, 1],
      tooltip: CC_DEV && '刷新频率（值越大刷新频率越低、性能越高）',
      slide: true,
      get: function get() {
        return this._updateRate;
      },
      set: function set(val) {
        if (val >= 0 && val <= 6) {
          this._updateRate = val;
        }
      }
    },
    frameByFrameRenderNum: {
      "default": 0,
      type: cc.Integer,
      range: [0, 12, 1],
      tooltip: CC_DEV && '逐帧渲染时，每帧渲染的Item数量（<=0时关闭分帧渲染）',
      slide: true
    },
    renderEvent: {
      "default": null,
      type: cc.Component.EventHandler,
      tooltip: CC_DEV && '渲染事件（渲染器）'
    },
    selectedMode: {
      "default": SelectedType.NONE,
      type: SelectedType,
      tooltip: CC_DEV && '选择模式'
    },
    repeatEventSingle: {
      "default": false,
      tooltip: CC_DEV && '是否重复响应单选事件',
      visible: function visible() {
        return this.selectedMode == SelectedType.SINGLE;
      }
    },
    selectedEvent: {
      "default": null,
      type: cc.Component.EventHandler,
      tooltip: CC_DEV && '触发选择事件',
      visible: function visible() {
        var bool = this.selectedMode > 0;
        if (!bool) this.selectedEvent = null;
        return bool;
      }
    },
    _selectedId: -1,
    selectedId: {
      visible: false,
      get: function get() {
        return this._selectedId;
      },
      set: function set(val) {
        var t = this;
        var item;

        switch (t.selectedMode) {
          case SelectedType.SINGLE:
            {
              if (!t.repeatEventSingle && val == t._selectedId) return;
              item = t.getItemByListId(val); // if (!item && val >= 0)
              //     return;

              if (t._selectedId >= 0) t._lastSelectedId = t._selectedId;else //如果＜0则取消选择，把_lastSelectedId也置空吧，如果以后有特殊需求再改吧。
                t._lastSelectedId = null;
              t._selectedId = val;
              if (item) item.listItem.selected = true;

              if (t._lastSelectedId >= 0 && t._lastSelectedId != t._selectedId) {
                var lastItem = t.getItemByListId(t._lastSelectedId);

                if (lastItem) {
                  lastItem.listItem.selected = false;
                }
              }

              if (t.selectedEvent) {
                cc.Component.EventHandler.emitEvents([t.selectedEvent], item, val % this._actualNumItems, t._lastSelectedId % this._actualNumItems);
              }

              break;
            }

          case SelectedType.MULT:
            {
              item = t.getItemByListId(val);
              if (!item) return;
              if (t._selectedId >= 0) t._lastSelectedId = t._selectedId;
              t._selectedId = val;
              var bool = !item.listItem.selected;
              item.listItem.selected = bool;
              var sub = t.multSelected.indexOf(val);

              if (bool && sub < 0) {
                t.multSelected.push(val);
              } else if (!bool && sub >= 0) {
                t.multSelected.splice(sub, 1);
              }

              if (t.selectedEvent) {
                cc.Component.EventHandler.emitEvents([t.selectedEvent], item, val % this._actualNumItems, t._lastSelectedId % this._actualNumItems, bool);
              }

              break;
            }
        }
      }
    },
    _numItems: {
      "default": 0,
      serializable: false
    },
    numItems: {
      visible: false,
      get: function get() {
        return this._actualNumItems;
      },
      set: function set(val) {
        var t = this;
        if (!t.checkInited()) return;

        if (val == null || val < 0) {
          cc.error('numItems set the wrong::', val);
          return;
        }

        t._actualNumItems = t._numItems = val;
        t._forceUpdate = true;

        if (t._virtual) {
          t._resizeContent();

          if (t.cyclic) {
            t._numItems = t._cyclicNum * t._numItems;
          }

          t._onScrolling();

          if (!t.frameByFrameRenderNum && t.slideMode == SlideType.PAGE) t.curPageNum = t.nearestListId;
        } else {
          var layout = t.content.getComponent(cc.Layout);

          if (layout) {
            layout.enabled = true;
          }

          t._delRedundantItem();

          t.firstListId = 0;

          if (t.frameByFrameRenderNum > 0) {
            //先渲染几个出来
            var len = t.frameByFrameRenderNum > t._numItems ? t._numItems : t.frameByFrameRenderNum;

            for (var n = 0; n < len; n++) {
              t._createOrUpdateItem2(n);
            }

            if (t.frameByFrameRenderNum < t._numItems) {
              t._updateCounter = t.frameByFrameRenderNum;
              t._updateDone = false;
            }
          } else {
            for (var _n = 0; _n < val; _n++) {
              t._createOrUpdateItem2(_n);
            }

            t.displayItemNum = val;
          }
        }
      }
    }
  },
  onLoad: function onLoad() {
    this._init();
  },
  onDestroy: function onDestroy() {
    if (this._itemTmp && this._itemTmp.isValid) this._itemTmp.destroy(); // let total = this._pool.size();

    while (this._pool.size()) {
      var node = this._pool.get();

      node.destroy();
    } // if (total)
    //     cc.log('-----------------' + this.node.name + '<List> destroy node total num. =>', total);

  },
  onEnable: function onEnable() {
    // if (!CC_EDITOR)
    this._registerEvent();

    this._init();
  },
  onDisable: function onDisable() {
    // if (!CC_EDITOR)
    this._unregisterEvent();
  },
  //注册事件
  _registerEvent: function _registerEvent() {
    var t = this;
    t.node.on(cc.Node.EventType.TOUCH_START, t._onTouchStart, t, true);
    t.node.on('touch-up', t._onTouchUp, t, true);
    t.node.on(cc.Node.EventType.TOUCH_CANCEL, t._onTouchCancelled, t, true);
    t.node.on('scroll-began', t._onScrollBegan, t, true);
    t.node.on('scroll-ended', t._onScrollEnded, t, true);
    t.node.on('scrolling', t._onScrolling, t, true);
    t.node.on(cc.Node.EventType.SIZE_CHANGED, t._onSizeChanged, t);
  },
  //卸载事件
  _unregisterEvent: function _unregisterEvent() {
    var t = this;
    t.node.off(cc.Node.EventType.TOUCH_START, t._onTouchStart, t, true);
    t.node.off('touch-up', t._onTouchUp, t, true);
    t.node.off(cc.Node.EventType.TOUCH_CANCEL, t._onTouchCancelled, t, true);
    t.node.off('scroll-began', t._onScrollBegan, t, true);
    t.node.off('scroll-ended', t._onScrollEnded, t, true);
    t.node.off('scrolling', t._onScrolling, t, true);
    t.node.off(cc.Node.EventType.SIZE_CHANGED, t._onSizeChanged, t);
  },
  //初始化各种..
  _init: function _init() {
    var t = this;
    if (t._inited) return;
    t._scrollView = t.node.getComponent(cc.ScrollView);
    t.content = t._scrollView.content;

    if (!t.content) {
      cc.error(t.node.name + "'s cc.ScrollView unset content!");
      return;
    }

    t._layout = t.content.getComponent(cc.Layout);
    t._align = t._layout.type; //排列模式

    t._resizeMode = t._layout.resizeMode; //自适应模式

    t._startAxis = t._layout.startAxis;
    t._topGap = t._layout.paddingTop; //顶边距

    t._rightGap = t._layout.paddingRight; //右边距

    t._bottomGap = t._layout.paddingBottom; //底边距

    t._leftGap = t._layout.paddingLeft; //左边距

    t._columnGap = t._layout.spacingX; //列距

    t._lineGap = t._layout.spacingY; //行距

    t._colLineNum; //列数或行数（非GRID模式则=1，表示单列或单行）;

    t._verticalDir = t._layout.verticalDirection; //垂直排列子节点的方向

    t._horizontalDir = t._layout.horizontalDirection; //水平排列子节点的方向

    t.setTemplateItem(cc.instantiate(t.templateType == TemplateType.PREFAB ? t.tmpPrefab : t.tmpNode));
    if (t._slideMode == SlideType.ADHERING || t._slideMode == SlideType.PAGE) //特定的滑动模式需要关闭惯性
      t._scrollView.inertia = false;
    if (!t.virtual) // lackCenter 仅支持 Virtual 模式
      t.lackCenter = false;
    t._lastDisplayData = []; //最后一次刷新的数据

    t.displayData = []; //当前数据

    t._pool = new cc.NodePool(); //这是个池子..

    t._forceUpdate = false; //是否强制更新

    t._updateCounter = 0; //当前分帧渲染帧数

    t._updateDone = true; //分帧渲染是否完成

    t.curPageNum = 0; //当前页数

    if (t.cyclic) {
      // 如果是循环列表，覆写一些cc.ScrollView的函数
      t._scrollView._processAutoScrolling = this._processAutoScrolling.bind(t);

      t._scrollView._startBounceBackIfNeeded = function () {
        return false;
      }; // t._scrollView._scrollChildren = function () {
      //     return false;
      // }

    }

    switch (t._align) {
      case cc.Layout.Type.HORIZONTAL:
        {
          switch (t._horizontalDir) {
            case cc.Layout.HorizontalDirection.LEFT_TO_RIGHT:
              t._alignCalcType = 1;
              break;

            case cc.Layout.HorizontalDirection.RIGHT_TO_LEFT:
              t._alignCalcType = 2;
              break;
          }

          break;
        }

      case cc.Layout.Type.VERTICAL:
        {
          switch (t._verticalDir) {
            case cc.Layout.VerticalDirection.TOP_TO_BOTTOM:
              t._alignCalcType = 3;
              break;

            case cc.Layout.VerticalDirection.BOTTOM_TO_TOP:
              t._alignCalcType = 4;
              break;
          }

          break;
        }

      case cc.Layout.Type.GRID:
        {
          switch (t._startAxis) {
            case cc.Layout.AxisDirection.HORIZONTAL:
              switch (t._verticalDir) {
                case cc.Layout.VerticalDirection.TOP_TO_BOTTOM:
                  t._alignCalcType = 3;
                  break;

                case cc.Layout.VerticalDirection.BOTTOM_TO_TOP:
                  t._alignCalcType = 4;
                  break;
              }

              break;

            case cc.Layout.AxisDirection.VERTICAL:
              switch (t._horizontalDir) {
                case cc.Layout.HorizontalDirection.LEFT_TO_RIGHT:
                  t._alignCalcType = 1;
                  break;

                case cc.Layout.HorizontalDirection.RIGHT_TO_LEFT:
                  t._alignCalcType = 2;
                  break;
              }

              break;
          }

          break;
        }
    } // 清空 content


    t.content.children.forEach(function (child) {
      child.removeFromParent();
      if (child.isValid) child.destroy();
    });
    t._inited = true;
  },

  /**
   * 为了实现循环列表，必须覆写cc.ScrollView的某些函数
   * @param {Number} dt
   */
  _processAutoScrolling: function _processAutoScrolling(dt) {
    // let isAutoScrollBrake = this._scrollView._isNecessaryAutoScrollBrake();
    var brakingFactor = 1;
    this._scrollView._autoScrollAccumulatedTime += dt * (1 / brakingFactor);
    var percentage = Math.min(1, this._scrollView._autoScrollAccumulatedTime / this._scrollView._autoScrollTotalTime);

    if (this._scrollView._autoScrollAttenuate) {
      var time = percentage - 1;
      percentage = time * time * time * time * time + 1;
    }

    var newPosition = this._scrollView._autoScrollStartPosition.add(this._scrollView._autoScrollTargetDelta.mul(percentage));

    var EPSILON = this._scrollView.getScrollEndedEventTiming();

    var reachedEnd = Math.abs(percentage - 1) <= EPSILON; // cc.log(reachedEnd, Math.abs(percentage - 1), EPSILON)

    var fireEvent = Math.abs(percentage - 1) <= this._scrollView.getScrollEndedEventTiming();

    if (fireEvent && !this._scrollView._isScrollEndedWithThresholdEventFired) {
      this._scrollView._dispatchEvent('scroll-ended-with-threshold');

      this._scrollView._isScrollEndedWithThresholdEventFired = true;
    } // if (this._scrollView.elastic && !reachedEnd) {
    //     let brakeOffsetPosition = newPosition.sub(this._scrollView._autoScrollBrakingStartPosition);
    //     if (isAutoScrollBrake) {
    //         brakeOffsetPosition = brakeOffsetPosition.mul(brakingFactor);
    //     }
    //     newPosition = this._scrollView._autoScrollBrakingStartPosition.add(brakeOffsetPosition);
    // } else {
    //     let moveDelta = newPosition.sub(this._scrollView.getContentPosition());
    //     let outOfBoundary = this._scrollView._getHowMuchOutOfBoundary(moveDelta);
    //     if (!outOfBoundary.fuzzyEquals(cc.v2(0, 0), EPSILON)) {
    //         newPosition = newPosition.add(outOfBoundary);
    //         reachedEnd = true;
    //     }
    // }


    if (reachedEnd) {
      this._scrollView._autoScrolling = false;
    }

    var deltaMove = newPosition.sub(this._scrollView.getContentPosition()); // cc.log(deltaMove)

    this._scrollView._moveContent(this._scrollView._clampDelta(deltaMove), reachedEnd);

    this._scrollView._dispatchEvent('scrolling'); // scollTo API controll move


    if (!this._scrollView._autoScrolling) {
      this._scrollView._isBouncing = false;
      this._scrollView._scrolling = false;

      this._scrollView._dispatchEvent('scroll-ended');
    }
  },
  //设置模板Item
  setTemplateItem: function setTemplateItem(item) {
    if (!item) return;
    var t = this;
    t._itemTmp = item;
    if (t._resizeMode == cc.Layout.ResizeMode.CHILDREN) t._itemSize = t._layout.cellSize;else t._itemSize = new cc.size(item.width, item.height); //获取ListItem，如果没有就取消选择模式

    var com = item.getComponent(ListItem);
    var remove = false;
    if (!com) remove = true;

    if (com) {
      if (!com._btnCom && !item.getComponent(cc.Button)) {
        remove = true;
      }
    }

    if (remove) {
      t.selectedMode = SelectedType.NONE;
    }

    com = item.getComponent(cc.Widget);

    if (com && com.enabled) {
      t._needUpdateWidget = true;
    }

    if (t.selectedMode == SelectedType.MULT) t.multSelected = [];

    switch (t._align) {
      case cc.Layout.Type.HORIZONTAL:
        t._colLineNum = 1;
        t._sizeType = false;
        break;

      case cc.Layout.Type.VERTICAL:
        t._colLineNum = 1;
        t._sizeType = true;
        break;

      case cc.Layout.Type.GRID:
        switch (t._startAxis) {
          case cc.Layout.AxisDirection.HORIZONTAL:
            //计算列数
            var trimW = t.content.width - t._leftGap - t._rightGap;
            t._colLineNum = Math.floor((trimW + t._columnGap) / (t._itemSize.width + t._columnGap));
            t._sizeType = true;
            break;

          case cc.Layout.AxisDirection.VERTICAL:
            //计算行数
            var trimH = t.content.height - t._topGap - t._bottomGap;
            t._colLineNum = Math.floor((trimH + t._lineGap) / (t._itemSize.height + t._lineGap));
            t._sizeType = false;
            break;
        }

        break;
    }
  },

  /**
   * 检查是否初始化
   * @param {Boolean} printLog 是否打印错误信息
   * @returns
   */
  checkInited: function checkInited(printLog) {
    printLog = printLog == null ? true : printLog;

    if (!this._inited) {
      if (printLog) {
        cc.error('List initialization not completed!');
      }

      return false;
    }

    return true;
  },
  //禁用 Layout 组件，自行计算 Content Size
  _resizeContent: function _resizeContent() {
    var t = this;
    var result;

    switch (t._align) {
      case cc.Layout.Type.HORIZONTAL:
        {
          if (t._customSize) {
            var fixed = t._getFixedSize();

            result = t._leftGap + fixed.val + t._itemSize.width * (t._numItems - fixed.count) + t._columnGap * (t._numItems - 1) + t._rightGap;
          } else {
            result = t._leftGap + t._itemSize.width * t._numItems + t._columnGap * (t._numItems - 1) + t._rightGap;
          }

          break;
        }

      case cc.Layout.Type.VERTICAL:
        {
          if (t._customSize) {
            var _fixed = t._getFixedSize();

            result = t._topGap + _fixed.val + t._itemSize.height * (t._numItems - _fixed.count) + t._lineGap * (t._numItems - 1) + t._bottomGap;
          } else {
            result = t._topGap + t._itemSize.height * t._numItems + t._lineGap * (t._numItems - 1) + t._bottomGap;
          }

          break;
        }

      case cc.Layout.Type.GRID:
        {
          //网格模式不支持居中
          if (t.lackCenter) t.lackCenter = false;

          switch (t._startAxis) {
            case cc.Layout.AxisDirection.HORIZONTAL:
              var lineNum = Math.ceil(t._numItems / t._colLineNum);
              result = t._topGap + t._itemSize.height * lineNum + t._lineGap * (lineNum - 1) + t._bottomGap;
              break;

            case cc.Layout.AxisDirection.VERTICAL:
              var colNum = Math.ceil(t._numItems / t._colLineNum);
              result = t._leftGap + t._itemSize.width * colNum + t._columnGap * (colNum - 1) + t._rightGap;
              break;
          }

          break;
        }
    }

    var layout = t.content.getComponent(cc.Layout);
    if (layout) layout.enabled = false;
    t._allItemSize = result;
    t._allItemSizeNoEdge = t._allItemSize - (t._sizeType ? t._topGap + t._bottomGap : t._leftGap + t._rightGap);

    if (t.cyclic) {
      var totalSize = t._sizeType ? t.node.height : t.node.width;
      t._cyclicPos1 = 0;
      totalSize -= t._cyclicPos1;
      t._cyclicNum = Math.ceil(totalSize / t._allItemSizeNoEdge) + 1;
      var spacing = t._sizeType ? t._lineGap : t._columnGap;
      t._cyclicPos2 = t._cyclicPos1 + t._allItemSizeNoEdge + spacing;
      t._cyclicAllItemSize = t._allItemSize + t._allItemSizeNoEdge * (t._cyclicNum - 1) + spacing * (t._cyclicNum - 1);
      t._cycilcAllItemSizeNoEdge = t._allItemSizeNoEdge * t._cyclicNum;
      t._cycilcAllItemSizeNoEdge += spacing * (t._cyclicNum - 1); // cc.log('_cyclicNum ->', t._cyclicNum, t._allItemSizeNoEdge, t._allItemSize, t._cyclicPos1, t._cyclicPos2);
    }

    t._lack = !t.cyclic && t._allItemSize < (t._sizeType ? t.node.height : t.node.width);
    var slideOffset = (!t._lack || !t.lackCenter) && t.lackSlide ? 0 : .1;
    var targetWH = t._lack ? (t._sizeType ? t.node.height : t.node.width) - slideOffset : t.cyclic ? t._cyclicAllItemSize : t._allItemSize;
    if (targetWH < 0) targetWH = 0;

    if (t._sizeType) {
      t.content.height = targetWH;
    } else {
      t.content.width = targetWH;
    } // cc.log('_resizeContent()  numItems =', t._numItems, '，content =', t.content);

  },
  //滚动进行时...
  _onScrolling: function _onScrolling(ev) {
    if (this.frameCount == null) this.frameCount = this._updateRate;

    if (!this._forceUpdate && ev && ev.type != 'scroll-ended' && this.frameCount > 0) {
      this.frameCount--;
      return;
    } else this.frameCount = this._updateRate;

    if (this._aniDelRuning) return; //循环列表处理

    if (this.cyclic) {
      var scrollPos = this.content.getPosition();
      scrollPos = this._sizeType ? scrollPos.y : scrollPos.x;
      var addVal = this._allItemSizeNoEdge + (this._sizeType ? this._lineGap : this._columnGap);
      var add = this._sizeType ? cc.v2(0, addVal) : cc.v2(addVal, 0);

      switch (this._alignCalcType) {
        case 1:
          //单行HORIZONTAL（LEFT_TO_RIGHT）、网格VERTICAL（LEFT_TO_RIGHT）
          if (scrollPos > -this._cyclicPos1) {
            this.content.x = -this._cyclicPos2;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.sub(add);
            } // if (this._beganPos) {
            //     this._beganPos += add;
            // }

          } else if (scrollPos < -this._cyclicPos2) {
            this.content.x = -this._cyclicPos1;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.add(add);
            } // if (this._beganPos) {
            //     this._beganPos -= add;
            // }

          }

          break;

        case 2:
          //单行HORIZONTAL（RIGHT_TO_LEFT）、网格VERTICAL（RIGHT_TO_LEFT）
          if (scrollPos < this._cyclicPos1) {
            this.content.x = this._cyclicPos2;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.add(add);
            }
          } else if (scrollPos > this._cyclicPos2) {
            this.content.x = this._cyclicPos1;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.sub(add);
            }
          }

          break;

        case 3:
          //单列VERTICAL（TOP_TO_BOTTOM）、网格HORIZONTAL（TOP_TO_BOTTOM）
          if (scrollPos < this._cyclicPos1) {
            this.content.y = this._cyclicPos2;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.add(add);
            }
          } else if (scrollPos > this._cyclicPos2) {
            this.content.y = this._cyclicPos1;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.sub(add);
            }
          }

          break;

        case 4:
          //单列VERTICAL（BOTTOM_TO_TOP）、网格HORIZONTAL（BOTTOM_TO_TOP）
          if (scrollPos > -this._cyclicPos1) {
            this.content.y = -this._cyclicPos2;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.sub(add);
            }
          } else if (scrollPos < -this._cyclicPos2) {
            this.content.y = -this._cyclicPos1;

            if (this._scrollView.isAutoScrolling()) {
              this._scrollView._autoScrollStartPosition = this._scrollView._autoScrollStartPosition.add(add);
            }
          }

          break;
      }
    }

    this._calcViewPos();

    var vTop, vRight, vBottom, vLeft;

    if (this._sizeType) {
      vTop = this.viewTop;
      vBottom = this.viewBottom;
    } else {
      vRight = this.viewRight;
      vLeft = this.viewLeft;
    }

    if (this._virtual) {
      this.displayData = [];
      var itemPos;
      var curId = 0;
      var endId = this._numItems - 1;

      if (this._customSize) {
        var breakFor = false; //如果该item的位置在可视区域内，就推入displayData

        for (; curId <= endId && !breakFor; curId++) {
          itemPos = this._calcItemPos(curId);

          switch (this._align) {
            case cc.Layout.Type.HORIZONTAL:
              if (itemPos.right >= vLeft && itemPos.left <= vRight) {
                this.displayData.push(itemPos);
              } else if (curId != 0 && this.displayData.length > 0) {
                breakFor = true;
              }

              break;

            case cc.Layout.Type.VERTICAL:
              if (itemPos.bottom <= vTop && itemPos.top >= vBottom) {
                this.displayData.push(itemPos);
              } else if (curId != 0 && this.displayData.length > 0) {
                breakFor = true;
              }

              break;

            case cc.Layout.Type.GRID:
              switch (this._startAxis) {
                case cc.Layout.AxisDirection.HORIZONTAL:
                  if (itemPos.bottom <= vTop && itemPos.top >= vBottom) {
                    this.displayData.push(itemPos);
                  } else if (curId != 0 && this.displayData.length > 0) {
                    breakFor = true;
                  }

                  break;

                case cc.Layout.AxisDirection.VERTICAL:
                  if (itemPos.right >= vLeft && itemPos.left <= vRight) {
                    this.displayData.push(itemPos);
                  } else if (curId != 0 && this.displayData.length > 0) {
                    breakFor = true;
                  }

                  break;
              }

              break;
          }
        }
      } else {
        var ww = this._itemSize.width + this._columnGap;
        var hh = this._itemSize.height + this._lineGap;

        switch (this._alignCalcType) {
          case 1:
            //单行HORIZONTAL（LEFT_TO_RIGHT）、网格VERTICAL（LEFT_TO_RIGHT）
            curId = (vLeft + this._leftGap) / ww;
            endId = (vRight + this._rightGap) / ww;
            break;

          case 2:
            //单行HORIZONTAL（RIGHT_TO_LEFT）、网格VERTICAL（RIGHT_TO_LEFT）
            curId = (-vRight - this._rightGap) / ww;
            endId = (-vLeft - this._leftGap) / ww;
            break;

          case 3:
            //单列VERTICAL（TOP_TO_BOTTOM）、网格HORIZONTAL（TOP_TO_BOTTOM）
            curId = (-vTop - this._topGap) / hh;
            endId = (-vBottom - this._bottomGap) / hh;
            break;

          case 4:
            //单列VERTICAL（BOTTOM_TO_TOP）、网格HORIZONTAL（BOTTOM_TO_TOP）
            curId = (vBottom + this._bottomGap) / hh;
            endId = (vTop + this._topGap) / hh;
            break;
        }

        curId = Math.floor(curId) * this._colLineNum;
        endId = Math.ceil(endId) * this._colLineNum;
        endId--;
        if (curId < 0) curId = 0;
        if (endId >= this._numItems) endId = this._numItems - 1; // cc.log(curId, endId);

        for (; curId <= endId; curId++) {
          this.displayData.push(this._calcItemPos(curId));
        }
      }

      if (this.displayData.length <= 0 || !this._numItems) {
        //if none, delete all.
        this._lastDisplayData = [];

        this._delRedundantItem();

        return;
      }

      this.firstListId = this.displayData[0].id;
      this.displayItemNum = this.displayData.length;
      var len = this._lastDisplayData.length; //判断数据是否与当前相同，如果相同，return。
      //因List的显示数据是有序的，所以只需要判断数组长度是否相等，以及头、尾两个元素是否相等即可。

      if (this._forceUpdate || this.displayItemNum != len || this.firstListId != this._lastDisplayData[0] || this.displayData[this.displayItemNum - 1].id != this._lastDisplayData[len - 1]) {
        this._lastDisplayData = [];

        if (this.frameByFrameRenderNum > 0) {
          //逐帧渲染
          if (this._numItems > 0) {
            if (!this._updateDone) {
              this._doneAfterUpdate = true;
            } else {
              this._updateCounter = 0;
            }

            this._updateDone = false;
          } else {
            this._delRedundantItem();

            this._updateCounter = 0;
            this._updateDone = true;
          } // cc.log('List Display Data I::', this.displayData);

        } else {
          //直接渲染
          // cc.log('List Display Data II::', this.displayData);
          for (var c = 0; c < this.displayItemNum; c++) {
            this._createOrUpdateItem(this.displayData[c]);
          }

          this._delRedundantItem();

          this._forceUpdate = false;
        }
      }

      this._calcNearestItem();
    }
  },
  //计算View位置
  _calcViewPos: function _calcViewPos() {
    var scrollPos = this.content.getPosition();

    switch (this._alignCalcType) {
      case 1:
        //单行HORIZONTAL（LEFT_TO_RIGHT）、网格VERTICAL（LEFT_TO_RIGHT）
        this.elasticLeft = scrollPos.x > 0 ? scrollPos.x : 0;
        this.viewLeft = (scrollPos.x < 0 ? -scrollPos.x : 0) - this.elasticLeft;
        this.viewRight = this.viewLeft + this.node.width;
        this.elasticRight = this.viewRight > this.content.width ? Math.abs(this.viewRight - this.content.width) : 0;
        this.viewRight += this.elasticRight; // cc.log(this.elasticLeft, this.elasticRight, this.viewLeft, this.viewRight);

        break;

      case 2:
        //单行HORIZONTAL（RIGHT_TO_LEFT）、网格VERTICAL（RIGHT_TO_LEFT）
        this.elasticRight = scrollPos.x < 0 ? -scrollPos.x : 0;
        this.viewRight = (scrollPos.x > 0 ? -scrollPos.x : 0) + this.elasticRight;
        this.viewLeft = this.viewRight - this.node.width;
        this.elasticLeft = this.viewLeft < -this.content.width ? Math.abs(this.viewLeft + this.content.width) : 0;
        this.viewLeft -= this.elasticLeft; // cc.log(this.elasticLeft, this.elasticRight, this.viewLeft, this.viewRight);

        break;

      case 3:
        //单列VERTICAL（TOP_TO_BOTTOM）、网格HORIZONTAL（TOP_TO_BOTTOM）
        this.elasticTop = scrollPos.y < 0 ? Math.abs(scrollPos.y) : 0;
        this.viewTop = (scrollPos.y > 0 ? -scrollPos.y : 0) + this.elasticTop;
        this.viewBottom = this.viewTop - this.node.height;
        this.elasticBottom = this.viewBottom < -this.content.height ? Math.abs(this.viewBottom + this.content.height) : 0;
        this.viewBottom += this.elasticBottom; // cc.log(this.elasticTop, this.elasticBottom, this.viewTop, this.viewBottom);

        break;

      case 4:
        //单列VERTICAL（BOTTOM_TO_TOP）、网格HORIZONTAL（BOTTOM_TO_TOP）
        this.elasticBottom = scrollPos.y > 0 ? Math.abs(scrollPos.y) : 0;
        this.viewBottom = (scrollPos.y < 0 ? -scrollPos.y : 0) - this.elasticBottom;
        this.viewTop = this.viewBottom + this.node.height;
        this.elasticTop = this.viewTop > this.content.height ? Math.abs(this.viewTop - this.content.height) : 0;
        this.viewTop -= this.elasticTop; // cc.log(this.elasticTop, this.elasticBottom, this.viewTop, this.viewBottom);

        break;
    }
  },
  //计算位置 根据id
  _calcItemPos: function _calcItemPos(id) {
    var width, height, top, bottom, left, right, itemX, itemY;

    switch (this._align) {
      case cc.Layout.Type.HORIZONTAL:
        switch (this._horizontalDir) {
          case cc.Layout.HorizontalDirection.LEFT_TO_RIGHT:
            {
              if (this._customSize) {
                var fixed = this._getFixedSize(id);

                left = this._leftGap + (this._itemSize.width + this._columnGap) * (id - fixed.count) + (fixed.val + this._columnGap * fixed.count);
                var cs = this._customSize[id];
                width = cs > 0 ? cs : this._itemSize.width;
              } else {
                left = this._leftGap + (this._itemSize.width + this._columnGap) * id;
                width = this._itemSize.width;
              }

              right = left + width;

              if (this.lackCenter) {
                var offset = this.content.width / 2 - this._allItemSizeNoEdge / 2;
                left += offset;
                right += offset;
              }

              return {
                id: id,
                left: left,
                right: right,
                x: left + this._itemTmp.anchorX * width,
                y: this._itemTmp.y
              };
            }

          case cc.Layout.HorizontalDirection.RIGHT_TO_LEFT:
            {
              if (this._customSize) {
                var _fixed2 = this._getFixedSize(id);

                right = -this._rightGap - (this._itemSize.width + this._columnGap) * (id - _fixed2.count) - (_fixed2.val + this._columnGap * _fixed2.count);
                var _cs = this._customSize[id];
                width = _cs > 0 ? _cs : this._itemSize.width;
              } else {
                right = -this._rightGap - (this._itemSize.width + this._columnGap) * id;
                width = this._itemSize.width;
              }

              left = right - width;

              if (this.lackCenter) {
                var _offset = this.content.width / 2 - this._allItemSizeNoEdge / 2;

                left -= _offset;
                right -= _offset;
              }

              return {
                id: id,
                right: right,
                left: left,
                x: left + this._itemTmp.anchorX * width,
                y: this._itemTmp.y
              };
            }
        }

        break;

      case cc.Layout.Type.VERTICAL:
        {
          switch (this._verticalDir) {
            case cc.Layout.VerticalDirection.TOP_TO_BOTTOM:
              {
                if (this._customSize) {
                  var _fixed3 = this._getFixedSize(id);

                  top = -this._topGap - (this._itemSize.height + this._lineGap) * (id - _fixed3.count) - (_fixed3.val + this._lineGap * _fixed3.count);
                  var _cs2 = this._customSize[id];
                  height = _cs2 > 0 ? _cs2 : this._itemSize.height;
                  bottom = top - height;
                } else {
                  top = -this._topGap - (this._itemSize.height + this._lineGap) * id;
                  height = this._itemSize.height;
                }

                bottom = top - height;

                if (this.lackCenter) {
                  var _offset2 = this.content.height / 2 - this._allItemSizeNoEdge / 2;

                  top -= _offset2;
                  bottom -= _offset2;
                } // cc.log({
                //     id: id,
                //     top: top,
                //     bottom: bottom,
                //     x: this._itemTmp.x,
                //     y: bottom + (this._itemTmp.anchorY * height),
                // });


                return {
                  id: id,
                  top: top,
                  bottom: bottom,
                  x: this._itemTmp.x,
                  y: bottom + this._itemTmp.anchorY * height
                };
              }

            case cc.Layout.VerticalDirection.BOTTOM_TO_TOP:
              {
                if (this._customSize) {
                  var _fixed4 = this._getFixedSize(id);

                  bottom = this._bottomGap + (this._itemSize.height + this._lineGap) * (id - _fixed4.count) + (_fixed4.val + this._lineGap * _fixed4.count);
                  var _cs3 = this._customSize[id];
                  height = _cs3 > 0 ? _cs3 : this._itemSize.height;
                } else {
                  bottom = this._bottomGap + (this._itemSize.height + this._lineGap) * id;
                  height = this._itemSize.height;
                }

                top = bottom + height;

                if (this.lackCenter) {
                  var _offset3 = this.content.height / 2 - this._allItemSizeNoEdge / 2;

                  top += _offset3;
                  bottom += _offset3;
                }

                return {
                  id: id,
                  top: top,
                  bottom: bottom,
                  x: this._itemTmp.x,
                  y: bottom + this._itemTmp.anchorY * height
                };
                break;
              }
          }
        }

      case cc.Layout.Type.GRID:
        {
          var colLine = Math.floor(id / this._colLineNum);

          switch (this._startAxis) {
            case cc.Layout.AxisDirection.HORIZONTAL:
              {
                switch (this._verticalDir) {
                  case cc.Layout.VerticalDirection.TOP_TO_BOTTOM:
                    {
                      top = -this._topGap - (this._itemSize.height + this._lineGap) * colLine;
                      bottom = top - this._itemSize.height;
                      itemY = bottom + this._itemTmp.anchorY * this._itemSize.height;
                      break;
                    }

                  case cc.Layout.VerticalDirection.BOTTOM_TO_TOP:
                    {
                      bottom = this._bottomGap + (this._itemSize.height + this._lineGap) * colLine;
                      top = bottom + this._itemSize.height;
                      itemY = bottom + this._itemTmp.anchorY * this._itemSize.height;
                      break;
                    }
                }

                itemX = this._leftGap + id % this._colLineNum * (this._itemSize.width + this._columnGap);

                switch (this._horizontalDir) {
                  case cc.Layout.HorizontalDirection.LEFT_TO_RIGHT:
                    {
                      itemX += this._itemTmp.anchorX * this._itemSize.width;
                      itemX -= this.content.anchorX * this.content.width;
                      break;
                    }

                  case cc.Layout.HorizontalDirection.RIGHT_TO_LEFT:
                    {
                      itemX += (1 - this._itemTmp.anchorX) * this._itemSize.width;
                      itemX -= (1 - this.content.anchorX) * this.content.width;
                      itemX *= -1;
                      break;
                    }
                }

                return {
                  id: id,
                  top: top,
                  bottom: bottom,
                  x: itemX,
                  y: itemY
                };
              }

            case cc.Layout.AxisDirection.VERTICAL:
              {
                switch (this._horizontalDir) {
                  case cc.Layout.HorizontalDirection.LEFT_TO_RIGHT:
                    {
                      left = this._leftGap + (this._itemSize.width + this._columnGap) * colLine;
                      right = left + this._itemSize.width;
                      itemX = left + this._itemTmp.anchorX * this._itemSize.width;
                      itemX -= this.content.anchorX * this.content.width;
                      break;
                    }

                  case cc.Layout.HorizontalDirection.RIGHT_TO_LEFT:
                    {
                      right = -this._rightGap - (this._itemSize.width + this._columnGap) * colLine;
                      left = right - this._itemSize.width;
                      itemX = left + this._itemTmp.anchorX * this._itemSize.width;
                      itemX += (1 - this.content.anchorX) * this.content.width;
                      break;
                    }
                }

                itemY = -this._topGap - id % this._colLineNum * (this._itemSize.height + this._lineGap);

                switch (this._verticalDir) {
                  case cc.Layout.VerticalDirection.TOP_TO_BOTTOM:
                    {
                      itemY -= (1 - this._itemTmp.anchorY) * this._itemSize.height;
                      itemY += (1 - this.content.anchorY) * this.content.height;
                      break;
                    }

                  case cc.Layout.VerticalDirection.BOTTOM_TO_TOP:
                    {
                      itemY -= this._itemTmp.anchorY * this._itemSize.height;
                      itemY += this.content.anchorY * this.content.height;
                      itemY *= -1;
                      break;
                    }
                }

                return {
                  id: id,
                  left: left,
                  right: right,
                  x: itemX,
                  y: itemY
                };
              }
          }

          break;
        }
    }
  },
  //计算已存在的Item的位置
  _calcExistItemPos: function _calcExistItemPos(id) {
    var item = this.getItemByListId(id);
    if (!item) return null;
    var data = {
      id: id,
      x: item.x,
      y: item.y
    };

    if (this._sizeType) {
      data.top = item.y + item.height * (1 - item.anchorY);
      data.bottom = item.y - item.height * item.anchorY;
    } else {
      data.left = item.x - item.width * item.anchorX;
      data.right = item.x + item.width * (1 - item.anchorX);
    }

    return data;
  },
  //获取Item位置
  getItemPos: function getItemPos(id) {
    if (this._virtual) return this._calcItemPos(id);else {
      if (this.frameByFrameRenderNum) return this._calcItemPos(id);else return this._calcExistItemPos(id);
    }
  },
  //获取固定尺寸
  _getFixedSize: function _getFixedSize(listId) {
    if (!this._customSize) return null;
    if (listId == null) listId = this._numItems;
    var fixed = 0;
    var count = 0;

    for (var id in this._customSize) {
      if (parseInt(id) < listId) {
        fixed += this._customSize[id];
        count++;
      }
    }

    return {
      val: fixed,
      count: count
    };
  },
  //滚动开始时..
  _onScrollBegan: function _onScrollBegan() {
    this._beganPos = this._sizeType ? this.viewTop : this.viewLeft;
  },
  //滚动结束时..
  _onScrollEnded: function _onScrollEnded() {
    var t = this;

    if (t.scrollToListId != null) {
      var item = t.getItemByListId(t.scrollToListId);
      t.scrollToListId = null;

      if (item) {
        item.runAction(new cc.sequence(new cc.scaleTo(.1, 1.06), new cc.scaleTo(.1, 1)));
      }
    }

    t._onScrolling();

    if (t._slideMode == SlideType.ADHERING && !t.adhering) {
      //cc.log(t.adhering, t._scrollView.isAutoScrolling(), t._scrollView.isScrolling());
      t.adhere();
    } else if (t._slideMode == SlideType.PAGE) {
      if (t._beganPos != null) {
        this._pageAdhere();
      } else {
        t.adhere();
      }
    }
  },
  // 触摸时
  _onTouchStart: function _onTouchStart(ev, captureListeners) {
    if (this._scrollView._hasNestedViewGroup(ev, captureListeners)) return;
    var isMe = ev.eventPhase === cc.Event.AT_TARGET && ev.target === this.node;

    if (!isMe) {
      var itemNode = ev.target;

      while (itemNode._listId == null && itemNode.parent) {
        itemNode = itemNode.parent;
      }

      this._scrollItem = itemNode._listId != null ? itemNode : ev.target;
      ;
    }
  },
  //触摸抬起时..
  _onTouchUp: function _onTouchUp() {
    var t = this;
    t._scrollPos = null;

    if (t._slideMode == SlideType.ADHERING) {
      if (t.adhering) t._adheringBarrier = true;
      t.adhere();
    } else if (t._slideMode == SlideType.PAGE) {
      if (t._beganPos != null) {
        t._pageAdhere();
      } else {
        t.adhere();
      }
    }

    this._scrollItem = null;
  },
  _onTouchCancelled: function _onTouchCancelled(ev, captureListeners) {
    var t = this;
    if (t._scrollView._hasNestedViewGroup(ev, captureListeners) || ev.simulate) return;
    t._scrollPos = null;

    if (t._slideMode == SlideType.ADHERING) {
      if (t.adhering) t._adheringBarrier = true;
      t.adhere();
    } else if (t._slideMode == SlideType.PAGE) {
      if (t._beganPos != null) {
        t._pageAdhere();
      } else {
        t.adhere();
      }
    }

    this._scrollItem = null;
  },
  //当尺寸改变
  _onSizeChanged: function _onSizeChanged() {
    if (this.checkInited(false)) this._onScrolling();
  },
  //当Item自适应
  _onItemAdaptive: function _onItemAdaptive(item) {
    var _this = this;

    if (this.checkInited(false)) {
      if (!this._sizeType && item.width != this._itemSize.width || this._sizeType && item.height != this._itemSize.height) {
        if (!this._customSize) this._customSize = {};
        var val = this._sizeType ? item.height : item.width;

        if (this._customSize[item._listId] != val) {
          this._customSize[item._listId] = val;

          this._resizeContent();

          this.content.children.forEach(function (child) {
            _this._updateItemPos(child);
          }); // 如果当前正在运行 scrollTo，肯定会不准确，在这里做修正

          if (!isNaN(this._scrollToListId)) {
            this._scrollPos = null;
            this.unschedule(this._scrollToSo);
            this.scrollTo(this._scrollToListId, Math.max(0, this._scrollToEndTime - new Date().getTime() / 1000));
          }
        }
      }
    }
  },
  //PAGE粘附
  _pageAdhere: function _pageAdhere() {
    var t = this;
    if (!t.cyclic && (t.elasticTop > 0 || t.elasticRight > 0 || t.elasticBottom > 0 || t.elasticLeft > 0)) return;
    var curPos = t._sizeType ? t.viewTop : t.viewLeft;
    var dis = (t._sizeType ? t.node.height : t.node.width) * t.pageDistance;
    var canSkip = Math.abs(t._beganPos - curPos) > dis;

    if (canSkip) {
      var timeInSecond = .5;

      switch (t._alignCalcType) {
        case 1: //单行HORIZONTAL（LEFT_TO_RIGHT）、网格VERTICAL（LEFT_TO_RIGHT）

        case 4:
          //单列VERTICAL（BOTTOM_TO_TOP）、网格HORIZONTAL（BOTTOM_TO_TOP）
          if (t._beganPos > curPos) {
            t.prePage(timeInSecond); // cc.log('_pageAdhere   PPPPPPPPPPPPPPP');
          } else {
            t.nextPage(timeInSecond); // cc.log('_pageAdhere   NNNNNNNNNNNNNNN')
          }

          break;

        case 2: //单行HORIZONTAL（RIGHT_TO_LEFT）、网格VERTICAL（RIGHT_TO_LEFT）

        case 3:
          //单列VERTICAL（TOP_TO_BOTTOM）、网格HORIZONTAL（TOP_TO_BOTTOM）
          if (t._beganPos < curPos) {
            t.prePage(timeInSecond);
          } else {
            t.nextPage(timeInSecond);
          }

          break;
      }
    } else if (t.elasticTop <= 0 && t.elasticRight <= 0 && t.elasticBottom <= 0 && t.elasticLeft <= 0) {
      t.adhere();
    }

    t._beganPos = null;
  },
  //粘附
  adhere: function adhere() {
    var t = this;
    if (!t.checkInited()) return;
    if (t.elasticTop > 0 || t.elasticRight > 0 || t.elasticBottom > 0 || t.elasticLeft > 0) return;
    t.adhering = true; // if (!t._virtual)

    t._calcNearestItem();

    var offset = (t._sizeType ? t._topGap : t._leftGap) / (t._sizeType ? t.node.height : t.node.width);
    var timeInSecond = .7;
    t.scrollTo(t.nearestListId, timeInSecond, offset);
  },
  //Update..
  update: function update() {
    if (this.frameByFrameRenderNum <= 0 || this._updateDone) return; // cc.log(this.displayData.length, this._updateCounter, this.displayData[this._updateCounter]);

    if (this._virtual) {
      var len = this._updateCounter + this.frameByFrameRenderNum > this.displayItemNum ? this.displayItemNum : this._updateCounter + this.frameByFrameRenderNum;

      for (var n = this._updateCounter; n < len; n++) {
        var data = this.displayData[n];
        if (data) this._createOrUpdateItem(data);
      }

      if (this._updateCounter >= this.displayItemNum - 1) {
        //最后一个
        if (this._doneAfterUpdate) {
          this._updateCounter = 0;
          this._updateDone = false;
          if (!this._scrollView.isScrolling()) this._doneAfterUpdate = false;
        } else {
          this._updateDone = true;

          this._delRedundantItem();

          this._forceUpdate = false;

          this._calcNearestItem();

          if (this.slideMode == SlideType.PAGE) this.curPageNum = this.nearestListId;
        }
      } else {
        this._updateCounter += this.frameByFrameRenderNum;
      }
    } else {
      if (this._updateCounter < this._numItems) {
        var _len = this._updateCounter + this.frameByFrameRenderNum > this._numItems ? this._numItems : this._updateCounter + this.frameByFrameRenderNum;

        for (var _n2 = this._updateCounter; _n2 < _len; _n2++) {
          this._createOrUpdateItem2(_n2);
        }

        this._updateCounter += this.frameByFrameRenderNum;
      } else {
        this._updateDone = true;

        this._calcNearestItem();

        if (this.slideMode == SlideType.PAGE) this.curPageNum = this.nearestListId;
      }
    }
  },

  /**
   * 创建或更新Item（虚拟列表用）
   * @param {Object} data 数据
   */
  _createOrUpdateItem: function _createOrUpdateItem(data) {
    var item = this.getItemByListId(data.id);

    if (!item) {
      //如果不存在
      var canGet = this._pool.size() > 0;

      if (canGet) {
        item = this._pool.get(); // cc.log('从池中取出::   旧id =', item._listId, '，新id =', data.id, item);
      } else {
        item = cc.instantiate(this._itemTmp); // cc.log('新建::', data.id, item);
      }

      if (item._listId != data.id) {
        item._listId = data.id;
        item.setContentSize(this._itemSize);
      }

      item.setPosition(new cc.v2(data.x, data.y));

      this._resetItemSize(item);

      this.content.addChild(item);

      if (canGet && this._needUpdateWidget) {
        var widget = item.getComponent(cc.Widget);
        if (widget) widget.updateAlignment();
      }

      item.setSiblingIndex(this.content.childrenCount - 1);
      var listItem = item.getComponent(ListItem);
      item.listItem = listItem;

      if (listItem) {
        listItem._list = this;

        listItem._registerEvent();
      }

      if (this.renderEvent) {
        cc.Component.EventHandler.emitEvents([this.renderEvent], item, data.id % this._actualNumItems);
      }
    } else if (this._forceUpdate && this.renderEvent) {
      //强制更新
      item.setPosition(new cc.v2(data.x, data.y));

      this._resetItemSize(item); // cc.log('ADD::', data.id, item);


      if (this.renderEvent) {
        cc.Component.EventHandler.emitEvents([this.renderEvent], item, data.id % this._actualNumItems);
      }
    }

    this._resetItemSize(item);

    this._updateListItem(item.listItem);

    if (this._lastDisplayData.indexOf(data.id) < 0) {
      this._lastDisplayData.push(data.id);
    }
  },
  //创建或更新Item（非虚拟列表用）
  _createOrUpdateItem2: function _createOrUpdateItem2(listId) {
    var item = this.content.children[listId];

    if (!item) {
      //如果不存在
      item = cc.instantiate(this._itemTmp);
      item._listId = listId;
      this.content.addChild(item);
      var listItem = item.getComponent(ListItem);
      item.listItem = listItem;

      if (listItem) {
        listItem._list = this;

        listItem._registerEvent();
      }

      if (this.renderEvent) {
        cc.Component.EventHandler.emitEvents([this.renderEvent], item, listId);
      }
    } else if (this._forceUpdate && this.renderEvent) {
      //强制更新
      item._listId = listId;

      if (this.renderEvent) {
        cc.Component.EventHandler.emitEvents([this.renderEvent], item, listId);
      }
    }

    this._updateListItem(item.listItem);

    if (this._lastDisplayData.indexOf(listId) < 0) {
      this._lastDisplayData.push(listId);
    }
  },
  _updateListItem: function _updateListItem(listItem) {
    if (!listItem) return;

    if (this.selectedMode > SelectedType.NONE) {
      switch (this.selectedMode) {
        case SelectedType.SINGLE:
          listItem.selected = this.selectedId == listItem.node._listId;
          break;

        case SelectedType.MULT:
          listItem.selected = this.multSelected.indexOf(listItem.node._listId) >= 0;
          break;
      }
    }
  },
  //仅虚拟列表用
  _resetItemSize: function _resetItemSize(item) {
    return;
    var size;

    if (this._customSize && this._customSize[item._listId]) {
      size = this._customSize[item._listId];
    } else {
      if (this._colLineNum > 1) item.setContentSize(this._itemSize);else size = this._sizeType ? this._itemSize.height : this._itemSize.width;
    }

    if (size) {
      if (this._sizeType) item.height = size;else item.width = size;
    }
  },

  /**
   * 更新Item位置
   * @param {Number||Node} listIdOrItem
   */
  _updateItemPos: function _updateItemPos(listIdOrItem) {
    var item = isNaN(listIdOrItem) ? listIdOrItem : this.getItemByListId(listIdOrItem);
    var pos = this.getItemPos(item._listId);
    item.setPosition(pos.x, pos.y);
  },

  /**
   * 设置多选
   * @param {Array} args 可以是单个listId，也可是个listId数组
   * @param {Boolean} bool 值，如果为null的话，则直接用args覆盖
   */
  setMultSelected: function setMultSelected(args, bool) {
    var t = this;
    if (!t.checkInited()) return;

    if (!Array.isArray(args)) {
      args = [args];
    }

    if (bool == null) {
      t.multSelected = args;
    } else {
      var listId, sub;

      if (bool) {
        for (var n = args.length - 1; n >= 0; n--) {
          listId = args[n];
          sub = t.multSelected.indexOf(listId);

          if (sub < 0) {
            t.multSelected.push(listId);
          }
        }
      } else {
        for (var _n3 = args.length - 1; _n3 >= 0; _n3--) {
          listId = args[_n3];
          sub = t.multSelected.indexOf(listId);

          if (sub >= 0) {
            t.multSelected.splice(sub, 1);
          }
        }
      }
    }

    t._forceUpdate = true;

    t._onScrolling();
  },

  /**
   * 更新指定的Item
   * @param {Array} args 单个listId，或者数组
   * @returns
   */
  updateItem: function updateItem(args) {
    if (!this.checkInited()) return;

    if (!Array.isArray(args)) {
      args = [args];
    }

    for (var n = 0, len = args.length; n < len; n++) {
      var listId = args[n];
      var item = this.getItemByListId(listId);

      if (item) {
        cc.Component.EventHandler.emitEvents([this.renderEvent], item, listId % this._actualNumItems);
      }
    }
  },

  /**
   * 更新全部
   */
  updateAll: function updateAll() {
    if (!this.checkInited()) return;
    this.numItems = this.numItems;
  },

  /**
   * 根据ListID获取Item
   * @param {Number} listId
   * @returns
   */
  getItemByListId: function getItemByListId(listId) {
    for (var n = this.content.childrenCount - 1; n >= 0; n--) {
      if (this.content.children[n]._listId == listId) return this.content.children[n];
    }
  },

  /**
   * 获取在显示区域外的Item
   * @returns
   */
  _getOutsideItem: function _getOutsideItem() {
    var item, isOutside;
    var result = [];

    for (var n = this.content.childrenCount - 1; n >= 0; n--) {
      item = this.content.children[n];
      isOutside = true;

      if (isOutside) {
        for (var c = this.displayItemNum - 1; c >= 0; c--) {
          if (!this.displayData[c]) continue;
          var listId = this.displayData[c].id;

          if (item._listId == listId) {
            isOutside = false;
            break;
          }
        }
      }

      if (isOutside) {
        result.push(item);
      }
    }

    return result;
  },
  //删除显示区域以外的Item
  _delRedundantItem: function _delRedundantItem() {
    if (this._virtual) {
      var arr = this._getOutsideItem();

      for (var n = arr.length - 1; n >= 0; n--) {
        var item = arr[n];
        if (this._scrollItem && item._listId == this._scrollItem._listId) continue;

        this._pool.put(item);
      } // cc.log('存入::', str, '    pool.length =', this._pool.length);

    } else {
      while (this.content.childrenCount > this._numItems) {
        this._delSingleItem(this.content.children[this.content.childrenCount - 1]);
      }
    }
  },
  //删除单个Item
  _delSingleItem: function _delSingleItem(item) {
    // cc.log('DEL::', item._listId, item);
    item.removeFromParent();
    if (item.destroy) item.destroy();
    item = null;
  },

  /**
   * 动效删除Item（此方法只适用于虚拟列表，即_virtual=true）
   * 一定要在回调函数里重新设置新的numItems进行刷新，毕竟本List是靠数据驱动的。
   */
  aniDelItem: function aniDelItem(listId, callFunc, aniType) {
    var t = this;
    if (!t.checkInited() || t.cyclic || !t._virtual) return cc.error('This function is not allowed to be called!');
    if (t._aniDelRuning) return cc.warn('Please wait for the current deletion to finish!');
    var item = t.getItemByListId(listId);

    if (!item) {
      callFunc(listId);
      return;
    }

    t._aniDelRuning = true;
    var curLastId = t.displayData[t.displayData.length - 1].id;
    var resetSelectedId = item.listItem.selected;
    item.listItem.showAni(aniType, function () {
      //判断有没有下一个，如果有的话，创建粗来
      var newId;

      if (curLastId < t._numItems - 2) {
        newId = curLastId + 1;
      }

      if (newId != null) {
        var newData = t._calcItemPos(newId);

        t.displayData.push(newData);
        if (t._virtual) t._createOrUpdateItem(newData);else t._createOrUpdateItem2(newId);
      } else t._numItems--;

      if (t.selectedMode == SelectedType.SINGLE) {
        if (resetSelectedId) {
          t._selectedId = -1;
        } else if (t._selectedId - 1 >= 0) {
          t._selectedId--;
        }
      } else if (t.selectedMode == SelectedType.MULT && t.multSelected.length) {
        var sub = t.multSelected.indexOf(listId); // let tmp;

        if (sub >= 0) {
          t.multSelected.splice(sub, 1);
        } //多选的数据，在其后的全部减一


        for (var n = t.multSelected.length - 1; n >= 0; n--) {
          var id = t.multSelected[n];
          if (id >= listId) t.multSelected[n]--;
        }
      }

      if (t._customSize) {
        if (t._customSize[listId]) delete t._customSize[listId];
        var newCustomSize = {};
        var size;

        for (var _id in t._customSize) {
          size = t._customSize[_id];
          _id = parseInt(_id);
          newCustomSize[_id - (_id >= listId ? 1 : 0)] = size;
        }

        t._customSize = newCustomSize;
      } //后面的Item向前怼的动效


      var sec = .2333;
      var acts, haveCB;

      for (var _n4 = newId != null ? newId : curLastId; _n4 >= listId + 1; _n4--) {
        item = t.getItemByListId(_n4);

        if (item) {
          var posData = t._calcItemPos(_n4 - 1);

          acts = [new cc.moveTo(sec, new cc.v2(posData.x, posData.y))];

          if (_n4 <= listId + 1) {
            haveCB = true;
            acts.push(new cc.CallFunc(function () {
              t._aniDelRuning = false;
              callFunc(listId);
            }));
          }

          if (acts.length > 1) item.runAction(new cc.Sequence(acts));else item.runAction(acts[0]);
        }
      }

      if (!haveCB) {
        t._aniDelRuning = false;
        callFunc(listId);
      }
    }, true);
  },

  /**
   * 滚动到..
   * @param {Number} listId 索引（如果<0，则滚到首个Item位置，如果>=_numItems，则滚到最末Item位置）
   * @param {Number} timeInSecond 时间
   * @param {Number} offset 索引目标位置偏移，0-1
   * @param {Boolean} overStress 滚动后是否强调该Item（这只是个实验功能）
   */
  scrollTo: function scrollTo(listId, timeInSecond, offset, overStress) {
    var t = this;
    if (!t.checkInited()) return;

    t._scrollView.stopAutoScroll();

    if (timeInSecond == null) //默认0.5
      timeInSecond = .5;else if (timeInSecond < 0) timeInSecond = 0;
    if (listId < 0) listId = 0;else if (listId >= t._numItems) listId = t._numItems - 1; // 以防设置了numItems之后layout的尺寸还未更新

    if (!t._virtual && t._layout && t._layout.enabled) t._layout.updateLayout();
    var pos = t.getItemPos(listId);
    var targetX, targetY;

    switch (t._alignCalcType) {
      case 1:
        //单行HORIZONTAL（LEFT_TO_RIGHT）、网格VERTICAL（LEFT_TO_RIGHT）
        targetX = pos.left;
        if (offset != null) targetX -= t.node.width * offset;else targetX -= t._leftGap;
        pos = new cc.v2(targetX, 0);
        break;

      case 2:
        //单行HORIZONTAL（RIGHT_TO_LEFT）、网格VERTICAL（RIGHT_TO_LEFT）
        targetX = pos.right - t.node.width;
        if (offset != null) targetX += t.node.width * offset;else targetX += t._rightGap;
        pos = new cc.v2(targetX + t.content.width, 0);
        break;

      case 3:
        //单列VERTICAL（TOP_TO_BOTTOM）、网格HORIZONTAL（TOP_TO_BOTTOM）
        targetY = pos.top;
        if (offset != null) targetY += t.node.height * offset;else targetY += t._topGap;
        pos = new cc.v2(0, -targetY);
        break;

      case 4:
        //单列VERTICAL（BOTTOM_TO_TOP）、网格HORIZONTAL（BOTTOM_TO_TOP）
        targetY = pos.bottom + t.node.height;
        if (offset != null) targetY -= t.node.height * offset;else targetY -= t._bottomGap;
        pos = new cc.v2(0, -targetY + t.content.height);
        break;
    }

    var viewPos = t.content.getPosition();
    viewPos = Math.abs(t._sizeType ? viewPos.y : viewPos.x);
    var comparePos = t._sizeType ? pos.y : pos.x;
    var runScroll = Math.abs((t._scrollPos != null ? t._scrollPos : viewPos) - comparePos) > .5; // cc.log(runScroll, t._scrollPos, viewPos, comparePos)

    t._scrollView.stopAutoScroll();

    if (runScroll) {
      t._scrollPos = comparePos;
      t._scrollToListId = listId;
      t._scrollToEndTime = new Date().getTime() / 1000 + timeInSecond;

      t._scrollView.scrollToOffset(pos, timeInSecond); // cc.log(listId, t.content.width, t.content.getPosition(), pos);


      t._scrollToSo = t.scheduleOnce(function () {
        if (!t._adheringBarrier) {
          t.adhering = t._adheringBarrier = false;
        }

        t._scrollPos = t._scrollToListId = t._scrollToEndTime = t._scrollToSo = null; //cc.log('2222222222', t._adheringBarrier)

        if (overStress) {
          // t.scrollToListId = listId;
          var item = t.getItemByListId(listId);

          if (item) {
            item.runAction(new cc.sequence(new cc.scaleTo(.1, 1.05), new cc.scaleTo(.1, 1)));
          }
        }
      }, timeInSecond + .1);

      if (timeInSecond <= 0) {
        t._onScrolling();
      }
    }
  },

  /**
   * 计算当前滚动窗最近的Item
   */
  _calcNearestItem: function _calcNearestItem() {
    var t = this;
    t.nearestListId = null;
    var data, center;
    if (t._virtual) t._calcViewPos();
    var vTop, vRight, vBottom, vLeft;
    vTop = t.viewTop;
    vRight = t.viewRight;
    vBottom = t.viewBottom;
    vLeft = t.viewLeft;
    var breakFor = false;

    for (var n = 0; n < t.content.childrenCount && !breakFor; n += t._colLineNum) {
      data = this._virtual ? this.displayData[n] : this._calcExistItemPos(n);
      center = this._sizeType ? (data.top + data.bottom) / 2 : center = (data.left + data.right) / 2;

      switch (this._alignCalcType) {
        case 1:
          //单行HORIZONTAL（LEFT_TO_RIGHT）、网格VERTICAL（LEFT_TO_RIGHT）
          if (data.right >= vLeft) {
            this.nearestListId = data.id;
            if (vLeft > center) this.nearestListId += this._colLineNum;
            breakFor = true;
          }

          break;

        case 2:
          //单行HORIZONTAL（RIGHT_TO_LEFT）、网格VERTICAL（RIGHT_TO_LEFT）
          if (data.left <= vRight) {
            this.nearestListId = data.id;
            if (vRight < center) this.nearestListId += this._colLineNum;
            breakFor = true;
          }

          break;

        case 3:
          //单列VERTICAL（TOP_TO_BOTTOM）、网格HORIZONTAL（TOP_TO_BOTTOM）
          if (data.bottom <= vTop) {
            this.nearestListId = data.id;
            if (vTop < center) this.nearestListId += this._colLineNum;
            breakFor = true;
          }

          break;

        case 4:
          //单列VERTICAL（BOTTOM_TO_TOP）、网格HORIZONTAL（BOTTOM_TO_TOP）
          if (data.top >= vBottom) {
            this.nearestListId = data.id;
            if (vBottom > center) this.nearestListId += this._colLineNum;
            breakFor = true;
          }

          break;
      }
    } //判断最后一个Item。。。（哎，这些判断真心恶心，判断了前面的还要判断最后一个。。。一开始呢，就只有一个布局（单列布局），那时候代码才三百行，后来就想着完善啊，艹..这坑真深，现在这行数都一千五了= =||）


    data = this._virtual ? this.displayData[this.displayItemNum - 1] : this._calcExistItemPos(this._numItems - 1);

    if (data && data.id == t._numItems - 1) {
      center = t._sizeType ? (data.top + data.bottom) / 2 : center = (data.left + data.right) / 2;

      switch (t._alignCalcType) {
        case 1:
          //单行HORIZONTAL（LEFT_TO_RIGHT）、网格VERTICAL（LEFT_TO_RIGHT）
          if (vRight > center) t.nearestListId = data.id;
          break;

        case 2:
          //单行HORIZONTAL（RIGHT_TO_LEFT）、网格VERTICAL（RIGHT_TO_LEFT）
          if (vLeft < center) t.nearestListId = data.id;
          break;

        case 3:
          //单列VERTICAL（TOP_TO_BOTTOM）、网格HORIZONTAL（TOP_TO_BOTTOM）
          if (vBottom < center) t.nearestListId = data.id;
          break;

        case 4:
          //单列VERTICAL（BOTTOM_TO_TOP）、网格HORIZONTAL（BOTTOM_TO_TOP）
          if (vTop > center) t.nearestListId = data.id;
          break;
      }
    } // cc.log('t.nearestListId =', t.nearestListId);

  },
  //上一页
  prePage: function prePage(timeInSecond) {
    // cc.log('👈');
    if (!this.checkInited()) return;
    if (timeInSecond == null) timeInSecond = .5;
    this.skipPage(this.curPageNum - 1, timeInSecond);
  },
  //下一页
  nextPage: function nextPage(timeInSecond) {
    // cc.log('👉');
    if (!this.checkInited()) return;
    if (timeInSecond == null) timeInSecond = .5;
    this.skipPage(this.curPageNum + 1, timeInSecond);
  },
  //跳转到第几页
  skipPage: function skipPage(pageNum, timeInSecond) {
    var t = this;
    if (!t.checkInited()) return;
    if (t._slideMode != SlideType.PAGE) return cc.error('This function is not allowed to be called, Must SlideMode = PAGE!');
    if (pageNum < 0 || pageNum >= t._numItems) return;
    if (t.curPageNum == pageNum) return; // cc.log(pageNum);

    t.curPageNum = pageNum;

    if (t.pageChangeEvent) {
      cc.Component.EventHandler.emitEvents([t.pageChangeEvent], pageNum);
    }

    t.scrollTo(pageNum, timeInSecond);
  },
  //计算 CustomSize（这个函数还是保留吧，某些罕见的情况的确还是需要手动计算customSize的）
  calcCustomSize: function calcCustomSize(numItems) {
    var t = this;
    if (!t.checkInited()) return;
    if (!t._itemTmp) return cc.error('Unset template item!');
    if (!t.renderEvent) return cc.error('Unset Render-Event!');
    t._customSize = {};
    var temp = cc.instantiate(t._itemTmp);
    t.content.addChild(temp);

    for (var n = 0; n < numItems; n++) {
      cc.Component.EventHandler.emitEvents([t.renderEvent], temp, n);

      if (temp.height != t._itemSize.height || temp.width != t._itemSize.width) {
        t._customSize[n] = t._sizeType ? temp.height : temp.width;
      }
    }

    if (!Object.keys(t._customSize).length) t._customSize = null;
    temp.removeFromParent();
    if (temp.destroy) temp.destroy();
    return t._customSize;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxUaGlyZFxcVmlydHVhbExpc3RcXExpc3QuanMiXSwibmFtZXMiOlsiVGVtcGxhdGVUeXBlIiwiY2MiLCJFbnVtIiwiU2xpZGVUeXBlIiwiU2VsZWN0ZWRUeXBlIiwiTGlzdEl0ZW0iLCJyZXF1aXJlIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJlZGl0b3IiLCJkaXNhbGxvd011bHRpcGxlIiwibWVudSIsInJlcXVpcmVDb21wb25lbnQiLCJTY3JvbGxWaWV3IiwiZXhlY3V0aW9uT3JkZXIiLCJwcm9wZXJ0aWVzIiwidGVtcGxhdGVUeXBlIiwiTk9ERSIsInR5cGUiLCJ0bXBOb2RlIiwiTm9kZSIsInRvb2x0aXAiLCJDQ19ERVYiLCJ2aXNpYmxlIiwiYm9vbCIsInRtcFByZWZhYiIsIlByZWZhYiIsIlBSRUZBQiIsIl9zbGlkZU1vZGUiLCJzbGlkZU1vZGUiLCJnZXQiLCJzZXQiLCJ2YWwiLCJwYWdlRGlzdGFuY2UiLCJGbG9hdCIsInJhbmdlIiwic2xpZGUiLCJQQUdFIiwicGFnZUNoYW5nZUV2ZW50IiwiRXZlbnRIYW5kbGVyIiwiX3ZpcnR1YWwiLCJ2aXJ0dWFsIiwiX251bUl0ZW1zIiwiX29uU2Nyb2xsaW5nIiwiY3ljbGljIiwiTk9STUFMIiwibGFja0NlbnRlciIsImxhY2tTbGlkZSIsIl91cGRhdGVSYXRlIiwidXBkYXRlUmF0ZSIsIkludGVnZXIiLCJmcmFtZUJ5RnJhbWVSZW5kZXJOdW0iLCJyZW5kZXJFdmVudCIsInNlbGVjdGVkTW9kZSIsIk5PTkUiLCJyZXBlYXRFdmVudFNpbmdsZSIsIlNJTkdMRSIsInNlbGVjdGVkRXZlbnQiLCJfc2VsZWN0ZWRJZCIsInNlbGVjdGVkSWQiLCJ0IiwiaXRlbSIsImdldEl0ZW1CeUxpc3RJZCIsIl9sYXN0U2VsZWN0ZWRJZCIsImxpc3RJdGVtIiwic2VsZWN0ZWQiLCJsYXN0SXRlbSIsImVtaXRFdmVudHMiLCJfYWN0dWFsTnVtSXRlbXMiLCJNVUxUIiwic3ViIiwibXVsdFNlbGVjdGVkIiwiaW5kZXhPZiIsInB1c2giLCJzcGxpY2UiLCJzZXJpYWxpemFibGUiLCJudW1JdGVtcyIsImNoZWNrSW5pdGVkIiwiZXJyb3IiLCJfZm9yY2VVcGRhdGUiLCJfcmVzaXplQ29udGVudCIsIl9jeWNsaWNOdW0iLCJjdXJQYWdlTnVtIiwibmVhcmVzdExpc3RJZCIsImxheW91dCIsImNvbnRlbnQiLCJnZXRDb21wb25lbnQiLCJMYXlvdXQiLCJlbmFibGVkIiwiX2RlbFJlZHVuZGFudEl0ZW0iLCJmaXJzdExpc3RJZCIsImxlbiIsIm4iLCJfY3JlYXRlT3JVcGRhdGVJdGVtMiIsIl91cGRhdGVDb3VudGVyIiwiX3VwZGF0ZURvbmUiLCJkaXNwbGF5SXRlbU51bSIsIm9uTG9hZCIsIl9pbml0Iiwib25EZXN0cm95IiwiX2l0ZW1UbXAiLCJpc1ZhbGlkIiwiZGVzdHJveSIsIl9wb29sIiwic2l6ZSIsIm5vZGUiLCJvbkVuYWJsZSIsIl9yZWdpc3RlckV2ZW50Iiwib25EaXNhYmxlIiwiX3VucmVnaXN0ZXJFdmVudCIsIm9uIiwiRXZlbnRUeXBlIiwiVE9VQ0hfU1RBUlQiLCJfb25Ub3VjaFN0YXJ0IiwiX29uVG91Y2hVcCIsIlRPVUNIX0NBTkNFTCIsIl9vblRvdWNoQ2FuY2VsbGVkIiwiX29uU2Nyb2xsQmVnYW4iLCJfb25TY3JvbGxFbmRlZCIsIlNJWkVfQ0hBTkdFRCIsIl9vblNpemVDaGFuZ2VkIiwib2ZmIiwiX2luaXRlZCIsIl9zY3JvbGxWaWV3IiwibmFtZSIsIl9sYXlvdXQiLCJfYWxpZ24iLCJfcmVzaXplTW9kZSIsInJlc2l6ZU1vZGUiLCJfc3RhcnRBeGlzIiwic3RhcnRBeGlzIiwiX3RvcEdhcCIsInBhZGRpbmdUb3AiLCJfcmlnaHRHYXAiLCJwYWRkaW5nUmlnaHQiLCJfYm90dG9tR2FwIiwicGFkZGluZ0JvdHRvbSIsIl9sZWZ0R2FwIiwicGFkZGluZ0xlZnQiLCJfY29sdW1uR2FwIiwic3BhY2luZ1giLCJfbGluZUdhcCIsInNwYWNpbmdZIiwiX2NvbExpbmVOdW0iLCJfdmVydGljYWxEaXIiLCJ2ZXJ0aWNhbERpcmVjdGlvbiIsIl9ob3Jpem9udGFsRGlyIiwiaG9yaXpvbnRhbERpcmVjdGlvbiIsInNldFRlbXBsYXRlSXRlbSIsImluc3RhbnRpYXRlIiwiQURIRVJJTkciLCJpbmVydGlhIiwiX2xhc3REaXNwbGF5RGF0YSIsImRpc3BsYXlEYXRhIiwiTm9kZVBvb2wiLCJfcHJvY2Vzc0F1dG9TY3JvbGxpbmciLCJiaW5kIiwiX3N0YXJ0Qm91bmNlQmFja0lmTmVlZGVkIiwiVHlwZSIsIkhPUklaT05UQUwiLCJIb3Jpem9udGFsRGlyZWN0aW9uIiwiTEVGVF9UT19SSUdIVCIsIl9hbGlnbkNhbGNUeXBlIiwiUklHSFRfVE9fTEVGVCIsIlZFUlRJQ0FMIiwiVmVydGljYWxEaXJlY3Rpb24iLCJUT1BfVE9fQk9UVE9NIiwiQk9UVE9NX1RPX1RPUCIsIkdSSUQiLCJBeGlzRGlyZWN0aW9uIiwiY2hpbGRyZW4iLCJmb3JFYWNoIiwiY2hpbGQiLCJyZW1vdmVGcm9tUGFyZW50IiwiZHQiLCJicmFraW5nRmFjdG9yIiwiX2F1dG9TY3JvbGxBY2N1bXVsYXRlZFRpbWUiLCJwZXJjZW50YWdlIiwiTWF0aCIsIm1pbiIsIl9hdXRvU2Nyb2xsVG90YWxUaW1lIiwiX2F1dG9TY3JvbGxBdHRlbnVhdGUiLCJ0aW1lIiwibmV3UG9zaXRpb24iLCJfYXV0b1Njcm9sbFN0YXJ0UG9zaXRpb24iLCJhZGQiLCJfYXV0b1Njcm9sbFRhcmdldERlbHRhIiwibXVsIiwiRVBTSUxPTiIsImdldFNjcm9sbEVuZGVkRXZlbnRUaW1pbmciLCJyZWFjaGVkRW5kIiwiYWJzIiwiZmlyZUV2ZW50IiwiX2lzU2Nyb2xsRW5kZWRXaXRoVGhyZXNob2xkRXZlbnRGaXJlZCIsIl9kaXNwYXRjaEV2ZW50IiwiX2F1dG9TY3JvbGxpbmciLCJkZWx0YU1vdmUiLCJnZXRDb250ZW50UG9zaXRpb24iLCJfbW92ZUNvbnRlbnQiLCJfY2xhbXBEZWx0YSIsIl9pc0JvdW5jaW5nIiwiX3Njcm9sbGluZyIsIlJlc2l6ZU1vZGUiLCJDSElMRFJFTiIsIl9pdGVtU2l6ZSIsImNlbGxTaXplIiwid2lkdGgiLCJoZWlnaHQiLCJjb20iLCJyZW1vdmUiLCJfYnRuQ29tIiwiQnV0dG9uIiwiV2lkZ2V0IiwiX25lZWRVcGRhdGVXaWRnZXQiLCJfc2l6ZVR5cGUiLCJ0cmltVyIsImZsb29yIiwidHJpbUgiLCJwcmludExvZyIsInJlc3VsdCIsIl9jdXN0b21TaXplIiwiZml4ZWQiLCJfZ2V0Rml4ZWRTaXplIiwiY291bnQiLCJsaW5lTnVtIiwiY2VpbCIsImNvbE51bSIsIl9hbGxJdGVtU2l6ZSIsIl9hbGxJdGVtU2l6ZU5vRWRnZSIsInRvdGFsU2l6ZSIsIl9jeWNsaWNQb3MxIiwic3BhY2luZyIsIl9jeWNsaWNQb3MyIiwiX2N5Y2xpY0FsbEl0ZW1TaXplIiwiX2N5Y2lsY0FsbEl0ZW1TaXplTm9FZGdlIiwiX2xhY2siLCJzbGlkZU9mZnNldCIsInRhcmdldFdIIiwiZXYiLCJmcmFtZUNvdW50IiwiX2FuaURlbFJ1bmluZyIsInNjcm9sbFBvcyIsImdldFBvc2l0aW9uIiwieSIsIngiLCJhZGRWYWwiLCJ2MiIsImlzQXV0b1Njcm9sbGluZyIsIl9jYWxjVmlld1BvcyIsInZUb3AiLCJ2UmlnaHQiLCJ2Qm90dG9tIiwidkxlZnQiLCJ2aWV3VG9wIiwidmlld0JvdHRvbSIsInZpZXdSaWdodCIsInZpZXdMZWZ0IiwiaXRlbVBvcyIsImN1cklkIiwiZW5kSWQiLCJicmVha0ZvciIsIl9jYWxjSXRlbVBvcyIsInJpZ2h0IiwibGVmdCIsImxlbmd0aCIsImJvdHRvbSIsInRvcCIsInd3IiwiaGgiLCJpZCIsIl9kb25lQWZ0ZXJVcGRhdGUiLCJjIiwiX2NyZWF0ZU9yVXBkYXRlSXRlbSIsIl9jYWxjTmVhcmVzdEl0ZW0iLCJlbGFzdGljTGVmdCIsImVsYXN0aWNSaWdodCIsImVsYXN0aWNUb3AiLCJlbGFzdGljQm90dG9tIiwiaXRlbVgiLCJpdGVtWSIsImNzIiwib2Zmc2V0IiwiYW5jaG9yWCIsImFuY2hvclkiLCJjb2xMaW5lIiwiX2NhbGNFeGlzdEl0ZW1Qb3MiLCJkYXRhIiwiZ2V0SXRlbVBvcyIsImxpc3RJZCIsInBhcnNlSW50IiwiX2JlZ2FuUG9zIiwic2Nyb2xsVG9MaXN0SWQiLCJydW5BY3Rpb24iLCJzZXF1ZW5jZSIsInNjYWxlVG8iLCJhZGhlcmluZyIsImFkaGVyZSIsIl9wYWdlQWRoZXJlIiwiY2FwdHVyZUxpc3RlbmVycyIsIl9oYXNOZXN0ZWRWaWV3R3JvdXAiLCJpc01lIiwiZXZlbnRQaGFzZSIsIkV2ZW50IiwiQVRfVEFSR0VUIiwidGFyZ2V0IiwiaXRlbU5vZGUiLCJfbGlzdElkIiwicGFyZW50IiwiX3Njcm9sbEl0ZW0iLCJfc2Nyb2xsUG9zIiwiX2FkaGVyaW5nQmFycmllciIsInNpbXVsYXRlIiwiX29uSXRlbUFkYXB0aXZlIiwiX3VwZGF0ZUl0ZW1Qb3MiLCJpc05hTiIsIl9zY3JvbGxUb0xpc3RJZCIsInVuc2NoZWR1bGUiLCJfc2Nyb2xsVG9TbyIsInNjcm9sbFRvIiwibWF4IiwiX3Njcm9sbFRvRW5kVGltZSIsIkRhdGUiLCJnZXRUaW1lIiwiY3VyUG9zIiwiZGlzIiwiY2FuU2tpcCIsInRpbWVJblNlY29uZCIsInByZVBhZ2UiLCJuZXh0UGFnZSIsInVwZGF0ZSIsImlzU2Nyb2xsaW5nIiwiY2FuR2V0Iiwic2V0Q29udGVudFNpemUiLCJzZXRQb3NpdGlvbiIsIl9yZXNldEl0ZW1TaXplIiwiYWRkQ2hpbGQiLCJ3aWRnZXQiLCJ1cGRhdGVBbGlnbm1lbnQiLCJzZXRTaWJsaW5nSW5kZXgiLCJjaGlsZHJlbkNvdW50IiwiX2xpc3QiLCJfdXBkYXRlTGlzdEl0ZW0iLCJsaXN0SWRPckl0ZW0iLCJwb3MiLCJzZXRNdWx0U2VsZWN0ZWQiLCJhcmdzIiwiQXJyYXkiLCJpc0FycmF5IiwidXBkYXRlSXRlbSIsInVwZGF0ZUFsbCIsIl9nZXRPdXRzaWRlSXRlbSIsImlzT3V0c2lkZSIsImFyciIsInB1dCIsIl9kZWxTaW5nbGVJdGVtIiwiYW5pRGVsSXRlbSIsImNhbGxGdW5jIiwiYW5pVHlwZSIsIndhcm4iLCJjdXJMYXN0SWQiLCJyZXNldFNlbGVjdGVkSWQiLCJzaG93QW5pIiwibmV3SWQiLCJuZXdEYXRhIiwibmV3Q3VzdG9tU2l6ZSIsInNlYyIsImFjdHMiLCJoYXZlQ0IiLCJwb3NEYXRhIiwibW92ZVRvIiwiQ2FsbEZ1bmMiLCJTZXF1ZW5jZSIsIm92ZXJTdHJlc3MiLCJzdG9wQXV0b1Njcm9sbCIsInVwZGF0ZUxheW91dCIsInRhcmdldFgiLCJ0YXJnZXRZIiwidmlld1BvcyIsImNvbXBhcmVQb3MiLCJydW5TY3JvbGwiLCJzY3JvbGxUb09mZnNldCIsInNjaGVkdWxlT25jZSIsImNlbnRlciIsInNraXBQYWdlIiwicGFnZU51bSIsImNhbGNDdXN0b21TaXplIiwidGVtcCIsIk9iamVjdCIsImtleXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs7OztBQU1BLElBQU1BLFlBQVksR0FBR0MsRUFBRSxDQUFDQyxJQUFILENBQVE7QUFDekIsVUFBUSxDQURpQjtBQUV6QixZQUFVO0FBRmUsQ0FBUixDQUFyQjtBQUlBLElBQU1DLFNBQVMsR0FBR0YsRUFBRSxDQUFDQyxJQUFILENBQVE7QUFDdEIsWUFBVSxDQURZO0FBQ1Q7QUFDYixjQUFZLENBRlU7QUFFUDtBQUNmLFVBQVEsQ0FIYyxDQUdUOztBQUhTLENBQVIsQ0FBbEI7QUFLQSxJQUFNRSxZQUFZLEdBQUdILEVBQUUsQ0FBQ0MsSUFBSCxDQUFRO0FBQ3pCLFVBQVEsQ0FEaUI7QUFFekIsWUFBVSxDQUZlO0FBRVo7QUFDYixVQUFRLENBSGlCLENBR2Q7O0FBSGMsQ0FBUixDQUFyQjs7QUFNQSxJQUFNRyxRQUFRLEdBQUdDLE9BQU8sQ0FBQyxVQUFELENBQXhCOztBQUVBTCxFQUFFLENBQUNNLEtBQUgsQ0FBUztBQUNMLGFBQVNOLEVBQUUsQ0FBQ08sU0FEUDtBQUdMQyxFQUFBQSxNQUFNLEVBQUU7QUFDSkMsSUFBQUEsZ0JBQWdCLEVBQUUsS0FEZDtBQUVKQyxJQUFBQSxJQUFJLEVBQUUsWUFGRjtBQUdKQyxJQUFBQSxnQkFBZ0IsRUFBRVgsRUFBRSxDQUFDWSxVQUhqQjtBQUlKO0FBQ0FDLElBQUFBLGNBQWMsRUFBRSxDQUFDO0FBTGIsR0FISDtBQVdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsWUFBWSxFQUFFO0FBQ1YsaUJBQVNoQixZQUFZLENBQUNpQixJQURaO0FBRVZDLE1BQUFBLElBQUksRUFBRWxCO0FBRkksS0FETjtBQUtSbUIsSUFBQUEsT0FBTyxFQUFFO0FBQ0wsaUJBQVMsSUFESjtBQUVMRCxNQUFBQSxJQUFJLEVBQUVqQixFQUFFLENBQUNtQixJQUZKO0FBR0xDLE1BQUFBLE9BQU8sRUFBRUMsTUFBTSxJQUFJLHFCQUhkO0FBSUxDLE1BQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQixZQUFJQyxJQUFJLEdBQUcsS0FBS1IsWUFBTCxJQUFxQmhCLFlBQVksQ0FBQ2lCLElBQTdDO0FBQ0EsWUFBSSxDQUFDTyxJQUFMLEVBQ0ksS0FBS0wsT0FBTCxHQUFlLElBQWY7QUFDSixlQUFPSyxJQUFQO0FBQ0g7QUFUSSxLQUxEO0FBZ0JSQyxJQUFBQSxTQUFTLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBQLE1BQUFBLElBQUksRUFBRWpCLEVBQUUsQ0FBQ3lCLE1BRkY7QUFHUEwsTUFBQUEsT0FBTyxFQUFFQyxNQUFNLElBQUksdUJBSFo7QUFJUEMsTUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCLFlBQUlDLElBQUksR0FBRyxLQUFLUixZQUFMLElBQXFCaEIsWUFBWSxDQUFDMkIsTUFBN0M7QUFDQSxZQUFJLENBQUNILElBQUwsRUFDSSxLQUFLQyxTQUFMLEdBQWlCLElBQWpCO0FBQ0osZUFBT0QsSUFBUDtBQUNIO0FBVE0sS0FoQkg7QUEyQlJJLElBQUFBLFVBQVUsRUFBRSxDQTNCSjtBQTRCUkMsSUFBQUEsU0FBUyxFQUFFO0FBQ1BYLE1BQUFBLElBQUksRUFBRWYsU0FEQztBQUVQa0IsTUFBQUEsT0FBTyxFQUFFQyxNQUFNLElBQUksTUFGWjtBQUdQUSxNQUFBQSxHQUFHLEVBQUUsZUFBWTtBQUNiLGVBQU8sS0FBS0YsVUFBWjtBQUNILE9BTE07QUFNUEcsTUFBQUEsR0FBRyxFQUFFLGFBQVVDLEdBQVYsRUFBZTtBQUNoQixZQUFJQSxHQUFHLElBQUksSUFBWCxFQUNJLEtBQUtKLFVBQUwsR0FBa0JJLEdBQWxCO0FBQ1A7QUFUTSxLQTVCSDtBQXVDUkMsSUFBQUEsWUFBWSxFQUFFO0FBQ1YsaUJBQVMsRUFEQztBQUVWZixNQUFBQSxJQUFJLEVBQUVqQixFQUFFLENBQUNpQyxLQUZDO0FBR1ZDLE1BQUFBLEtBQUssRUFBRSxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sRUFBUCxDQUhHO0FBSVZkLE1BQUFBLE9BQU8sRUFBRUMsTUFBTSxJQUFJLFFBSlQ7QUFLVmMsTUFBQUEsS0FBSyxFQUFFLElBTEc7QUFNVmIsTUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCLGVBQU8sS0FBS0ssVUFBTCxJQUFtQnpCLFNBQVMsQ0FBQ2tDLElBQXBDO0FBQ0g7QUFSUyxLQXZDTjtBQWlEUkMsSUFBQUEsZUFBZSxFQUFFO0FBQ2IsaUJBQVMsSUFESTtBQUVicEIsTUFBQUEsSUFBSSxFQUFFakIsRUFBRSxDQUFDTyxTQUFILENBQWErQixZQUZOO0FBR2JsQixNQUFBQSxPQUFPLEVBQUVDLE1BQU0sSUFBSSxRQUhOO0FBSWJDLE1BQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQixZQUFJQyxJQUFJLEdBQUcsS0FBS0ksVUFBTCxJQUFtQnpCLFNBQVMsQ0FBQ2tDLElBQXhDO0FBQ0EsWUFBSSxDQUFDYixJQUFMLEVBQ0ksS0FBS2MsZUFBTCxHQUF1QixJQUF2QjtBQUNKLGVBQU9kLElBQVA7QUFDSDtBQVRZLEtBakRUO0FBNERSZ0IsSUFBQUEsUUFBUSxFQUFFLElBNURGO0FBNkRSQyxJQUFBQSxPQUFPLEVBQUU7QUFDTHBCLE1BQUFBLE9BQU8sRUFBRUMsTUFBTSxJQUFJLGVBRGQ7QUFFTFEsTUFBQUEsR0FGSyxpQkFFQztBQUNGLGVBQU8sS0FBS1UsUUFBWjtBQUNILE9BSkk7QUFLTFQsTUFBQUEsR0FMSyxlQUtEQyxHQUxDLEVBS0k7QUFDTCxZQUFJQSxHQUFHLElBQUksSUFBWCxFQUNJLEtBQUtRLFFBQUwsR0FBZ0JSLEdBQWhCOztBQUNKLFlBQUksQ0FBQ1YsTUFBRCxJQUFXLEtBQUtvQixTQUFMLElBQWtCLENBQWpDLEVBQW9DO0FBQ2hDLGVBQUtDLFlBQUw7QUFDSDtBQUNKO0FBWEksS0E3REQ7QUEwRVJDLElBQUFBLE1BQU0sRUFBRTtBQUNKLGlCQUFTLEtBREw7QUFFSnZCLE1BQUFBLE9BQU8sRUFBRUMsTUFBTSxJQUFJLFNBRmY7QUFHSkMsTUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCLFlBQUlTLEdBQUcsR0FBRyxLQUFLUyxPQUFMLElBQWdCLEtBQUtaLFNBQUwsSUFBa0IxQixTQUFTLENBQUMwQyxNQUF0RDtBQUNBLFlBQUksQ0FBQ2IsR0FBTCxFQUNJLEtBQUtZLE1BQUwsR0FBYyxLQUFkO0FBQ0osZUFBT1osR0FBUDtBQUNIO0FBUkcsS0ExRUE7QUFvRlJjLElBQUFBLFVBQVUsRUFBRTtBQUNSLGlCQUFTLEtBREQ7QUFFUnpCLE1BQUFBLE9BQU8sRUFBRUMsTUFBTSxJQUFJLDJDQUZYO0FBR1JDLE1BQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQixlQUFPLEtBQUtrQixPQUFaO0FBQ0g7QUFMTyxLQXBGSjtBQTJGUk0sSUFBQUEsU0FBUyxFQUFFO0FBQ1AsaUJBQVMsS0FERjtBQUVQMUIsTUFBQUEsT0FBTyxFQUFFQyxNQUFNLElBQUksMkJBRlo7QUFHUEMsTUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCLFlBQUlTLEdBQUcsR0FBRyxLQUFLUyxPQUFMLElBQWdCLENBQUMsS0FBS0ssVUFBaEM7QUFDQSxZQUFJLENBQUNkLEdBQUwsRUFDSSxLQUFLZSxTQUFMLEdBQWlCLEtBQWpCO0FBQ0osZUFBT2YsR0FBUDtBQUNIO0FBUk0sS0EzRkg7QUFxR1JnQixJQUFBQSxXQUFXLEVBQUUsQ0FyR0w7QUFzR1JDLElBQUFBLFVBQVUsRUFBRTtBQUNSL0IsTUFBQUEsSUFBSSxFQUFFakIsRUFBRSxDQUFDaUQsT0FERDtBQUVSZixNQUFBQSxLQUFLLEVBQUUsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsQ0FGQztBQUdSZCxNQUFBQSxPQUFPLEVBQUVDLE1BQU0sSUFBSSxzQkFIWDtBQUlSYyxNQUFBQSxLQUFLLEVBQUUsSUFKQztBQUtSTixNQUFBQSxHQUxRLGlCQUtGO0FBQ0YsZUFBTyxLQUFLa0IsV0FBWjtBQUNILE9BUE87QUFRUmpCLE1BQUFBLEdBUlEsZUFRSkMsR0FSSSxFQVFDO0FBQ0wsWUFBSUEsR0FBRyxJQUFJLENBQVAsSUFBWUEsR0FBRyxJQUFJLENBQXZCLEVBQTBCO0FBQ3RCLGVBQUtnQixXQUFMLEdBQW1CaEIsR0FBbkI7QUFDSDtBQUNKO0FBWk8sS0F0R0o7QUFvSFJtQixJQUFBQSxxQkFBcUIsRUFBRTtBQUNuQixpQkFBUyxDQURVO0FBRW5CakMsTUFBQUEsSUFBSSxFQUFFakIsRUFBRSxDQUFDaUQsT0FGVTtBQUduQmYsTUFBQUEsS0FBSyxFQUFFLENBQUMsQ0FBRCxFQUFJLEVBQUosRUFBUSxDQUFSLENBSFk7QUFJbkJkLE1BQUFBLE9BQU8sRUFBRUMsTUFBTSxJQUFJLCtCQUpBO0FBS25CYyxNQUFBQSxLQUFLLEVBQUU7QUFMWSxLQXBIZjtBQTJIUmdCLElBQUFBLFdBQVcsRUFBRTtBQUNULGlCQUFTLElBREE7QUFFVGxDLE1BQUFBLElBQUksRUFBRWpCLEVBQUUsQ0FBQ08sU0FBSCxDQUFhK0IsWUFGVjtBQUdUbEIsTUFBQUEsT0FBTyxFQUFFQyxNQUFNLElBQUk7QUFIVixLQTNITDtBQWdJUitCLElBQUFBLFlBQVksRUFBRTtBQUNWLGlCQUFTakQsWUFBWSxDQUFDa0QsSUFEWjtBQUVWcEMsTUFBQUEsSUFBSSxFQUFFZCxZQUZJO0FBR1ZpQixNQUFBQSxPQUFPLEVBQUVDLE1BQU0sSUFBSTtBQUhULEtBaElOO0FBcUlSaUMsSUFBQUEsaUJBQWlCLEVBQUU7QUFDZixpQkFBUyxLQURNO0FBRWZsQyxNQUFBQSxPQUFPLEVBQUVDLE1BQU0sSUFBSSxZQUZKO0FBR2ZDLE1BQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUNqQixlQUFPLEtBQUs4QixZQUFMLElBQXFCakQsWUFBWSxDQUFDb0QsTUFBekM7QUFDSDtBQUxjLEtBcklYO0FBNElSQyxJQUFBQSxhQUFhLEVBQUU7QUFDWCxpQkFBUyxJQURFO0FBRVh2QyxNQUFBQSxJQUFJLEVBQUVqQixFQUFFLENBQUNPLFNBQUgsQ0FBYStCLFlBRlI7QUFHWGxCLE1BQUFBLE9BQU8sRUFBRUMsTUFBTSxJQUFJLFFBSFI7QUFJWEMsTUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCLFlBQUlDLElBQUksR0FBRyxLQUFLNkIsWUFBTCxHQUFvQixDQUEvQjtBQUNBLFlBQUksQ0FBQzdCLElBQUwsRUFDSSxLQUFLaUMsYUFBTCxHQUFxQixJQUFyQjtBQUNKLGVBQU9qQyxJQUFQO0FBQ0g7QUFUVSxLQTVJUDtBQXVKUmtDLElBQUFBLFdBQVcsRUFBRSxDQUFDLENBdkpOO0FBd0pSQyxJQUFBQSxVQUFVLEVBQUU7QUFDUnBDLE1BQUFBLE9BQU8sRUFBRSxLQUREO0FBRVJPLE1BQUFBLEdBQUcsRUFBRSxlQUFZO0FBQ2IsZUFBTyxLQUFLNEIsV0FBWjtBQUNILE9BSk87QUFLUjNCLE1BQUFBLEdBQUcsRUFBRSxhQUFVQyxHQUFWLEVBQWU7QUFDaEIsWUFBSTRCLENBQUMsR0FBRyxJQUFSO0FBQ0EsWUFBSUMsSUFBSjs7QUFDQSxnQkFBUUQsQ0FBQyxDQUFDUCxZQUFWO0FBQ0ksZUFBS2pELFlBQVksQ0FBQ29ELE1BQWxCO0FBQTBCO0FBQ3RCLGtCQUFJLENBQUNJLENBQUMsQ0FBQ0wsaUJBQUgsSUFBd0J2QixHQUFHLElBQUk0QixDQUFDLENBQUNGLFdBQXJDLEVBQ0k7QUFDSkcsY0FBQUEsSUFBSSxHQUFHRCxDQUFDLENBQUNFLGVBQUYsQ0FBa0I5QixHQUFsQixDQUFQLENBSHNCLENBSXRCO0FBQ0E7O0FBQ0Esa0JBQUk0QixDQUFDLENBQUNGLFdBQUYsSUFBaUIsQ0FBckIsRUFDSUUsQ0FBQyxDQUFDRyxlQUFGLEdBQW9CSCxDQUFDLENBQUNGLFdBQXRCLENBREosS0FFSztBQUNERSxnQkFBQUEsQ0FBQyxDQUFDRyxlQUFGLEdBQW9CLElBQXBCO0FBQ0pILGNBQUFBLENBQUMsQ0FBQ0YsV0FBRixHQUFnQjFCLEdBQWhCO0FBQ0Esa0JBQUk2QixJQUFKLEVBQ0lBLElBQUksQ0FBQ0csUUFBTCxDQUFjQyxRQUFkLEdBQXlCLElBQXpCOztBQUNKLGtCQUFJTCxDQUFDLENBQUNHLGVBQUYsSUFBcUIsQ0FBckIsSUFBMEJILENBQUMsQ0FBQ0csZUFBRixJQUFxQkgsQ0FBQyxDQUFDRixXQUFyRCxFQUFrRTtBQUM5RCxvQkFBSVEsUUFBUSxHQUFHTixDQUFDLENBQUNFLGVBQUYsQ0FBa0JGLENBQUMsQ0FBQ0csZUFBcEIsQ0FBZjs7QUFDQSxvQkFBSUcsUUFBSixFQUFjO0FBQ1ZBLGtCQUFBQSxRQUFRLENBQUNGLFFBQVQsQ0FBa0JDLFFBQWxCLEdBQTZCLEtBQTdCO0FBQ0g7QUFDSjs7QUFDRCxrQkFBSUwsQ0FBQyxDQUFDSCxhQUFOLEVBQXFCO0FBQ2pCeEQsZ0JBQUFBLEVBQUUsQ0FBQ08sU0FBSCxDQUFhK0IsWUFBYixDQUEwQjRCLFVBQTFCLENBQXFDLENBQUNQLENBQUMsQ0FBQ0gsYUFBSCxDQUFyQyxFQUF3REksSUFBeEQsRUFBOEQ3QixHQUFHLEdBQUcsS0FBS29DLGVBQXpFLEVBQTBGUixDQUFDLENBQUNHLGVBQUYsR0FBb0IsS0FBS0ssZUFBbkg7QUFDSDs7QUFDRDtBQUNIOztBQUNELGVBQUtoRSxZQUFZLENBQUNpRSxJQUFsQjtBQUF3QjtBQUNwQlIsY0FBQUEsSUFBSSxHQUFHRCxDQUFDLENBQUNFLGVBQUYsQ0FBa0I5QixHQUFsQixDQUFQO0FBQ0Esa0JBQUksQ0FBQzZCLElBQUwsRUFDSTtBQUNKLGtCQUFJRCxDQUFDLENBQUNGLFdBQUYsSUFBaUIsQ0FBckIsRUFDSUUsQ0FBQyxDQUFDRyxlQUFGLEdBQW9CSCxDQUFDLENBQUNGLFdBQXRCO0FBQ0pFLGNBQUFBLENBQUMsQ0FBQ0YsV0FBRixHQUFnQjFCLEdBQWhCO0FBQ0Esa0JBQUlSLElBQUksR0FBRyxDQUFDcUMsSUFBSSxDQUFDRyxRQUFMLENBQWNDLFFBQTFCO0FBQ0FKLGNBQUFBLElBQUksQ0FBQ0csUUFBTCxDQUFjQyxRQUFkLEdBQXlCekMsSUFBekI7QUFDQSxrQkFBSThDLEdBQUcsR0FBR1YsQ0FBQyxDQUFDVyxZQUFGLENBQWVDLE9BQWYsQ0FBdUJ4QyxHQUF2QixDQUFWOztBQUNBLGtCQUFJUixJQUFJLElBQUk4QyxHQUFHLEdBQUcsQ0FBbEIsRUFBcUI7QUFDakJWLGdCQUFBQSxDQUFDLENBQUNXLFlBQUYsQ0FBZUUsSUFBZixDQUFvQnpDLEdBQXBCO0FBQ0gsZUFGRCxNQUVPLElBQUksQ0FBQ1IsSUFBRCxJQUFTOEMsR0FBRyxJQUFJLENBQXBCLEVBQXVCO0FBQzFCVixnQkFBQUEsQ0FBQyxDQUFDVyxZQUFGLENBQWVHLE1BQWYsQ0FBc0JKLEdBQXRCLEVBQTJCLENBQTNCO0FBQ0g7O0FBQ0Qsa0JBQUlWLENBQUMsQ0FBQ0gsYUFBTixFQUFxQjtBQUNqQnhELGdCQUFBQSxFQUFFLENBQUNPLFNBQUgsQ0FBYStCLFlBQWIsQ0FBMEI0QixVQUExQixDQUFxQyxDQUFDUCxDQUFDLENBQUNILGFBQUgsQ0FBckMsRUFBd0RJLElBQXhELEVBQThEN0IsR0FBRyxHQUFHLEtBQUtvQyxlQUF6RSxFQUEwRlIsQ0FBQyxDQUFDRyxlQUFGLEdBQW9CLEtBQUtLLGVBQW5ILEVBQW9JNUMsSUFBcEk7QUFDSDs7QUFDRDtBQUNIO0FBNUNMO0FBOENIO0FBdERPLEtBeEpKO0FBZ05Sa0IsSUFBQUEsU0FBUyxFQUFFO0FBQ1AsaUJBQVMsQ0FERjtBQUVQaUMsTUFBQUEsWUFBWSxFQUFFO0FBRlAsS0FoTkg7QUFvTlJDLElBQUFBLFFBQVEsRUFBRTtBQUNOckQsTUFBQUEsT0FBTyxFQUFFLEtBREg7QUFFTk8sTUFBQUEsR0FGTSxpQkFFQTtBQUNGLGVBQU8sS0FBS3NDLGVBQVo7QUFDSCxPQUpLO0FBS05yQyxNQUFBQSxHQUxNLGVBS0ZDLEdBTEUsRUFLRztBQUNMLFlBQUk0QixDQUFDLEdBQUcsSUFBUjtBQUNBLFlBQUksQ0FBQ0EsQ0FBQyxDQUFDaUIsV0FBRixFQUFMLEVBQ0k7O0FBQ0osWUFBSTdDLEdBQUcsSUFBSSxJQUFQLElBQWVBLEdBQUcsR0FBRyxDQUF6QixFQUE0QjtBQUN4Qi9CLFVBQUFBLEVBQUUsQ0FBQzZFLEtBQUgsQ0FBUywwQkFBVCxFQUFxQzlDLEdBQXJDO0FBQ0E7QUFDSDs7QUFDRDRCLFFBQUFBLENBQUMsQ0FBQ1EsZUFBRixHQUFvQlIsQ0FBQyxDQUFDbEIsU0FBRixHQUFjVixHQUFsQztBQUNBNEIsUUFBQUEsQ0FBQyxDQUFDbUIsWUFBRixHQUFpQixJQUFqQjs7QUFFQSxZQUFJbkIsQ0FBQyxDQUFDcEIsUUFBTixFQUFnQjtBQUNab0IsVUFBQUEsQ0FBQyxDQUFDb0IsY0FBRjs7QUFDQSxjQUFJcEIsQ0FBQyxDQUFDaEIsTUFBTixFQUFjO0FBQ1ZnQixZQUFBQSxDQUFDLENBQUNsQixTQUFGLEdBQWNrQixDQUFDLENBQUNxQixVQUFGLEdBQWVyQixDQUFDLENBQUNsQixTQUEvQjtBQUNIOztBQUNEa0IsVUFBQUEsQ0FBQyxDQUFDakIsWUFBRjs7QUFDQSxjQUFJLENBQUNpQixDQUFDLENBQUNULHFCQUFILElBQTRCUyxDQUFDLENBQUMvQixTQUFGLElBQWUxQixTQUFTLENBQUNrQyxJQUF6RCxFQUNJdUIsQ0FBQyxDQUFDc0IsVUFBRixHQUFldEIsQ0FBQyxDQUFDdUIsYUFBakI7QUFDUCxTQVJELE1BUU87QUFDSCxjQUFJQyxNQUFNLEdBQUd4QixDQUFDLENBQUN5QixPQUFGLENBQVVDLFlBQVYsQ0FBdUJyRixFQUFFLENBQUNzRixNQUExQixDQUFiOztBQUNBLGNBQUlILE1BQUosRUFBWTtBQUNSQSxZQUFBQSxNQUFNLENBQUNJLE9BQVAsR0FBaUIsSUFBakI7QUFDSDs7QUFDRDVCLFVBQUFBLENBQUMsQ0FBQzZCLGlCQUFGOztBQUVBN0IsVUFBQUEsQ0FBQyxDQUFDOEIsV0FBRixHQUFnQixDQUFoQjs7QUFDQSxjQUFJOUIsQ0FBQyxDQUFDVCxxQkFBRixHQUEwQixDQUE5QixFQUFpQztBQUM3QjtBQUNBLGdCQUFJd0MsR0FBRyxHQUFHL0IsQ0FBQyxDQUFDVCxxQkFBRixHQUEwQlMsQ0FBQyxDQUFDbEIsU0FBNUIsR0FBd0NrQixDQUFDLENBQUNsQixTQUExQyxHQUFzRGtCLENBQUMsQ0FBQ1QscUJBQWxFOztBQUNBLGlCQUFLLElBQUl5QyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHRCxHQUFwQixFQUF5QkMsQ0FBQyxFQUExQixFQUE4QjtBQUMxQmhDLGNBQUFBLENBQUMsQ0FBQ2lDLG9CQUFGLENBQXVCRCxDQUF2QjtBQUNIOztBQUNELGdCQUFJaEMsQ0FBQyxDQUFDVCxxQkFBRixHQUEwQlMsQ0FBQyxDQUFDbEIsU0FBaEMsRUFBMkM7QUFDdkNrQixjQUFBQSxDQUFDLENBQUNrQyxjQUFGLEdBQW1CbEMsQ0FBQyxDQUFDVCxxQkFBckI7QUFDQVMsY0FBQUEsQ0FBQyxDQUFDbUMsV0FBRixHQUFnQixLQUFoQjtBQUNIO0FBQ0osV0FWRCxNQVVPO0FBQ0gsaUJBQUssSUFBSUgsRUFBQyxHQUFHLENBQWIsRUFBZ0JBLEVBQUMsR0FBRzVELEdBQXBCLEVBQXlCNEQsRUFBQyxFQUExQixFQUE4QjtBQUMxQmhDLGNBQUFBLENBQUMsQ0FBQ2lDLG9CQUFGLENBQXVCRCxFQUF2QjtBQUNIOztBQUNEaEMsWUFBQUEsQ0FBQyxDQUFDb0MsY0FBRixHQUFtQmhFLEdBQW5CO0FBQ0g7QUFDSjtBQUNKO0FBakRLO0FBcE5GLEdBWFA7QUFvUkxpRSxFQUFBQSxNQXBSSyxvQkFvUkk7QUFDTCxTQUFLQyxLQUFMO0FBQ0gsR0F0Ukk7QUF3UkxDLEVBQUFBLFNBeFJLLHVCQXdSTztBQUNSLFFBQUksS0FBS0MsUUFBTCxJQUFpQixLQUFLQSxRQUFMLENBQWNDLE9BQW5DLEVBQ0ksS0FBS0QsUUFBTCxDQUFjRSxPQUFkLEdBRkksQ0FHUjs7QUFDQSxXQUFPLEtBQUtDLEtBQUwsQ0FBV0MsSUFBWCxFQUFQLEVBQTBCO0FBQ3RCLFVBQUlDLElBQUksR0FBRyxLQUFLRixLQUFMLENBQVd6RSxHQUFYLEVBQVg7O0FBQ0EyRSxNQUFBQSxJQUFJLENBQUNILE9BQUw7QUFDSCxLQVBPLENBUVI7QUFDQTs7QUFDSCxHQWxTSTtBQW9TTEksRUFBQUEsUUFwU0ssc0JBb1NNO0FBQ1A7QUFDQSxTQUFLQyxjQUFMOztBQUNBLFNBQUtULEtBQUw7QUFDSCxHQXhTSTtBQTBTTFUsRUFBQUEsU0ExU0ssdUJBMFNPO0FBQ1I7QUFDQSxTQUFLQyxnQkFBTDtBQUNILEdBN1NJO0FBOFNMO0FBQ0FGLEVBQUFBLGNBL1NLLDRCQStTWTtBQUNiLFFBQUkvQyxDQUFDLEdBQUcsSUFBUjtBQUNBQSxJQUFBQSxDQUFDLENBQUM2QyxJQUFGLENBQU9LLEVBQVAsQ0FBVTdHLEVBQUUsQ0FBQ21CLElBQUgsQ0FBUTJGLFNBQVIsQ0FBa0JDLFdBQTVCLEVBQXlDcEQsQ0FBQyxDQUFDcUQsYUFBM0MsRUFBMERyRCxDQUExRCxFQUE2RCxJQUE3RDtBQUNBQSxJQUFBQSxDQUFDLENBQUM2QyxJQUFGLENBQU9LLEVBQVAsQ0FBVSxVQUFWLEVBQXNCbEQsQ0FBQyxDQUFDc0QsVUFBeEIsRUFBb0N0RCxDQUFwQyxFQUF1QyxJQUF2QztBQUNBQSxJQUFBQSxDQUFDLENBQUM2QyxJQUFGLENBQU9LLEVBQVAsQ0FBVTdHLEVBQUUsQ0FBQ21CLElBQUgsQ0FBUTJGLFNBQVIsQ0FBa0JJLFlBQTVCLEVBQTBDdkQsQ0FBQyxDQUFDd0QsaUJBQTVDLEVBQStEeEQsQ0FBL0QsRUFBa0UsSUFBbEU7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDNkMsSUFBRixDQUFPSyxFQUFQLENBQVUsY0FBVixFQUEwQmxELENBQUMsQ0FBQ3lELGNBQTVCLEVBQTRDekQsQ0FBNUMsRUFBK0MsSUFBL0M7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDNkMsSUFBRixDQUFPSyxFQUFQLENBQVUsY0FBVixFQUEwQmxELENBQUMsQ0FBQzBELGNBQTVCLEVBQTRDMUQsQ0FBNUMsRUFBK0MsSUFBL0M7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDNkMsSUFBRixDQUFPSyxFQUFQLENBQVUsV0FBVixFQUF1QmxELENBQUMsQ0FBQ2pCLFlBQXpCLEVBQXVDaUIsQ0FBdkMsRUFBMEMsSUFBMUM7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDNkMsSUFBRixDQUFPSyxFQUFQLENBQVU3RyxFQUFFLENBQUNtQixJQUFILENBQVEyRixTQUFSLENBQWtCUSxZQUE1QixFQUEwQzNELENBQUMsQ0FBQzRELGNBQTVDLEVBQTRENUQsQ0FBNUQ7QUFDSCxHQXhUSTtBQXlUTDtBQUNBaUQsRUFBQUEsZ0JBMVRLLDhCQTBUYztBQUNmLFFBQUlqRCxDQUFDLEdBQUcsSUFBUjtBQUNBQSxJQUFBQSxDQUFDLENBQUM2QyxJQUFGLENBQU9nQixHQUFQLENBQVd4SCxFQUFFLENBQUNtQixJQUFILENBQVEyRixTQUFSLENBQWtCQyxXQUE3QixFQUEwQ3BELENBQUMsQ0FBQ3FELGFBQTVDLEVBQTJEckQsQ0FBM0QsRUFBOEQsSUFBOUQ7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDNkMsSUFBRixDQUFPZ0IsR0FBUCxDQUFXLFVBQVgsRUFBdUI3RCxDQUFDLENBQUNzRCxVQUF6QixFQUFxQ3RELENBQXJDLEVBQXdDLElBQXhDO0FBQ0FBLElBQUFBLENBQUMsQ0FBQzZDLElBQUYsQ0FBT2dCLEdBQVAsQ0FBV3hILEVBQUUsQ0FBQ21CLElBQUgsQ0FBUTJGLFNBQVIsQ0FBa0JJLFlBQTdCLEVBQTJDdkQsQ0FBQyxDQUFDd0QsaUJBQTdDLEVBQWdFeEQsQ0FBaEUsRUFBbUUsSUFBbkU7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDNkMsSUFBRixDQUFPZ0IsR0FBUCxDQUFXLGNBQVgsRUFBMkI3RCxDQUFDLENBQUN5RCxjQUE3QixFQUE2Q3pELENBQTdDLEVBQWdELElBQWhEO0FBQ0FBLElBQUFBLENBQUMsQ0FBQzZDLElBQUYsQ0FBT2dCLEdBQVAsQ0FBVyxjQUFYLEVBQTJCN0QsQ0FBQyxDQUFDMEQsY0FBN0IsRUFBNkMxRCxDQUE3QyxFQUFnRCxJQUFoRDtBQUNBQSxJQUFBQSxDQUFDLENBQUM2QyxJQUFGLENBQU9nQixHQUFQLENBQVcsV0FBWCxFQUF3QjdELENBQUMsQ0FBQ2pCLFlBQTFCLEVBQXdDaUIsQ0FBeEMsRUFBMkMsSUFBM0M7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDNkMsSUFBRixDQUFPZ0IsR0FBUCxDQUFXeEgsRUFBRSxDQUFDbUIsSUFBSCxDQUFRMkYsU0FBUixDQUFrQlEsWUFBN0IsRUFBMkMzRCxDQUFDLENBQUM0RCxjQUE3QyxFQUE2RDVELENBQTdEO0FBQ0gsR0FuVUk7QUFvVUw7QUFDQXNDLEVBQUFBLEtBclVLLG1CQXFVRztBQUNKLFFBQUl0QyxDQUFDLEdBQUcsSUFBUjtBQUNBLFFBQUlBLENBQUMsQ0FBQzhELE9BQU4sRUFDSTtBQUVKOUQsSUFBQUEsQ0FBQyxDQUFDK0QsV0FBRixHQUFnQi9ELENBQUMsQ0FBQzZDLElBQUYsQ0FBT25CLFlBQVAsQ0FBb0JyRixFQUFFLENBQUNZLFVBQXZCLENBQWhCO0FBRUErQyxJQUFBQSxDQUFDLENBQUN5QixPQUFGLEdBQVl6QixDQUFDLENBQUMrRCxXQUFGLENBQWN0QyxPQUExQjs7QUFDQSxRQUFJLENBQUN6QixDQUFDLENBQUN5QixPQUFQLEVBQWdCO0FBQ1pwRixNQUFBQSxFQUFFLENBQUM2RSxLQUFILENBQVNsQixDQUFDLENBQUM2QyxJQUFGLENBQU9tQixJQUFQLEdBQWMsaUNBQXZCO0FBQ0E7QUFDSDs7QUFFRGhFLElBQUFBLENBQUMsQ0FBQ2lFLE9BQUYsR0FBWWpFLENBQUMsQ0FBQ3lCLE9BQUYsQ0FBVUMsWUFBVixDQUF1QnJGLEVBQUUsQ0FBQ3NGLE1BQTFCLENBQVo7QUFFQTNCLElBQUFBLENBQUMsQ0FBQ2tFLE1BQUYsR0FBV2xFLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVTNHLElBQXJCLENBZkksQ0FldUI7O0FBQzNCMEMsSUFBQUEsQ0FBQyxDQUFDbUUsV0FBRixHQUFnQm5FLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVUcsVUFBMUIsQ0FoQkksQ0FnQmtDOztBQUN0Q3BFLElBQUFBLENBQUMsQ0FBQ3FFLFVBQUYsR0FBZXJFLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVUssU0FBekI7QUFFQXRFLElBQUFBLENBQUMsQ0FBQ3VFLE9BQUYsR0FBWXZFLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVU8sVUFBdEIsQ0FuQkksQ0FtQm9DOztBQUN4Q3hFLElBQUFBLENBQUMsQ0FBQ3lFLFNBQUYsR0FBY3pFLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVVMsWUFBeEIsQ0FwQkksQ0FvQm9DOztBQUN4QzFFLElBQUFBLENBQUMsQ0FBQzJFLFVBQUYsR0FBZTNFLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVVcsYUFBekIsQ0FyQkksQ0FxQm9DOztBQUN4QzVFLElBQUFBLENBQUMsQ0FBQzZFLFFBQUYsR0FBYTdFLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVWEsV0FBdkIsQ0F0QkksQ0FzQm9DOztBQUV4QzlFLElBQUFBLENBQUMsQ0FBQytFLFVBQUYsR0FBZS9FLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVWUsUUFBekIsQ0F4QkksQ0F3Qm9DOztBQUN4Q2hGLElBQUFBLENBQUMsQ0FBQ2lGLFFBQUYsR0FBYWpGLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVWlCLFFBQXZCLENBekJJLENBeUJvQzs7QUFFeENsRixJQUFBQSxDQUFDLENBQUNtRixXQUFGLENBM0JJLENBMkJXOztBQUVmbkYsSUFBQUEsQ0FBQyxDQUFDb0YsWUFBRixHQUFpQnBGLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVW9CLGlCQUEzQixDQTdCSSxDQTZCMEM7O0FBQzlDckYsSUFBQUEsQ0FBQyxDQUFDc0YsY0FBRixHQUFtQnRGLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVXNCLG1CQUE3QixDQTlCSSxDQThCOEM7O0FBRWxEdkYsSUFBQUEsQ0FBQyxDQUFDd0YsZUFBRixDQUFrQm5KLEVBQUUsQ0FBQ29KLFdBQUgsQ0FBZXpGLENBQUMsQ0FBQzVDLFlBQUYsSUFBa0JoQixZQUFZLENBQUMyQixNQUEvQixHQUF3Q2lDLENBQUMsQ0FBQ25DLFNBQTFDLEdBQXNEbUMsQ0FBQyxDQUFDekMsT0FBdkUsQ0FBbEI7QUFFQSxRQUFJeUMsQ0FBQyxDQUFDaEMsVUFBRixJQUFnQnpCLFNBQVMsQ0FBQ21KLFFBQTFCLElBQXNDMUYsQ0FBQyxDQUFDaEMsVUFBRixJQUFnQnpCLFNBQVMsQ0FBQ2tDLElBQXBFLEVBQXlFO0FBQ3JFdUIsTUFBQUEsQ0FBQyxDQUFDK0QsV0FBRixDQUFjNEIsT0FBZCxHQUF3QixLQUF4QjtBQUNKLFFBQUksQ0FBQzNGLENBQUMsQ0FBQ25CLE9BQVAsRUFBd0I7QUFDcEJtQixNQUFBQSxDQUFDLENBQUNkLFVBQUYsR0FBZSxLQUFmO0FBRUpjLElBQUFBLENBQUMsQ0FBQzRGLGdCQUFGLEdBQXFCLEVBQXJCLENBdkNJLENBdUNvQjs7QUFDeEI1RixJQUFBQSxDQUFDLENBQUM2RixXQUFGLEdBQWdCLEVBQWhCLENBeENJLENBd0NvQjs7QUFDeEI3RixJQUFBQSxDQUFDLENBQUMyQyxLQUFGLEdBQVUsSUFBSXRHLEVBQUUsQ0FBQ3lKLFFBQVAsRUFBVixDQXpDSSxDQXlDNEI7O0FBQ2hDOUYsSUFBQUEsQ0FBQyxDQUFDbUIsWUFBRixHQUFpQixLQUFqQixDQTFDSSxDQTBDb0I7O0FBQ3hCbkIsSUFBQUEsQ0FBQyxDQUFDa0MsY0FBRixHQUFtQixDQUFuQixDQTNDSSxDQTJDb0I7O0FBQ3hCbEMsSUFBQUEsQ0FBQyxDQUFDbUMsV0FBRixHQUFnQixJQUFoQixDQTVDSSxDQTRDb0I7O0FBRXhCbkMsSUFBQUEsQ0FBQyxDQUFDc0IsVUFBRixHQUFlLENBQWYsQ0E5Q0ksQ0E4Q2dCOztBQUVwQixRQUFJdEIsQ0FBQyxDQUFDaEIsTUFBTixFQUFjO0FBQUU7QUFDWmdCLE1BQUFBLENBQUMsQ0FBQytELFdBQUYsQ0FBY2dDLHFCQUFkLEdBQXNDLEtBQUtBLHFCQUFMLENBQTJCQyxJQUEzQixDQUFnQ2hHLENBQWhDLENBQXRDOztBQUNBQSxNQUFBQSxDQUFDLENBQUMrRCxXQUFGLENBQWNrQyx3QkFBZCxHQUF5QyxZQUFZO0FBQ2pELGVBQU8sS0FBUDtBQUNILE9BRkQsQ0FGVSxDQUtWO0FBQ0E7QUFDQTs7QUFDSDs7QUFFRCxZQUFRakcsQ0FBQyxDQUFDa0UsTUFBVjtBQUNJLFdBQUs3SCxFQUFFLENBQUNzRixNQUFILENBQVV1RSxJQUFWLENBQWVDLFVBQXBCO0FBQWdDO0FBQzVCLGtCQUFRbkcsQ0FBQyxDQUFDc0YsY0FBVjtBQUNJLGlCQUFLakosRUFBRSxDQUFDc0YsTUFBSCxDQUFVeUUsbUJBQVYsQ0FBOEJDLGFBQW5DO0FBQ0lyRyxjQUFBQSxDQUFDLENBQUNzRyxjQUFGLEdBQW1CLENBQW5CO0FBQ0E7O0FBQ0osaUJBQUtqSyxFQUFFLENBQUNzRixNQUFILENBQVV5RSxtQkFBVixDQUE4QkcsYUFBbkM7QUFDSXZHLGNBQUFBLENBQUMsQ0FBQ3NHLGNBQUYsR0FBbUIsQ0FBbkI7QUFDQTtBQU5SOztBQVFBO0FBQ0g7O0FBQ0QsV0FBS2pLLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXVFLElBQVYsQ0FBZU0sUUFBcEI7QUFBOEI7QUFDMUIsa0JBQVF4RyxDQUFDLENBQUNvRixZQUFWO0FBQ0ksaUJBQUsvSSxFQUFFLENBQUNzRixNQUFILENBQVU4RSxpQkFBVixDQUE0QkMsYUFBakM7QUFDSTFHLGNBQUFBLENBQUMsQ0FBQ3NHLGNBQUYsR0FBbUIsQ0FBbkI7QUFDQTs7QUFDSixpQkFBS2pLLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVThFLGlCQUFWLENBQTRCRSxhQUFqQztBQUNJM0csY0FBQUEsQ0FBQyxDQUFDc0csY0FBRixHQUFtQixDQUFuQjtBQUNBO0FBTlI7O0FBUUE7QUFDSDs7QUFDRCxXQUFLakssRUFBRSxDQUFDc0YsTUFBSCxDQUFVdUUsSUFBVixDQUFlVSxJQUFwQjtBQUEwQjtBQUN0QixrQkFBUTVHLENBQUMsQ0FBQ3FFLFVBQVY7QUFDSSxpQkFBS2hJLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVWtGLGFBQVYsQ0FBd0JWLFVBQTdCO0FBQ0ksc0JBQVFuRyxDQUFDLENBQUNvRixZQUFWO0FBQ0kscUJBQUsvSSxFQUFFLENBQUNzRixNQUFILENBQVU4RSxpQkFBVixDQUE0QkMsYUFBakM7QUFDSTFHLGtCQUFBQSxDQUFDLENBQUNzRyxjQUFGLEdBQW1CLENBQW5CO0FBQ0E7O0FBQ0oscUJBQUtqSyxFQUFFLENBQUNzRixNQUFILENBQVU4RSxpQkFBVixDQUE0QkUsYUFBakM7QUFDSTNHLGtCQUFBQSxDQUFDLENBQUNzRyxjQUFGLEdBQW1CLENBQW5CO0FBQ0E7QUFOUjs7QUFRQTs7QUFDSixpQkFBS2pLLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVWtGLGFBQVYsQ0FBd0JMLFFBQTdCO0FBQ0ksc0JBQVF4RyxDQUFDLENBQUNzRixjQUFWO0FBQ0kscUJBQUtqSixFQUFFLENBQUNzRixNQUFILENBQVV5RSxtQkFBVixDQUE4QkMsYUFBbkM7QUFDSXJHLGtCQUFBQSxDQUFDLENBQUNzRyxjQUFGLEdBQW1CLENBQW5CO0FBQ0E7O0FBQ0oscUJBQUtqSyxFQUFFLENBQUNzRixNQUFILENBQVV5RSxtQkFBVixDQUE4QkcsYUFBbkM7QUFDSXZHLGtCQUFBQSxDQUFDLENBQUNzRyxjQUFGLEdBQW1CLENBQW5CO0FBQ0E7QUFOUjs7QUFRQTtBQXBCUjs7QUFzQkE7QUFDSDtBQS9DTCxLQTFESSxDQTJHSjs7O0FBQ0F0RyxJQUFBQSxDQUFDLENBQUN5QixPQUFGLENBQVVxRixRQUFWLENBQW1CQyxPQUFuQixDQUEyQixVQUFBQyxLQUFLLEVBQUk7QUFDaENBLE1BQUFBLEtBQUssQ0FBQ0MsZ0JBQU47QUFDQSxVQUFJRCxLQUFLLENBQUN2RSxPQUFWLEVBQ0l1RSxLQUFLLENBQUN0RSxPQUFOO0FBQ1AsS0FKRDtBQUtBMUMsSUFBQUEsQ0FBQyxDQUFDOEQsT0FBRixHQUFZLElBQVo7QUFDSCxHQXZiSTs7QUF3Ykw7Ozs7QUFJQWlDLEVBQUFBLHFCQTViSyxpQ0E0YmlCbUIsRUE1YmpCLEVBNGJxQjtBQUN0QjtBQUNBLFFBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFNBQUtwRCxXQUFMLENBQWlCcUQsMEJBQWpCLElBQStDRixFQUFFLElBQUksSUFBSUMsYUFBUixDQUFqRDtBQUVBLFFBQUlFLFVBQVUsR0FBR0MsSUFBSSxDQUFDQyxHQUFMLENBQVMsQ0FBVCxFQUFZLEtBQUt4RCxXQUFMLENBQWlCcUQsMEJBQWpCLEdBQThDLEtBQUtyRCxXQUFMLENBQWlCeUQsb0JBQTNFLENBQWpCOztBQUNBLFFBQUksS0FBS3pELFdBQUwsQ0FBaUIwRCxvQkFBckIsRUFBMkM7QUFDdkMsVUFBSUMsSUFBSSxHQUFHTCxVQUFVLEdBQUcsQ0FBeEI7QUFDQUEsTUFBQUEsVUFBVSxHQUFHSyxJQUFJLEdBQUdBLElBQVAsR0FBY0EsSUFBZCxHQUFxQkEsSUFBckIsR0FBNEJBLElBQTVCLEdBQW1DLENBQWhEO0FBQ0g7O0FBRUQsUUFBSUMsV0FBVyxHQUFHLEtBQUs1RCxXQUFMLENBQWlCNkQsd0JBQWpCLENBQTBDQyxHQUExQyxDQUE4QyxLQUFLOUQsV0FBTCxDQUFpQitELHNCQUFqQixDQUF3Q0MsR0FBeEMsQ0FBNENWLFVBQTVDLENBQTlDLENBQWxCOztBQUNBLFFBQUlXLE9BQU8sR0FBRyxLQUFLakUsV0FBTCxDQUFpQmtFLHlCQUFqQixFQUFkOztBQUNBLFFBQUlDLFVBQVUsR0FBR1osSUFBSSxDQUFDYSxHQUFMLENBQVNkLFVBQVUsR0FBRyxDQUF0QixLQUE0QlcsT0FBN0MsQ0Fic0IsQ0FjdEI7O0FBRUEsUUFBSUksU0FBUyxHQUFHZCxJQUFJLENBQUNhLEdBQUwsQ0FBU2QsVUFBVSxHQUFHLENBQXRCLEtBQTRCLEtBQUt0RCxXQUFMLENBQWlCa0UseUJBQWpCLEVBQTVDOztBQUNBLFFBQUlHLFNBQVMsSUFBSSxDQUFDLEtBQUtyRSxXQUFMLENBQWlCc0UscUNBQW5DLEVBQTBFO0FBQ3RFLFdBQUt0RSxXQUFMLENBQWlCdUUsY0FBakIsQ0FBZ0MsNkJBQWhDOztBQUNBLFdBQUt2RSxXQUFMLENBQWlCc0UscUNBQWpCLEdBQXlELElBQXpEO0FBQ0gsS0FwQnFCLENBc0J0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxRQUFJSCxVQUFKLEVBQWdCO0FBQ1osV0FBS25FLFdBQUwsQ0FBaUJ3RSxjQUFqQixHQUFrQyxLQUFsQztBQUNIOztBQUVELFFBQUlDLFNBQVMsR0FBR2IsV0FBVyxDQUFDakgsR0FBWixDQUFnQixLQUFLcUQsV0FBTCxDQUFpQjBFLGtCQUFqQixFQUFoQixDQUFoQixDQXpDc0IsQ0EwQ3RCOztBQUNBLFNBQUsxRSxXQUFMLENBQWlCMkUsWUFBakIsQ0FBOEIsS0FBSzNFLFdBQUwsQ0FBaUI0RSxXQUFqQixDQUE2QkgsU0FBN0IsQ0FBOUIsRUFBdUVOLFVBQXZFOztBQUNBLFNBQUtuRSxXQUFMLENBQWlCdUUsY0FBakIsQ0FBZ0MsV0FBaEMsRUE1Q3NCLENBOEN0Qjs7O0FBQ0EsUUFBSSxDQUFDLEtBQUt2RSxXQUFMLENBQWlCd0UsY0FBdEIsRUFBc0M7QUFDbEMsV0FBS3hFLFdBQUwsQ0FBaUI2RSxXQUFqQixHQUErQixLQUEvQjtBQUNBLFdBQUs3RSxXQUFMLENBQWlCOEUsVUFBakIsR0FBOEIsS0FBOUI7O0FBQ0EsV0FBSzlFLFdBQUwsQ0FBaUJ1RSxjQUFqQixDQUFnQyxjQUFoQztBQUNIO0FBQ0osR0FoZkk7QUFpZkw7QUFDQTlDLEVBQUFBLGVBbGZLLDJCQWtmV3ZGLElBbGZYLEVBa2ZpQjtBQUNsQixRQUFJLENBQUNBLElBQUwsRUFDSTtBQUNKLFFBQUlELENBQUMsR0FBRyxJQUFSO0FBQ0FBLElBQUFBLENBQUMsQ0FBQ3dDLFFBQUYsR0FBYXZDLElBQWI7QUFFQSxRQUFJRCxDQUFDLENBQUNtRSxXQUFGLElBQWlCOUgsRUFBRSxDQUFDc0YsTUFBSCxDQUFVbUgsVUFBVixDQUFxQkMsUUFBMUMsRUFDSS9JLENBQUMsQ0FBQ2dKLFNBQUYsR0FBY2hKLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVWdGLFFBQXhCLENBREosS0FHSWpKLENBQUMsQ0FBQ2dKLFNBQUYsR0FBYyxJQUFJM00sRUFBRSxDQUFDdUcsSUFBUCxDQUFZM0MsSUFBSSxDQUFDaUosS0FBakIsRUFBd0JqSixJQUFJLENBQUNrSixNQUE3QixDQUFkLENBVGMsQ0FXbEI7O0FBQ0EsUUFBSUMsR0FBRyxHQUFHbkosSUFBSSxDQUFDeUIsWUFBTCxDQUFrQmpGLFFBQWxCLENBQVY7QUFDQSxRQUFJNE0sTUFBTSxHQUFHLEtBQWI7QUFDQSxRQUFJLENBQUNELEdBQUwsRUFDSUMsTUFBTSxHQUFHLElBQVQ7O0FBQ0osUUFBSUQsR0FBSixFQUFTO0FBQ0wsVUFBSSxDQUFDQSxHQUFHLENBQUNFLE9BQUwsSUFBZ0IsQ0FBQ3JKLElBQUksQ0FBQ3lCLFlBQUwsQ0FBa0JyRixFQUFFLENBQUNrTixNQUFyQixDQUFyQixFQUFtRDtBQUMvQ0YsUUFBQUEsTUFBTSxHQUFHLElBQVQ7QUFDSDtBQUNKOztBQUNELFFBQUlBLE1BQUosRUFBWTtBQUNSckosTUFBQUEsQ0FBQyxDQUFDUCxZQUFGLEdBQWlCakQsWUFBWSxDQUFDa0QsSUFBOUI7QUFDSDs7QUFDRDBKLElBQUFBLEdBQUcsR0FBR25KLElBQUksQ0FBQ3lCLFlBQUwsQ0FBa0JyRixFQUFFLENBQUNtTixNQUFyQixDQUFOOztBQUNBLFFBQUlKLEdBQUcsSUFBSUEsR0FBRyxDQUFDeEgsT0FBZixFQUF3QjtBQUNwQjVCLE1BQUFBLENBQUMsQ0FBQ3lKLGlCQUFGLEdBQXNCLElBQXRCO0FBQ0g7O0FBQ0QsUUFBSXpKLENBQUMsQ0FBQ1AsWUFBRixJQUFrQmpELFlBQVksQ0FBQ2lFLElBQW5DLEVBQ0lULENBQUMsQ0FBQ1csWUFBRixHQUFpQixFQUFqQjs7QUFFSixZQUFRWCxDQUFDLENBQUNrRSxNQUFWO0FBQ0ksV0FBSzdILEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXVFLElBQVYsQ0FBZUMsVUFBcEI7QUFDSW5HLFFBQUFBLENBQUMsQ0FBQ21GLFdBQUYsR0FBZ0IsQ0FBaEI7QUFDQW5GLFFBQUFBLENBQUMsQ0FBQzBKLFNBQUYsR0FBYyxLQUFkO0FBQ0E7O0FBQ0osV0FBS3JOLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXVFLElBQVYsQ0FBZU0sUUFBcEI7QUFDSXhHLFFBQUFBLENBQUMsQ0FBQ21GLFdBQUYsR0FBZ0IsQ0FBaEI7QUFDQW5GLFFBQUFBLENBQUMsQ0FBQzBKLFNBQUYsR0FBYyxJQUFkO0FBQ0E7O0FBQ0osV0FBS3JOLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXVFLElBQVYsQ0FBZVUsSUFBcEI7QUFDSSxnQkFBUTVHLENBQUMsQ0FBQ3FFLFVBQVY7QUFDSSxlQUFLaEksRUFBRSxDQUFDc0YsTUFBSCxDQUFVa0YsYUFBVixDQUF3QlYsVUFBN0I7QUFDSTtBQUNBLGdCQUFJd0QsS0FBSyxHQUFHM0osQ0FBQyxDQUFDeUIsT0FBRixDQUFVeUgsS0FBVixHQUFrQmxKLENBQUMsQ0FBQzZFLFFBQXBCLEdBQStCN0UsQ0FBQyxDQUFDeUUsU0FBN0M7QUFDQXpFLFlBQUFBLENBQUMsQ0FBQ21GLFdBQUYsR0FBZ0JtQyxJQUFJLENBQUNzQyxLQUFMLENBQVcsQ0FBQ0QsS0FBSyxHQUFHM0osQ0FBQyxDQUFDK0UsVUFBWCxLQUEwQi9FLENBQUMsQ0FBQ2dKLFNBQUYsQ0FBWUUsS0FBWixHQUFvQmxKLENBQUMsQ0FBQytFLFVBQWhELENBQVgsQ0FBaEI7QUFDQS9FLFlBQUFBLENBQUMsQ0FBQzBKLFNBQUYsR0FBYyxJQUFkO0FBQ0E7O0FBQ0osZUFBS3JOLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVWtGLGFBQVYsQ0FBd0JMLFFBQTdCO0FBQ0k7QUFDQSxnQkFBSXFELEtBQUssR0FBRzdKLENBQUMsQ0FBQ3lCLE9BQUYsQ0FBVTBILE1BQVYsR0FBbUJuSixDQUFDLENBQUN1RSxPQUFyQixHQUErQnZFLENBQUMsQ0FBQzJFLFVBQTdDO0FBQ0EzRSxZQUFBQSxDQUFDLENBQUNtRixXQUFGLEdBQWdCbUMsSUFBSSxDQUFDc0MsS0FBTCxDQUFXLENBQUNDLEtBQUssR0FBRzdKLENBQUMsQ0FBQ2lGLFFBQVgsS0FBd0JqRixDQUFDLENBQUNnSixTQUFGLENBQVlHLE1BQVosR0FBcUJuSixDQUFDLENBQUNpRixRQUEvQyxDQUFYLENBQWhCO0FBQ0FqRixZQUFBQSxDQUFDLENBQUMwSixTQUFGLEdBQWMsS0FBZDtBQUNBO0FBWlI7O0FBY0E7QUF4QlI7QUEwQkgsR0EzaUJJOztBQTRpQkw7Ozs7O0FBS0F6SSxFQUFBQSxXQWpqQkssdUJBaWpCTzZJLFFBampCUCxFQWlqQmlCO0FBQ2xCQSxJQUFBQSxRQUFRLEdBQUdBLFFBQVEsSUFBSSxJQUFaLEdBQW1CLElBQW5CLEdBQTBCQSxRQUFyQzs7QUFDQSxRQUFJLENBQUMsS0FBS2hHLE9BQVYsRUFBbUI7QUFDZixVQUFJZ0csUUFBSixFQUFjO0FBQ1Z6TixRQUFBQSxFQUFFLENBQUM2RSxLQUFILENBQVMsb0NBQVQ7QUFDSDs7QUFDRCxhQUFPLEtBQVA7QUFDSDs7QUFDRCxXQUFPLElBQVA7QUFDSCxHQTFqQkk7QUEyakJMO0FBQ0FFLEVBQUFBLGNBNWpCSyw0QkE0akJZO0FBQ2IsUUFBSXBCLENBQUMsR0FBRyxJQUFSO0FBQ0EsUUFBSStKLE1BQUo7O0FBQ0EsWUFBUS9KLENBQUMsQ0FBQ2tFLE1BQVY7QUFDSSxXQUFLN0gsRUFBRSxDQUFDc0YsTUFBSCxDQUFVdUUsSUFBVixDQUFlQyxVQUFwQjtBQUFnQztBQUM1QixjQUFJbkcsQ0FBQyxDQUFDZ0ssV0FBTixFQUFtQjtBQUNmLGdCQUFJQyxLQUFLLEdBQUdqSyxDQUFDLENBQUNrSyxhQUFGLEVBQVo7O0FBQ0FILFlBQUFBLE1BQU0sR0FBRy9KLENBQUMsQ0FBQzZFLFFBQUYsR0FBYW9GLEtBQUssQ0FBQzdMLEdBQW5CLEdBQTBCNEIsQ0FBQyxDQUFDZ0osU0FBRixDQUFZRSxLQUFaLElBQXFCbEosQ0FBQyxDQUFDbEIsU0FBRixHQUFjbUwsS0FBSyxDQUFDRSxLQUF6QyxDQUExQixHQUE4RW5LLENBQUMsQ0FBQytFLFVBQUYsSUFBZ0IvRSxDQUFDLENBQUNsQixTQUFGLEdBQWMsQ0FBOUIsQ0FBOUUsR0FBa0hrQixDQUFDLENBQUN5RSxTQUE3SDtBQUNILFdBSEQsTUFHTztBQUNIc0YsWUFBQUEsTUFBTSxHQUFHL0osQ0FBQyxDQUFDNkUsUUFBRixHQUFjN0UsQ0FBQyxDQUFDZ0osU0FBRixDQUFZRSxLQUFaLEdBQW9CbEosQ0FBQyxDQUFDbEIsU0FBcEMsR0FBa0RrQixDQUFDLENBQUMrRSxVQUFGLElBQWdCL0UsQ0FBQyxDQUFDbEIsU0FBRixHQUFjLENBQTlCLENBQWxELEdBQXNGa0IsQ0FBQyxDQUFDeUUsU0FBakc7QUFDSDs7QUFDRDtBQUNIOztBQUNELFdBQUtwSSxFQUFFLENBQUNzRixNQUFILENBQVV1RSxJQUFWLENBQWVNLFFBQXBCO0FBQThCO0FBQzFCLGNBQUl4RyxDQUFDLENBQUNnSyxXQUFOLEVBQW1CO0FBQ2YsZ0JBQUlDLE1BQUssR0FBR2pLLENBQUMsQ0FBQ2tLLGFBQUYsRUFBWjs7QUFDQUgsWUFBQUEsTUFBTSxHQUFHL0osQ0FBQyxDQUFDdUUsT0FBRixHQUFZMEYsTUFBSyxDQUFDN0wsR0FBbEIsR0FBeUI0QixDQUFDLENBQUNnSixTQUFGLENBQVlHLE1BQVosSUFBc0JuSixDQUFDLENBQUNsQixTQUFGLEdBQWNtTCxNQUFLLENBQUNFLEtBQTFDLENBQXpCLEdBQThFbkssQ0FBQyxDQUFDaUYsUUFBRixJQUFjakYsQ0FBQyxDQUFDbEIsU0FBRixHQUFjLENBQTVCLENBQTlFLEdBQWdIa0IsQ0FBQyxDQUFDMkUsVUFBM0g7QUFDSCxXQUhELE1BR087QUFDSG9GLFlBQUFBLE1BQU0sR0FBRy9KLENBQUMsQ0FBQ3VFLE9BQUYsR0FBYXZFLENBQUMsQ0FBQ2dKLFNBQUYsQ0FBWUcsTUFBWixHQUFxQm5KLENBQUMsQ0FBQ2xCLFNBQXBDLEdBQWtEa0IsQ0FBQyxDQUFDaUYsUUFBRixJQUFjakYsQ0FBQyxDQUFDbEIsU0FBRixHQUFjLENBQTVCLENBQWxELEdBQW9Ga0IsQ0FBQyxDQUFDMkUsVUFBL0Y7QUFDSDs7QUFDRDtBQUNIOztBQUNELFdBQUt0SSxFQUFFLENBQUNzRixNQUFILENBQVV1RSxJQUFWLENBQWVVLElBQXBCO0FBQTBCO0FBQ3RCO0FBQ0EsY0FBSTVHLENBQUMsQ0FBQ2QsVUFBTixFQUNJYyxDQUFDLENBQUNkLFVBQUYsR0FBZSxLQUFmOztBQUNKLGtCQUFRYyxDQUFDLENBQUNxRSxVQUFWO0FBQ0ksaUJBQUtoSSxFQUFFLENBQUNzRixNQUFILENBQVVrRixhQUFWLENBQXdCVixVQUE3QjtBQUNJLGtCQUFJaUUsT0FBTyxHQUFHOUMsSUFBSSxDQUFDK0MsSUFBTCxDQUFVckssQ0FBQyxDQUFDbEIsU0FBRixHQUFja0IsQ0FBQyxDQUFDbUYsV0FBMUIsQ0FBZDtBQUNBNEUsY0FBQUEsTUFBTSxHQUFHL0osQ0FBQyxDQUFDdUUsT0FBRixHQUFhdkUsQ0FBQyxDQUFDZ0osU0FBRixDQUFZRyxNQUFaLEdBQXFCaUIsT0FBbEMsR0FBOENwSyxDQUFDLENBQUNpRixRQUFGLElBQWNtRixPQUFPLEdBQUcsQ0FBeEIsQ0FBOUMsR0FBNEVwSyxDQUFDLENBQUMyRSxVQUF2RjtBQUNBOztBQUNKLGlCQUFLdEksRUFBRSxDQUFDc0YsTUFBSCxDQUFVa0YsYUFBVixDQUF3QkwsUUFBN0I7QUFDSSxrQkFBSThELE1BQU0sR0FBR2hELElBQUksQ0FBQytDLElBQUwsQ0FBVXJLLENBQUMsQ0FBQ2xCLFNBQUYsR0FBY2tCLENBQUMsQ0FBQ21GLFdBQTFCLENBQWI7QUFDQTRFLGNBQUFBLE1BQU0sR0FBRy9KLENBQUMsQ0FBQzZFLFFBQUYsR0FBYzdFLENBQUMsQ0FBQ2dKLFNBQUYsQ0FBWUUsS0FBWixHQUFvQm9CLE1BQWxDLEdBQTZDdEssQ0FBQyxDQUFDK0UsVUFBRixJQUFnQnVGLE1BQU0sR0FBRyxDQUF6QixDQUE3QyxHQUE0RXRLLENBQUMsQ0FBQ3lFLFNBQXZGO0FBQ0E7QUFSUjs7QUFVQTtBQUNIO0FBbENMOztBQXFDQSxRQUFJakQsTUFBTSxHQUFHeEIsQ0FBQyxDQUFDeUIsT0FBRixDQUFVQyxZQUFWLENBQXVCckYsRUFBRSxDQUFDc0YsTUFBMUIsQ0FBYjtBQUNBLFFBQUlILE1BQUosRUFDSUEsTUFBTSxDQUFDSSxPQUFQLEdBQWlCLEtBQWpCO0FBRUo1QixJQUFBQSxDQUFDLENBQUN1SyxZQUFGLEdBQWlCUixNQUFqQjtBQUNBL0osSUFBQUEsQ0FBQyxDQUFDd0ssa0JBQUYsR0FBdUJ4SyxDQUFDLENBQUN1SyxZQUFGLElBQWtCdkssQ0FBQyxDQUFDMEosU0FBRixHQUFlMUosQ0FBQyxDQUFDdUUsT0FBRixHQUFZdkUsQ0FBQyxDQUFDMkUsVUFBN0IsR0FBNEMzRSxDQUFDLENBQUM2RSxRQUFGLEdBQWE3RSxDQUFDLENBQUN5RSxTQUE3RSxDQUF2Qjs7QUFFQSxRQUFJekUsQ0FBQyxDQUFDaEIsTUFBTixFQUFjO0FBQ1YsVUFBSXlMLFNBQVMsR0FBSXpLLENBQUMsQ0FBQzBKLFNBQUYsR0FBYzFKLENBQUMsQ0FBQzZDLElBQUYsQ0FBT3NHLE1BQXJCLEdBQThCbkosQ0FBQyxDQUFDNkMsSUFBRixDQUFPcUcsS0FBdEQ7QUFFQWxKLE1BQUFBLENBQUMsQ0FBQzBLLFdBQUYsR0FBZ0IsQ0FBaEI7QUFDQUQsTUFBQUEsU0FBUyxJQUFJekssQ0FBQyxDQUFDMEssV0FBZjtBQUNBMUssTUFBQUEsQ0FBQyxDQUFDcUIsVUFBRixHQUFlaUcsSUFBSSxDQUFDK0MsSUFBTCxDQUFVSSxTQUFTLEdBQUd6SyxDQUFDLENBQUN3SyxrQkFBeEIsSUFBOEMsQ0FBN0Q7QUFDQSxVQUFJRyxPQUFPLEdBQUczSyxDQUFDLENBQUMwSixTQUFGLEdBQWMxSixDQUFDLENBQUNpRixRQUFoQixHQUEyQmpGLENBQUMsQ0FBQytFLFVBQTNDO0FBQ0EvRSxNQUFBQSxDQUFDLENBQUM0SyxXQUFGLEdBQWdCNUssQ0FBQyxDQUFDMEssV0FBRixHQUFnQjFLLENBQUMsQ0FBQ3dLLGtCQUFsQixHQUF1Q0csT0FBdkQ7QUFDQTNLLE1BQUFBLENBQUMsQ0FBQzZLLGtCQUFGLEdBQXVCN0ssQ0FBQyxDQUFDdUssWUFBRixHQUFrQnZLLENBQUMsQ0FBQ3dLLGtCQUFGLElBQXdCeEssQ0FBQyxDQUFDcUIsVUFBRixHQUFlLENBQXZDLENBQWxCLEdBQWdFc0osT0FBTyxJQUFJM0ssQ0FBQyxDQUFDcUIsVUFBRixHQUFlLENBQW5CLENBQTlGO0FBQ0FyQixNQUFBQSxDQUFDLENBQUM4Syx3QkFBRixHQUE2QjlLLENBQUMsQ0FBQ3dLLGtCQUFGLEdBQXVCeEssQ0FBQyxDQUFDcUIsVUFBdEQ7QUFDQXJCLE1BQUFBLENBQUMsQ0FBQzhLLHdCQUFGLElBQThCSCxPQUFPLElBQUkzSyxDQUFDLENBQUNxQixVQUFGLEdBQWUsQ0FBbkIsQ0FBckMsQ0FWVSxDQVdWO0FBQ0g7O0FBRURyQixJQUFBQSxDQUFDLENBQUMrSyxLQUFGLEdBQVUsQ0FBQy9LLENBQUMsQ0FBQ2hCLE1BQUgsSUFBYWdCLENBQUMsQ0FBQ3VLLFlBQUYsSUFBa0J2SyxDQUFDLENBQUMwSixTQUFGLEdBQWMxSixDQUFDLENBQUM2QyxJQUFGLENBQU9zRyxNQUFyQixHQUE4Qm5KLENBQUMsQ0FBQzZDLElBQUYsQ0FBT3FHLEtBQXZELENBQXZCO0FBQ0EsUUFBSThCLFdBQVcsR0FBSSxDQUFDLENBQUNoTCxDQUFDLENBQUMrSyxLQUFILElBQVksQ0FBQy9LLENBQUMsQ0FBQ2QsVUFBaEIsS0FBK0JjLENBQUMsQ0FBQ2IsU0FBbEMsR0FBK0MsQ0FBL0MsR0FBbUQsRUFBckU7QUFFQSxRQUFJOEwsUUFBUSxHQUFHakwsQ0FBQyxDQUFDK0ssS0FBRixHQUFXLENBQUMvSyxDQUFDLENBQUMwSixTQUFGLEdBQWMxSixDQUFDLENBQUM2QyxJQUFGLENBQU9zRyxNQUFyQixHQUE4Qm5KLENBQUMsQ0FBQzZDLElBQUYsQ0FBT3FHLEtBQXRDLElBQStDOEIsV0FBMUQsR0FBMEVoTCxDQUFDLENBQUNoQixNQUFGLEdBQVdnQixDQUFDLENBQUM2SyxrQkFBYixHQUFrQzdLLENBQUMsQ0FBQ3VLLFlBQTdIO0FBQ0EsUUFBSVUsUUFBUSxHQUFHLENBQWYsRUFDSUEsUUFBUSxHQUFHLENBQVg7O0FBRUosUUFBSWpMLENBQUMsQ0FBQzBKLFNBQU4sRUFBaUI7QUFDYjFKLE1BQUFBLENBQUMsQ0FBQ3lCLE9BQUYsQ0FBVTBILE1BQVYsR0FBbUI4QixRQUFuQjtBQUNILEtBRkQsTUFFTztBQUNIakwsTUFBQUEsQ0FBQyxDQUFDeUIsT0FBRixDQUFVeUgsS0FBVixHQUFrQitCLFFBQWxCO0FBQ0gsS0F4RVksQ0F5RWI7O0FBQ0gsR0F0b0JJO0FBdW9CTDtBQUNBbE0sRUFBQUEsWUF4b0JLLHdCQXdvQlFtTSxFQXhvQlIsRUF3b0JZO0FBQ2IsUUFBSSxLQUFLQyxVQUFMLElBQW1CLElBQXZCLEVBQ0ksS0FBS0EsVUFBTCxHQUFrQixLQUFLL0wsV0FBdkI7O0FBQ0osUUFBSSxDQUFDLEtBQUsrQixZQUFOLElBQXVCK0osRUFBRSxJQUFJQSxFQUFFLENBQUM1TixJQUFILElBQVcsY0FBeEMsSUFBMkQsS0FBSzZOLFVBQUwsR0FBa0IsQ0FBakYsRUFBb0Y7QUFDaEYsV0FBS0EsVUFBTDtBQUNBO0FBQ0gsS0FIRCxNQUlJLEtBQUtBLFVBQUwsR0FBa0IsS0FBSy9MLFdBQXZCOztBQUVKLFFBQUksS0FBS2dNLGFBQVQsRUFDSSxPQVZTLENBWWI7O0FBQ0EsUUFBSSxLQUFLcE0sTUFBVCxFQUFpQjtBQUNiLFVBQUlxTSxTQUFTLEdBQUcsS0FBSzVKLE9BQUwsQ0FBYTZKLFdBQWIsRUFBaEI7QUFDQUQsTUFBQUEsU0FBUyxHQUFHLEtBQUszQixTQUFMLEdBQWlCMkIsU0FBUyxDQUFDRSxDQUEzQixHQUErQkYsU0FBUyxDQUFDRyxDQUFyRDtBQUVBLFVBQUlDLE1BQU0sR0FBRyxLQUFLakIsa0JBQUwsSUFBMkIsS0FBS2QsU0FBTCxHQUFpQixLQUFLekUsUUFBdEIsR0FBaUMsS0FBS0YsVUFBakUsQ0FBYjtBQUNBLFVBQUk4QyxHQUFHLEdBQUcsS0FBSzZCLFNBQUwsR0FBaUJyTixFQUFFLENBQUNxUCxFQUFILENBQU0sQ0FBTixFQUFTRCxNQUFULENBQWpCLEdBQW9DcFAsRUFBRSxDQUFDcVAsRUFBSCxDQUFNRCxNQUFOLEVBQWMsQ0FBZCxDQUE5Qzs7QUFFQSxjQUFRLEtBQUtuRixjQUFiO0FBQ0ksYUFBSyxDQUFMO0FBQU87QUFDSCxjQUFJK0UsU0FBUyxHQUFHLENBQUMsS0FBS1gsV0FBdEIsRUFBbUM7QUFDL0IsaUJBQUtqSixPQUFMLENBQWErSixDQUFiLEdBQWlCLENBQUMsS0FBS1osV0FBdkI7O0FBQ0EsZ0JBQUksS0FBSzdHLFdBQUwsQ0FBaUI0SCxlQUFqQixFQUFKLEVBQXdDO0FBQ3BDLG1CQUFLNUgsV0FBTCxDQUFpQjZELHdCQUFqQixHQUE0QyxLQUFLN0QsV0FBTCxDQUFpQjZELHdCQUFqQixDQUEwQ2xILEdBQTFDLENBQThDbUgsR0FBOUMsQ0FBNUM7QUFDSCxhQUo4QixDQUsvQjtBQUNBO0FBQ0E7O0FBQ0gsV0FSRCxNQVFPLElBQUl3RCxTQUFTLEdBQUcsQ0FBQyxLQUFLVCxXQUF0QixFQUFtQztBQUN0QyxpQkFBS25KLE9BQUwsQ0FBYStKLENBQWIsR0FBaUIsQ0FBQyxLQUFLZCxXQUF2Qjs7QUFDQSxnQkFBSSxLQUFLM0csV0FBTCxDQUFpQjRILGVBQWpCLEVBQUosRUFBd0M7QUFDcEMsbUJBQUs1SCxXQUFMLENBQWlCNkQsd0JBQWpCLEdBQTRDLEtBQUs3RCxXQUFMLENBQWlCNkQsd0JBQWpCLENBQTBDQyxHQUExQyxDQUE4Q0EsR0FBOUMsQ0FBNUM7QUFDSCxhQUpxQyxDQUt0QztBQUNBO0FBQ0E7O0FBQ0g7O0FBQ0Q7O0FBQ0osYUFBSyxDQUFMO0FBQU87QUFDSCxjQUFJd0QsU0FBUyxHQUFHLEtBQUtYLFdBQXJCLEVBQWtDO0FBQzlCLGlCQUFLakosT0FBTCxDQUFhK0osQ0FBYixHQUFpQixLQUFLWixXQUF0Qjs7QUFDQSxnQkFBSSxLQUFLN0csV0FBTCxDQUFpQjRILGVBQWpCLEVBQUosRUFBd0M7QUFDcEMsbUJBQUs1SCxXQUFMLENBQWlCNkQsd0JBQWpCLEdBQTRDLEtBQUs3RCxXQUFMLENBQWlCNkQsd0JBQWpCLENBQTBDQyxHQUExQyxDQUE4Q0EsR0FBOUMsQ0FBNUM7QUFDSDtBQUNKLFdBTEQsTUFLTyxJQUFJd0QsU0FBUyxHQUFHLEtBQUtULFdBQXJCLEVBQWtDO0FBQ3JDLGlCQUFLbkosT0FBTCxDQUFhK0osQ0FBYixHQUFpQixLQUFLZCxXQUF0Qjs7QUFDQSxnQkFBSSxLQUFLM0csV0FBTCxDQUFpQjRILGVBQWpCLEVBQUosRUFBd0M7QUFDcEMsbUJBQUs1SCxXQUFMLENBQWlCNkQsd0JBQWpCLEdBQTRDLEtBQUs3RCxXQUFMLENBQWlCNkQsd0JBQWpCLENBQTBDbEgsR0FBMUMsQ0FBOENtSCxHQUE5QyxDQUE1QztBQUNIO0FBQ0o7O0FBQ0Q7O0FBQ0osYUFBSyxDQUFMO0FBQU87QUFDSCxjQUFJd0QsU0FBUyxHQUFHLEtBQUtYLFdBQXJCLEVBQWtDO0FBQzlCLGlCQUFLakosT0FBTCxDQUFhOEosQ0FBYixHQUFpQixLQUFLWCxXQUF0Qjs7QUFDQSxnQkFBSSxLQUFLN0csV0FBTCxDQUFpQjRILGVBQWpCLEVBQUosRUFBd0M7QUFDcEMsbUJBQUs1SCxXQUFMLENBQWlCNkQsd0JBQWpCLEdBQTRDLEtBQUs3RCxXQUFMLENBQWlCNkQsd0JBQWpCLENBQTBDQyxHQUExQyxDQUE4Q0EsR0FBOUMsQ0FBNUM7QUFDSDtBQUNKLFdBTEQsTUFLTyxJQUFJd0QsU0FBUyxHQUFHLEtBQUtULFdBQXJCLEVBQWtDO0FBQ3JDLGlCQUFLbkosT0FBTCxDQUFhOEosQ0FBYixHQUFpQixLQUFLYixXQUF0Qjs7QUFDQSxnQkFBSSxLQUFLM0csV0FBTCxDQUFpQjRILGVBQWpCLEVBQUosRUFBd0M7QUFDcEMsbUJBQUs1SCxXQUFMLENBQWlCNkQsd0JBQWpCLEdBQTRDLEtBQUs3RCxXQUFMLENBQWlCNkQsd0JBQWpCLENBQTBDbEgsR0FBMUMsQ0FBOENtSCxHQUE5QyxDQUE1QztBQUNIO0FBQ0o7O0FBQ0Q7O0FBQ0osYUFBSyxDQUFMO0FBQU87QUFDSCxjQUFJd0QsU0FBUyxHQUFHLENBQUMsS0FBS1gsV0FBdEIsRUFBbUM7QUFDL0IsaUJBQUtqSixPQUFMLENBQWE4SixDQUFiLEdBQWlCLENBQUMsS0FBS1gsV0FBdkI7O0FBQ0EsZ0JBQUksS0FBSzdHLFdBQUwsQ0FBaUI0SCxlQUFqQixFQUFKLEVBQXdDO0FBQ3BDLG1CQUFLNUgsV0FBTCxDQUFpQjZELHdCQUFqQixHQUE0QyxLQUFLN0QsV0FBTCxDQUFpQjZELHdCQUFqQixDQUEwQ2xILEdBQTFDLENBQThDbUgsR0FBOUMsQ0FBNUM7QUFDSDtBQUNKLFdBTEQsTUFLTyxJQUFJd0QsU0FBUyxHQUFHLENBQUMsS0FBS1QsV0FBdEIsRUFBbUM7QUFDdEMsaUJBQUtuSixPQUFMLENBQWE4SixDQUFiLEdBQWlCLENBQUMsS0FBS2IsV0FBdkI7O0FBQ0EsZ0JBQUksS0FBSzNHLFdBQUwsQ0FBaUI0SCxlQUFqQixFQUFKLEVBQXdDO0FBQ3BDLG1CQUFLNUgsV0FBTCxDQUFpQjZELHdCQUFqQixHQUE0QyxLQUFLN0QsV0FBTCxDQUFpQjZELHdCQUFqQixDQUEwQ0MsR0FBMUMsQ0FBOENBLEdBQTlDLENBQTVDO0FBQ0g7QUFDSjs7QUFDRDtBQTFEUjtBQTRESDs7QUFFRCxTQUFLK0QsWUFBTDs7QUFFQSxRQUFJQyxJQUFKLEVBQVVDLE1BQVYsRUFBa0JDLE9BQWxCLEVBQTJCQyxLQUEzQjs7QUFDQSxRQUFJLEtBQUt0QyxTQUFULEVBQW9CO0FBQ2hCbUMsTUFBQUEsSUFBSSxHQUFHLEtBQUtJLE9BQVo7QUFDQUYsTUFBQUEsT0FBTyxHQUFHLEtBQUtHLFVBQWY7QUFDSCxLQUhELE1BR087QUFDSEosTUFBQUEsTUFBTSxHQUFHLEtBQUtLLFNBQWQ7QUFDQUgsTUFBQUEsS0FBSyxHQUFHLEtBQUtJLFFBQWI7QUFDSDs7QUFFRCxRQUFJLEtBQUt4TixRQUFULEVBQW1CO0FBQ2YsV0FBS2lILFdBQUwsR0FBbUIsRUFBbkI7QUFDQSxVQUFJd0csT0FBSjtBQUVBLFVBQUlDLEtBQUssR0FBRyxDQUFaO0FBQ0EsVUFBSUMsS0FBSyxHQUFHLEtBQUt6TixTQUFMLEdBQWlCLENBQTdCOztBQUVBLFVBQUksS0FBS2tMLFdBQVQsRUFBc0I7QUFDbEIsWUFBSXdDLFFBQVEsR0FBRyxLQUFmLENBRGtCLENBRWxCOztBQUNBLGVBQU9GLEtBQUssSUFBSUMsS0FBVCxJQUFrQixDQUFDQyxRQUExQixFQUFvQ0YsS0FBSyxFQUF6QyxFQUE2QztBQUN6Q0QsVUFBQUEsT0FBTyxHQUFHLEtBQUtJLFlBQUwsQ0FBa0JILEtBQWxCLENBQVY7O0FBQ0Esa0JBQVEsS0FBS3BJLE1BQWI7QUFDSSxpQkFBSzdILEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXVFLElBQVYsQ0FBZUMsVUFBcEI7QUFDSSxrQkFBSWtHLE9BQU8sQ0FBQ0ssS0FBUixJQUFpQlYsS0FBakIsSUFBMEJLLE9BQU8sQ0FBQ00sSUFBUixJQUFnQmIsTUFBOUMsRUFBc0Q7QUFDbEQscUJBQUtqRyxXQUFMLENBQWlCaEYsSUFBakIsQ0FBc0J3TCxPQUF0QjtBQUNILGVBRkQsTUFFTyxJQUFJQyxLQUFLLElBQUksQ0FBVCxJQUFjLEtBQUt6RyxXQUFMLENBQWlCK0csTUFBakIsR0FBMEIsQ0FBNUMsRUFBK0M7QUFDbERKLGdCQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNIOztBQUNEOztBQUNKLGlCQUFLblEsRUFBRSxDQUFDc0YsTUFBSCxDQUFVdUUsSUFBVixDQUFlTSxRQUFwQjtBQUNJLGtCQUFJNkYsT0FBTyxDQUFDUSxNQUFSLElBQWtCaEIsSUFBbEIsSUFBMEJRLE9BQU8sQ0FBQ1MsR0FBUixJQUFlZixPQUE3QyxFQUFzRDtBQUNsRCxxQkFBS2xHLFdBQUwsQ0FBaUJoRixJQUFqQixDQUFzQndMLE9BQXRCO0FBQ0gsZUFGRCxNQUVPLElBQUlDLEtBQUssSUFBSSxDQUFULElBQWMsS0FBS3pHLFdBQUwsQ0FBaUIrRyxNQUFqQixHQUEwQixDQUE1QyxFQUErQztBQUNsREosZ0JBQUFBLFFBQVEsR0FBRyxJQUFYO0FBQ0g7O0FBQ0Q7O0FBQ0osaUJBQUtuUSxFQUFFLENBQUNzRixNQUFILENBQVV1RSxJQUFWLENBQWVVLElBQXBCO0FBQ0ksc0JBQVEsS0FBS3ZDLFVBQWI7QUFDSSxxQkFBS2hJLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVWtGLGFBQVYsQ0FBd0JWLFVBQTdCO0FBQ0ksc0JBQUlrRyxPQUFPLENBQUNRLE1BQVIsSUFBa0JoQixJQUFsQixJQUEwQlEsT0FBTyxDQUFDUyxHQUFSLElBQWVmLE9BQTdDLEVBQXNEO0FBQ2xELHlCQUFLbEcsV0FBTCxDQUFpQmhGLElBQWpCLENBQXNCd0wsT0FBdEI7QUFDSCxtQkFGRCxNQUVPLElBQUlDLEtBQUssSUFBSSxDQUFULElBQWMsS0FBS3pHLFdBQUwsQ0FBaUIrRyxNQUFqQixHQUEwQixDQUE1QyxFQUErQztBQUNsREosb0JBQUFBLFFBQVEsR0FBRyxJQUFYO0FBQ0g7O0FBQ0Q7O0FBQ0oscUJBQUtuUSxFQUFFLENBQUNzRixNQUFILENBQVVrRixhQUFWLENBQXdCTCxRQUE3QjtBQUNJLHNCQUFJNkYsT0FBTyxDQUFDSyxLQUFSLElBQWlCVixLQUFqQixJQUEwQkssT0FBTyxDQUFDTSxJQUFSLElBQWdCYixNQUE5QyxFQUFzRDtBQUNsRCx5QkFBS2pHLFdBQUwsQ0FBaUJoRixJQUFqQixDQUFzQndMLE9BQXRCO0FBQ0gsbUJBRkQsTUFFTyxJQUFJQyxLQUFLLElBQUksQ0FBVCxJQUFjLEtBQUt6RyxXQUFMLENBQWlCK0csTUFBakIsR0FBMEIsQ0FBNUMsRUFBK0M7QUFDbERKLG9CQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNIOztBQUNEO0FBZFI7O0FBZ0JBO0FBaENSO0FBa0NIO0FBQ0osT0F4Q0QsTUF3Q087QUFDSCxZQUFJTyxFQUFFLEdBQUcsS0FBSy9ELFNBQUwsQ0FBZUUsS0FBZixHQUF1QixLQUFLbkUsVUFBckM7QUFDQSxZQUFJaUksRUFBRSxHQUFHLEtBQUtoRSxTQUFMLENBQWVHLE1BQWYsR0FBd0IsS0FBS2xFLFFBQXRDOztBQUNBLGdCQUFRLEtBQUtxQixjQUFiO0FBQ0ksZUFBSyxDQUFMO0FBQU87QUFDSGdHLFlBQUFBLEtBQUssR0FBRyxDQUFDTixLQUFLLEdBQUcsS0FBS25ILFFBQWQsSUFBMEJrSSxFQUFsQztBQUNBUixZQUFBQSxLQUFLLEdBQUcsQ0FBQ1QsTUFBTSxHQUFHLEtBQUtySCxTQUFmLElBQTRCc0ksRUFBcEM7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFBTztBQUNIVCxZQUFBQSxLQUFLLEdBQUcsQ0FBQyxDQUFDUixNQUFELEdBQVUsS0FBS3JILFNBQWhCLElBQTZCc0ksRUFBckM7QUFDQVIsWUFBQUEsS0FBSyxHQUFHLENBQUMsQ0FBQ1AsS0FBRCxHQUFTLEtBQUtuSCxRQUFmLElBQTJCa0ksRUFBbkM7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFBTztBQUNIVCxZQUFBQSxLQUFLLEdBQUcsQ0FBQyxDQUFDVCxJQUFELEdBQVEsS0FBS3RILE9BQWQsSUFBeUJ5SSxFQUFqQztBQUNBVCxZQUFBQSxLQUFLLEdBQUcsQ0FBQyxDQUFDUixPQUFELEdBQVcsS0FBS3BILFVBQWpCLElBQStCcUksRUFBdkM7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFBTztBQUNIVixZQUFBQSxLQUFLLEdBQUcsQ0FBQ1AsT0FBTyxHQUFHLEtBQUtwSCxVQUFoQixJQUE4QnFJLEVBQXRDO0FBQ0FULFlBQUFBLEtBQUssR0FBRyxDQUFDVixJQUFJLEdBQUcsS0FBS3RILE9BQWIsSUFBd0J5SSxFQUFoQztBQUNBO0FBaEJSOztBQWtCQVYsUUFBQUEsS0FBSyxHQUFHaEYsSUFBSSxDQUFDc0MsS0FBTCxDQUFXMEMsS0FBWCxJQUFvQixLQUFLbkgsV0FBakM7QUFDQW9ILFFBQUFBLEtBQUssR0FBR2pGLElBQUksQ0FBQytDLElBQUwsQ0FBVWtDLEtBQVYsSUFBbUIsS0FBS3BILFdBQWhDO0FBQ0FvSCxRQUFBQSxLQUFLO0FBQ0wsWUFBSUQsS0FBSyxHQUFHLENBQVosRUFDSUEsS0FBSyxHQUFHLENBQVI7QUFDSixZQUFJQyxLQUFLLElBQUksS0FBS3pOLFNBQWxCLEVBQ0l5TixLQUFLLEdBQUcsS0FBS3pOLFNBQUwsR0FBaUIsQ0FBekIsQ0EzQkQsQ0E0Qkg7O0FBQ0EsZUFBT3dOLEtBQUssSUFBSUMsS0FBaEIsRUFBdUJELEtBQUssRUFBNUIsRUFBZ0M7QUFDNUIsZUFBS3pHLFdBQUwsQ0FBaUJoRixJQUFqQixDQUFzQixLQUFLNEwsWUFBTCxDQUFrQkgsS0FBbEIsQ0FBdEI7QUFDSDtBQUNKOztBQUNELFVBQUksS0FBS3pHLFdBQUwsQ0FBaUIrRyxNQUFqQixJQUEyQixDQUEzQixJQUFnQyxDQUFDLEtBQUs5TixTQUExQyxFQUFxRDtBQUFFO0FBQ25ELGFBQUs4RyxnQkFBTCxHQUF3QixFQUF4Qjs7QUFDQSxhQUFLL0QsaUJBQUw7O0FBQ0E7QUFDSDs7QUFDRCxXQUFLQyxXQUFMLEdBQW1CLEtBQUsrRCxXQUFMLENBQWlCLENBQWpCLEVBQW9Cb0gsRUFBdkM7QUFDQSxXQUFLN0ssY0FBTCxHQUFzQixLQUFLeUQsV0FBTCxDQUFpQitHLE1BQXZDO0FBQ0EsVUFBSTdLLEdBQUcsR0FBRyxLQUFLNkQsZ0JBQUwsQ0FBc0JnSCxNQUFoQyxDQXZGZSxDQXdGZjtBQUNBOztBQUNBLFVBQUksS0FBS3pMLFlBQUwsSUFDQSxLQUFLaUIsY0FBTCxJQUF1QkwsR0FEdkIsSUFFQSxLQUFLRCxXQUFMLElBQW9CLEtBQUs4RCxnQkFBTCxDQUFzQixDQUF0QixDQUZwQixJQUdBLEtBQUtDLFdBQUwsQ0FBaUIsS0FBS3pELGNBQUwsR0FBc0IsQ0FBdkMsRUFBMEM2SyxFQUExQyxJQUFnRCxLQUFLckgsZ0JBQUwsQ0FBc0I3RCxHQUFHLEdBQUcsQ0FBNUIsQ0FIcEQsRUFJRTtBQUNFLGFBQUs2RCxnQkFBTCxHQUF3QixFQUF4Qjs7QUFDQSxZQUFJLEtBQUtyRyxxQkFBTCxHQUE2QixDQUFqQyxFQUFvQztBQUFFO0FBQ2xDLGNBQUksS0FBS1QsU0FBTCxHQUFpQixDQUFyQixFQUF3QjtBQUNwQixnQkFBSSxDQUFDLEtBQUtxRCxXQUFWLEVBQXVCO0FBQ25CLG1CQUFLK0ssZ0JBQUwsR0FBd0IsSUFBeEI7QUFDSCxhQUZELE1BRU87QUFDSCxtQkFBS2hMLGNBQUwsR0FBc0IsQ0FBdEI7QUFDSDs7QUFDRCxpQkFBS0MsV0FBTCxHQUFtQixLQUFuQjtBQUNILFdBUEQsTUFPTztBQUNILGlCQUFLTixpQkFBTDs7QUFDQSxpQkFBS0ssY0FBTCxHQUFzQixDQUF0QjtBQUNBLGlCQUFLQyxXQUFMLEdBQW1CLElBQW5CO0FBQ0gsV0FaK0IsQ0FhaEM7O0FBQ0gsU0FkRCxNQWNPO0FBQUU7QUFDTDtBQUNBLGVBQUssSUFBSWdMLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBSy9LLGNBQXpCLEVBQXlDK0ssQ0FBQyxFQUExQyxFQUE4QztBQUMxQyxpQkFBS0MsbUJBQUwsQ0FBeUIsS0FBS3ZILFdBQUwsQ0FBaUJzSCxDQUFqQixDQUF6QjtBQUNIOztBQUNELGVBQUt0TCxpQkFBTDs7QUFDQSxlQUFLVixZQUFMLEdBQW9CLEtBQXBCO0FBQ0g7QUFDSjs7QUFDRCxXQUFLa00sZ0JBQUw7QUFDSDtBQUNKLEdBOTFCSTtBQSsxQkw7QUFDQXpCLEVBQUFBLFlBaDJCSywwQkFnMkJVO0FBQ1gsUUFBSVAsU0FBUyxHQUFHLEtBQUs1SixPQUFMLENBQWE2SixXQUFiLEVBQWhCOztBQUNBLFlBQVEsS0FBS2hGLGNBQWI7QUFDSSxXQUFLLENBQUw7QUFBTztBQUNILGFBQUtnSCxXQUFMLEdBQW1CakMsU0FBUyxDQUFDRyxDQUFWLEdBQWMsQ0FBZCxHQUFrQkgsU0FBUyxDQUFDRyxDQUE1QixHQUFnQyxDQUFuRDtBQUNBLGFBQUtZLFFBQUwsR0FBZ0IsQ0FBQ2YsU0FBUyxDQUFDRyxDQUFWLEdBQWMsQ0FBZCxHQUFrQixDQUFDSCxTQUFTLENBQUNHLENBQTdCLEdBQWlDLENBQWxDLElBQXVDLEtBQUs4QixXQUE1RDtBQUNBLGFBQUtuQixTQUFMLEdBQWlCLEtBQUtDLFFBQUwsR0FBZ0IsS0FBS3ZKLElBQUwsQ0FBVXFHLEtBQTNDO0FBQ0EsYUFBS3FFLFlBQUwsR0FBb0IsS0FBS3BCLFNBQUwsR0FBaUIsS0FBSzFLLE9BQUwsQ0FBYXlILEtBQTlCLEdBQXNDNUIsSUFBSSxDQUFDYSxHQUFMLENBQVMsS0FBS2dFLFNBQUwsR0FBaUIsS0FBSzFLLE9BQUwsQ0FBYXlILEtBQXZDLENBQXRDLEdBQXNGLENBQTFHO0FBQ0EsYUFBS2lELFNBQUwsSUFBa0IsS0FBS29CLFlBQXZCLENBTEosQ0FNSTs7QUFDQTs7QUFDSixXQUFLLENBQUw7QUFBTztBQUNILGFBQUtBLFlBQUwsR0FBb0JsQyxTQUFTLENBQUNHLENBQVYsR0FBYyxDQUFkLEdBQWtCLENBQUNILFNBQVMsQ0FBQ0csQ0FBN0IsR0FBaUMsQ0FBckQ7QUFDQSxhQUFLVyxTQUFMLEdBQWlCLENBQUNkLFNBQVMsQ0FBQ0csQ0FBVixHQUFjLENBQWQsR0FBa0IsQ0FBQ0gsU0FBUyxDQUFDRyxDQUE3QixHQUFpQyxDQUFsQyxJQUF1QyxLQUFLK0IsWUFBN0Q7QUFDQSxhQUFLbkIsUUFBTCxHQUFnQixLQUFLRCxTQUFMLEdBQWlCLEtBQUt0SixJQUFMLENBQVVxRyxLQUEzQztBQUNBLGFBQUtvRSxXQUFMLEdBQW1CLEtBQUtsQixRQUFMLEdBQWdCLENBQUMsS0FBSzNLLE9BQUwsQ0FBYXlILEtBQTlCLEdBQXNDNUIsSUFBSSxDQUFDYSxHQUFMLENBQVMsS0FBS2lFLFFBQUwsR0FBZ0IsS0FBSzNLLE9BQUwsQ0FBYXlILEtBQXRDLENBQXRDLEdBQXFGLENBQXhHO0FBQ0EsYUFBS2tELFFBQUwsSUFBaUIsS0FBS2tCLFdBQXRCLENBTEosQ0FNSTs7QUFDQTs7QUFDSixXQUFLLENBQUw7QUFBTztBQUNILGFBQUtFLFVBQUwsR0FBa0JuQyxTQUFTLENBQUNFLENBQVYsR0FBYyxDQUFkLEdBQWtCakUsSUFBSSxDQUFDYSxHQUFMLENBQVNrRCxTQUFTLENBQUNFLENBQW5CLENBQWxCLEdBQTBDLENBQTVEO0FBQ0EsYUFBS1UsT0FBTCxHQUFlLENBQUNaLFNBQVMsQ0FBQ0UsQ0FBVixHQUFjLENBQWQsR0FBa0IsQ0FBQ0YsU0FBUyxDQUFDRSxDQUE3QixHQUFpQyxDQUFsQyxJQUF1QyxLQUFLaUMsVUFBM0Q7QUFDQSxhQUFLdEIsVUFBTCxHQUFrQixLQUFLRCxPQUFMLEdBQWUsS0FBS3BKLElBQUwsQ0FBVXNHLE1BQTNDO0FBQ0EsYUFBS3NFLGFBQUwsR0FBcUIsS0FBS3ZCLFVBQUwsR0FBa0IsQ0FBQyxLQUFLekssT0FBTCxDQUFhMEgsTUFBaEMsR0FBeUM3QixJQUFJLENBQUNhLEdBQUwsQ0FBUyxLQUFLK0QsVUFBTCxHQUFrQixLQUFLekssT0FBTCxDQUFhMEgsTUFBeEMsQ0FBekMsR0FBMkYsQ0FBaEg7QUFDQSxhQUFLK0MsVUFBTCxJQUFtQixLQUFLdUIsYUFBeEIsQ0FMSixDQU1JOztBQUNBOztBQUNKLFdBQUssQ0FBTDtBQUFPO0FBQ0gsYUFBS0EsYUFBTCxHQUFxQnBDLFNBQVMsQ0FBQ0UsQ0FBVixHQUFjLENBQWQsR0FBa0JqRSxJQUFJLENBQUNhLEdBQUwsQ0FBU2tELFNBQVMsQ0FBQ0UsQ0FBbkIsQ0FBbEIsR0FBMEMsQ0FBL0Q7QUFDQSxhQUFLVyxVQUFMLEdBQWtCLENBQUNiLFNBQVMsQ0FBQ0UsQ0FBVixHQUFjLENBQWQsR0FBa0IsQ0FBQ0YsU0FBUyxDQUFDRSxDQUE3QixHQUFpQyxDQUFsQyxJQUF1QyxLQUFLa0MsYUFBOUQ7QUFDQSxhQUFLeEIsT0FBTCxHQUFlLEtBQUtDLFVBQUwsR0FBa0IsS0FBS3JKLElBQUwsQ0FBVXNHLE1BQTNDO0FBQ0EsYUFBS3FFLFVBQUwsR0FBa0IsS0FBS3ZCLE9BQUwsR0FBZSxLQUFLeEssT0FBTCxDQUFhMEgsTUFBNUIsR0FBcUM3QixJQUFJLENBQUNhLEdBQUwsQ0FBUyxLQUFLOEQsT0FBTCxHQUFlLEtBQUt4SyxPQUFMLENBQWEwSCxNQUFyQyxDQUFyQyxHQUFvRixDQUF0RztBQUNBLGFBQUs4QyxPQUFMLElBQWdCLEtBQUt1QixVQUFyQixDQUxKLENBTUk7O0FBQ0E7QUFoQ1I7QUFrQ0gsR0FwNEJJO0FBcTRCTDtBQUNBZixFQUFBQSxZQXQ0Qkssd0JBczRCUVEsRUF0NEJSLEVBczRCWTtBQUNiLFFBQUkvRCxLQUFKLEVBQVdDLE1BQVgsRUFBbUIyRCxHQUFuQixFQUF3QkQsTUFBeEIsRUFBZ0NGLElBQWhDLEVBQXNDRCxLQUF0QyxFQUE2Q2dCLEtBQTdDLEVBQW9EQyxLQUFwRDs7QUFDQSxZQUFRLEtBQUt6SixNQUFiO0FBQ0ksV0FBSzdILEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXVFLElBQVYsQ0FBZUMsVUFBcEI7QUFDSSxnQkFBUSxLQUFLYixjQUFiO0FBQ0ksZUFBS2pKLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXlFLG1CQUFWLENBQThCQyxhQUFuQztBQUFrRDtBQUM5QyxrQkFBSSxLQUFLMkQsV0FBVCxFQUFzQjtBQUNsQixvQkFBSUMsS0FBSyxHQUFHLEtBQUtDLGFBQUwsQ0FBbUIrQyxFQUFuQixDQUFaOztBQUNBTixnQkFBQUEsSUFBSSxHQUFHLEtBQUs5SCxRQUFMLEdBQWlCLENBQUMsS0FBS21FLFNBQUwsQ0FBZUUsS0FBZixHQUF1QixLQUFLbkUsVUFBN0IsS0FBNENrSSxFQUFFLEdBQUdoRCxLQUFLLENBQUNFLEtBQXZELENBQWpCLElBQW1GRixLQUFLLENBQUM3TCxHQUFOLEdBQWEsS0FBSzJHLFVBQUwsR0FBa0JrRixLQUFLLENBQUNFLEtBQXhILENBQVA7QUFDQSxvQkFBSXlELEVBQUUsR0FBRyxLQUFLNUQsV0FBTCxDQUFpQmlELEVBQWpCLENBQVQ7QUFDQS9ELGdCQUFBQSxLQUFLLEdBQUkwRSxFQUFFLEdBQUcsQ0FBTCxHQUFTQSxFQUFULEdBQWMsS0FBSzVFLFNBQUwsQ0FBZUUsS0FBdEM7QUFDSCxlQUxELE1BS087QUFDSHlELGdCQUFBQSxJQUFJLEdBQUcsS0FBSzlILFFBQUwsR0FBaUIsQ0FBQyxLQUFLbUUsU0FBTCxDQUFlRSxLQUFmLEdBQXVCLEtBQUtuRSxVQUE3QixJQUEyQ2tJLEVBQW5FO0FBQ0EvRCxnQkFBQUEsS0FBSyxHQUFHLEtBQUtGLFNBQUwsQ0FBZUUsS0FBdkI7QUFDSDs7QUFDRHdELGNBQUFBLEtBQUssR0FBR0MsSUFBSSxHQUFHekQsS0FBZjs7QUFDQSxrQkFBSSxLQUFLaEssVUFBVCxFQUFxQjtBQUNqQixvQkFBSTJPLE1BQU0sR0FBSSxLQUFLcE0sT0FBTCxDQUFheUgsS0FBYixHQUFxQixDQUF0QixHQUE0QixLQUFLc0Isa0JBQUwsR0FBMEIsQ0FBbkU7QUFDQW1DLGdCQUFBQSxJQUFJLElBQUlrQixNQUFSO0FBQ0FuQixnQkFBQUEsS0FBSyxJQUFJbUIsTUFBVDtBQUNIOztBQUNELHFCQUFPO0FBQ0haLGdCQUFBQSxFQUFFLEVBQUVBLEVBREQ7QUFFSE4sZ0JBQUFBLElBQUksRUFBRUEsSUFGSDtBQUdIRCxnQkFBQUEsS0FBSyxFQUFFQSxLQUhKO0FBSUhsQixnQkFBQUEsQ0FBQyxFQUFFbUIsSUFBSSxHQUFJLEtBQUtuSyxRQUFMLENBQWNzTCxPQUFkLEdBQXdCNUUsS0FKaEM7QUFLSHFDLGdCQUFBQSxDQUFDLEVBQUUsS0FBSy9JLFFBQUwsQ0FBYytJO0FBTGQsZUFBUDtBQU9IOztBQUNELGVBQUtsUCxFQUFFLENBQUNzRixNQUFILENBQVV5RSxtQkFBVixDQUE4QkcsYUFBbkM7QUFBa0Q7QUFDOUMsa0JBQUksS0FBS3lELFdBQVQsRUFBc0I7QUFDbEIsb0JBQUlDLE9BQUssR0FBRyxLQUFLQyxhQUFMLENBQW1CK0MsRUFBbkIsQ0FBWjs7QUFDQVAsZ0JBQUFBLEtBQUssR0FBRyxDQUFDLEtBQUtqSSxTQUFOLEdBQW1CLENBQUMsS0FBS3VFLFNBQUwsQ0FBZUUsS0FBZixHQUF1QixLQUFLbkUsVUFBN0IsS0FBNENrSSxFQUFFLEdBQUdoRCxPQUFLLENBQUNFLEtBQXZELENBQW5CLElBQXFGRixPQUFLLENBQUM3TCxHQUFOLEdBQWEsS0FBSzJHLFVBQUwsR0FBa0JrRixPQUFLLENBQUNFLEtBQTFILENBQVI7QUFDQSxvQkFBSXlELEdBQUUsR0FBRyxLQUFLNUQsV0FBTCxDQUFpQmlELEVBQWpCLENBQVQ7QUFDQS9ELGdCQUFBQSxLQUFLLEdBQUkwRSxHQUFFLEdBQUcsQ0FBTCxHQUFTQSxHQUFULEdBQWMsS0FBSzVFLFNBQUwsQ0FBZUUsS0FBdEM7QUFDSCxlQUxELE1BS087QUFDSHdELGdCQUFBQSxLQUFLLEdBQUcsQ0FBQyxLQUFLakksU0FBTixHQUFtQixDQUFDLEtBQUt1RSxTQUFMLENBQWVFLEtBQWYsR0FBdUIsS0FBS25FLFVBQTdCLElBQTJDa0ksRUFBdEU7QUFDQS9ELGdCQUFBQSxLQUFLLEdBQUcsS0FBS0YsU0FBTCxDQUFlRSxLQUF2QjtBQUNIOztBQUNEeUQsY0FBQUEsSUFBSSxHQUFHRCxLQUFLLEdBQUd4RCxLQUFmOztBQUNBLGtCQUFJLEtBQUtoSyxVQUFULEVBQXFCO0FBQ2pCLG9CQUFJMk8sT0FBTSxHQUFJLEtBQUtwTSxPQUFMLENBQWF5SCxLQUFiLEdBQXFCLENBQXRCLEdBQTRCLEtBQUtzQixrQkFBTCxHQUEwQixDQUFuRTs7QUFDQW1DLGdCQUFBQSxJQUFJLElBQUlrQixPQUFSO0FBQ0FuQixnQkFBQUEsS0FBSyxJQUFJbUIsT0FBVDtBQUNIOztBQUNELHFCQUFPO0FBQ0haLGdCQUFBQSxFQUFFLEVBQUVBLEVBREQ7QUFFSFAsZ0JBQUFBLEtBQUssRUFBRUEsS0FGSjtBQUdIQyxnQkFBQUEsSUFBSSxFQUFFQSxJQUhIO0FBSUhuQixnQkFBQUEsQ0FBQyxFQUFFbUIsSUFBSSxHQUFJLEtBQUtuSyxRQUFMLENBQWNzTCxPQUFkLEdBQXdCNUUsS0FKaEM7QUFLSHFDLGdCQUFBQSxDQUFDLEVBQUUsS0FBSy9JLFFBQUwsQ0FBYytJO0FBTGQsZUFBUDtBQU9IO0FBaERMOztBQWtEQTs7QUFDSixXQUFLbFAsRUFBRSxDQUFDc0YsTUFBSCxDQUFVdUUsSUFBVixDQUFlTSxRQUFwQjtBQUE4QjtBQUMxQixrQkFBUSxLQUFLcEIsWUFBYjtBQUNJLGlCQUFLL0ksRUFBRSxDQUFDc0YsTUFBSCxDQUFVOEUsaUJBQVYsQ0FBNEJDLGFBQWpDO0FBQWdEO0FBQzVDLG9CQUFJLEtBQUtzRCxXQUFULEVBQXNCO0FBQ2xCLHNCQUFJQyxPQUFLLEdBQUcsS0FBS0MsYUFBTCxDQUFtQitDLEVBQW5CLENBQVo7O0FBQ0FILGtCQUFBQSxHQUFHLEdBQUcsQ0FBQyxLQUFLdkksT0FBTixHQUFpQixDQUFDLEtBQUt5RSxTQUFMLENBQWVHLE1BQWYsR0FBd0IsS0FBS2xFLFFBQTlCLEtBQTJDZ0ksRUFBRSxHQUFHaEQsT0FBSyxDQUFDRSxLQUF0RCxDQUFqQixJQUFrRkYsT0FBSyxDQUFDN0wsR0FBTixHQUFhLEtBQUs2RyxRQUFMLEdBQWdCZ0YsT0FBSyxDQUFDRSxLQUFySCxDQUFOO0FBQ0Esc0JBQUl5RCxJQUFFLEdBQUcsS0FBSzVELFdBQUwsQ0FBaUJpRCxFQUFqQixDQUFUO0FBQ0E5RCxrQkFBQUEsTUFBTSxHQUFJeUUsSUFBRSxHQUFHLENBQUwsR0FBU0EsSUFBVCxHQUFjLEtBQUs1RSxTQUFMLENBQWVHLE1BQXZDO0FBQ0EwRCxrQkFBQUEsTUFBTSxHQUFHQyxHQUFHLEdBQUczRCxNQUFmO0FBQ0gsaUJBTkQsTUFNTztBQUNIMkQsa0JBQUFBLEdBQUcsR0FBRyxDQUFDLEtBQUt2SSxPQUFOLEdBQWlCLENBQUMsS0FBS3lFLFNBQUwsQ0FBZUcsTUFBZixHQUF3QixLQUFLbEUsUUFBOUIsSUFBMENnSSxFQUFqRTtBQUNBOUQsa0JBQUFBLE1BQU0sR0FBRyxLQUFLSCxTQUFMLENBQWVHLE1BQXhCO0FBQ0g7O0FBQ0QwRCxnQkFBQUEsTUFBTSxHQUFHQyxHQUFHLEdBQUczRCxNQUFmOztBQUNBLG9CQUFJLEtBQUtqSyxVQUFULEVBQXFCO0FBQ2pCLHNCQUFJMk8sUUFBTSxHQUFJLEtBQUtwTSxPQUFMLENBQWEwSCxNQUFiLEdBQXNCLENBQXZCLEdBQTZCLEtBQUtxQixrQkFBTCxHQUEwQixDQUFwRTs7QUFDQXNDLGtCQUFBQSxHQUFHLElBQUllLFFBQVA7QUFDQWhCLGtCQUFBQSxNQUFNLElBQUlnQixRQUFWO0FBQ0gsaUJBaEIyQyxDQWlCNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLHVCQUFPO0FBQ0haLGtCQUFBQSxFQUFFLEVBQUVBLEVBREQ7QUFFSEgsa0JBQUFBLEdBQUcsRUFBRUEsR0FGRjtBQUdIRCxrQkFBQUEsTUFBTSxFQUFFQSxNQUhMO0FBSUhyQixrQkFBQUEsQ0FBQyxFQUFFLEtBQUtoSixRQUFMLENBQWNnSixDQUpkO0FBS0hELGtCQUFBQSxDQUFDLEVBQUVzQixNQUFNLEdBQUksS0FBS3JLLFFBQUwsQ0FBY3VMLE9BQWQsR0FBd0I1RTtBQUxsQyxpQkFBUDtBQU9IOztBQUNELGlCQUFLOU0sRUFBRSxDQUFDc0YsTUFBSCxDQUFVOEUsaUJBQVYsQ0FBNEJFLGFBQWpDO0FBQWdEO0FBQzVDLG9CQUFJLEtBQUtxRCxXQUFULEVBQXNCO0FBQ2xCLHNCQUFJQyxPQUFLLEdBQUcsS0FBS0MsYUFBTCxDQUFtQitDLEVBQW5CLENBQVo7O0FBQ0FKLGtCQUFBQSxNQUFNLEdBQUcsS0FBS2xJLFVBQUwsR0FBbUIsQ0FBQyxLQUFLcUUsU0FBTCxDQUFlRyxNQUFmLEdBQXdCLEtBQUtsRSxRQUE5QixLQUEyQ2dJLEVBQUUsR0FBR2hELE9BQUssQ0FBQ0UsS0FBdEQsQ0FBbkIsSUFBb0ZGLE9BQUssQ0FBQzdMLEdBQU4sR0FBYSxLQUFLNkcsUUFBTCxHQUFnQmdGLE9BQUssQ0FBQ0UsS0FBdkgsQ0FBVDtBQUNBLHNCQUFJeUQsSUFBRSxHQUFHLEtBQUs1RCxXQUFMLENBQWlCaUQsRUFBakIsQ0FBVDtBQUNBOUQsa0JBQUFBLE1BQU0sR0FBSXlFLElBQUUsR0FBRyxDQUFMLEdBQVNBLElBQVQsR0FBYyxLQUFLNUUsU0FBTCxDQUFlRyxNQUF2QztBQUNILGlCQUxELE1BS087QUFDSDBELGtCQUFBQSxNQUFNLEdBQUcsS0FBS2xJLFVBQUwsR0FBbUIsQ0FBQyxLQUFLcUUsU0FBTCxDQUFlRyxNQUFmLEdBQXdCLEtBQUtsRSxRQUE5QixJQUEwQ2dJLEVBQXRFO0FBQ0E5RCxrQkFBQUEsTUFBTSxHQUFHLEtBQUtILFNBQUwsQ0FBZUcsTUFBeEI7QUFDSDs7QUFDRDJELGdCQUFBQSxHQUFHLEdBQUdELE1BQU0sR0FBRzFELE1BQWY7O0FBQ0Esb0JBQUksS0FBS2pLLFVBQVQsRUFBcUI7QUFDakIsc0JBQUkyTyxRQUFNLEdBQUksS0FBS3BNLE9BQUwsQ0FBYTBILE1BQWIsR0FBc0IsQ0FBdkIsR0FBNkIsS0FBS3FCLGtCQUFMLEdBQTBCLENBQXBFOztBQUNBc0Msa0JBQUFBLEdBQUcsSUFBSWUsUUFBUDtBQUNBaEIsa0JBQUFBLE1BQU0sSUFBSWdCLFFBQVY7QUFDSDs7QUFDRCx1QkFBTztBQUNIWixrQkFBQUEsRUFBRSxFQUFFQSxFQUREO0FBRUhILGtCQUFBQSxHQUFHLEVBQUVBLEdBRkY7QUFHSEQsa0JBQUFBLE1BQU0sRUFBRUEsTUFITDtBQUlIckIsa0JBQUFBLENBQUMsRUFBRSxLQUFLaEosUUFBTCxDQUFjZ0osQ0FKZDtBQUtIRCxrQkFBQUEsQ0FBQyxFQUFFc0IsTUFBTSxHQUFJLEtBQUtySyxRQUFMLENBQWN1TCxPQUFkLEdBQXdCNUU7QUFMbEMsaUJBQVA7QUFPQTtBQUNIO0FBekRMO0FBMkRIOztBQUNELFdBQUs5TSxFQUFFLENBQUNzRixNQUFILENBQVV1RSxJQUFWLENBQWVVLElBQXBCO0FBQTBCO0FBQ3RCLGNBQUlvSCxPQUFPLEdBQUcxRyxJQUFJLENBQUNzQyxLQUFMLENBQVdxRCxFQUFFLEdBQUcsS0FBSzlILFdBQXJCLENBQWQ7O0FBQ0Esa0JBQVEsS0FBS2QsVUFBYjtBQUNJLGlCQUFLaEksRUFBRSxDQUFDc0YsTUFBSCxDQUFVa0YsYUFBVixDQUF3QlYsVUFBN0I7QUFBeUM7QUFDckMsd0JBQVEsS0FBS2YsWUFBYjtBQUNJLHVCQUFLL0ksRUFBRSxDQUFDc0YsTUFBSCxDQUFVOEUsaUJBQVYsQ0FBNEJDLGFBQWpDO0FBQWdEO0FBQzVDb0csc0JBQUFBLEdBQUcsR0FBRyxDQUFDLEtBQUt2SSxPQUFOLEdBQWlCLENBQUMsS0FBS3lFLFNBQUwsQ0FBZUcsTUFBZixHQUF3QixLQUFLbEUsUUFBOUIsSUFBMEMrSSxPQUFqRTtBQUNBbkIsc0JBQUFBLE1BQU0sR0FBR0MsR0FBRyxHQUFHLEtBQUs5RCxTQUFMLENBQWVHLE1BQTlCO0FBQ0F3RSxzQkFBQUEsS0FBSyxHQUFHZCxNQUFNLEdBQUksS0FBS3JLLFFBQUwsQ0FBY3VMLE9BQWQsR0FBd0IsS0FBSy9FLFNBQUwsQ0FBZUcsTUFBekQ7QUFDQTtBQUNIOztBQUNELHVCQUFLOU0sRUFBRSxDQUFDc0YsTUFBSCxDQUFVOEUsaUJBQVYsQ0FBNEJFLGFBQWpDO0FBQWdEO0FBQzVDa0csc0JBQUFBLE1BQU0sR0FBRyxLQUFLbEksVUFBTCxHQUFtQixDQUFDLEtBQUtxRSxTQUFMLENBQWVHLE1BQWYsR0FBd0IsS0FBS2xFLFFBQTlCLElBQTBDK0ksT0FBdEU7QUFDQWxCLHNCQUFBQSxHQUFHLEdBQUdELE1BQU0sR0FBRyxLQUFLN0QsU0FBTCxDQUFlRyxNQUE5QjtBQUNBd0Usc0JBQUFBLEtBQUssR0FBR2QsTUFBTSxHQUFJLEtBQUtySyxRQUFMLENBQWN1TCxPQUFkLEdBQXdCLEtBQUsvRSxTQUFMLENBQWVHLE1BQXpEO0FBQ0E7QUFDSDtBQVpMOztBQWNBdUUsZ0JBQUFBLEtBQUssR0FBRyxLQUFLN0ksUUFBTCxHQUFrQm9JLEVBQUUsR0FBRyxLQUFLOUgsV0FBWCxJQUEyQixLQUFLNkQsU0FBTCxDQUFlRSxLQUFmLEdBQXVCLEtBQUtuRSxVQUF2RCxDQUF6Qjs7QUFDQSx3QkFBUSxLQUFLTyxjQUFiO0FBQ0ksdUJBQUtqSixFQUFFLENBQUNzRixNQUFILENBQVV5RSxtQkFBVixDQUE4QkMsYUFBbkM7QUFBa0Q7QUFDOUNxSCxzQkFBQUEsS0FBSyxJQUFLLEtBQUtsTCxRQUFMLENBQWNzTCxPQUFkLEdBQXdCLEtBQUs5RSxTQUFMLENBQWVFLEtBQWpEO0FBQ0F3RSxzQkFBQUEsS0FBSyxJQUFLLEtBQUtqTSxPQUFMLENBQWFxTSxPQUFiLEdBQXVCLEtBQUtyTSxPQUFMLENBQWF5SCxLQUE5QztBQUNBO0FBQ0g7O0FBQ0QsdUJBQUs3TSxFQUFFLENBQUNzRixNQUFILENBQVV5RSxtQkFBVixDQUE4QkcsYUFBbkM7QUFBa0Q7QUFDOUNtSCxzQkFBQUEsS0FBSyxJQUFLLENBQUMsSUFBSSxLQUFLbEwsUUFBTCxDQUFjc0wsT0FBbkIsSUFBOEIsS0FBSzlFLFNBQUwsQ0FBZUUsS0FBdkQ7QUFDQXdFLHNCQUFBQSxLQUFLLElBQUssQ0FBQyxJQUFJLEtBQUtqTSxPQUFMLENBQWFxTSxPQUFsQixJQUE2QixLQUFLck0sT0FBTCxDQUFheUgsS0FBcEQ7QUFDQXdFLHNCQUFBQSxLQUFLLElBQUksQ0FBQyxDQUFWO0FBQ0E7QUFDSDtBQVhMOztBQWFBLHVCQUFPO0FBQ0hULGtCQUFBQSxFQUFFLEVBQUVBLEVBREQ7QUFFSEgsa0JBQUFBLEdBQUcsRUFBRUEsR0FGRjtBQUdIRCxrQkFBQUEsTUFBTSxFQUFFQSxNQUhMO0FBSUhyQixrQkFBQUEsQ0FBQyxFQUFFa0MsS0FKQTtBQUtIbkMsa0JBQUFBLENBQUMsRUFBRW9DO0FBTEEsaUJBQVA7QUFPSDs7QUFDRCxpQkFBS3RSLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVWtGLGFBQVYsQ0FBd0JMLFFBQTdCO0FBQXVDO0FBQ25DLHdCQUFRLEtBQUtsQixjQUFiO0FBQ0ksdUJBQUtqSixFQUFFLENBQUNzRixNQUFILENBQVV5RSxtQkFBVixDQUE4QkMsYUFBbkM7QUFBa0Q7QUFDOUNzRyxzQkFBQUEsSUFBSSxHQUFHLEtBQUs5SCxRQUFMLEdBQWlCLENBQUMsS0FBS21FLFNBQUwsQ0FBZUUsS0FBZixHQUF1QixLQUFLbkUsVUFBN0IsSUFBMkNpSixPQUFuRTtBQUNBdEIsc0JBQUFBLEtBQUssR0FBR0MsSUFBSSxHQUFHLEtBQUszRCxTQUFMLENBQWVFLEtBQTlCO0FBQ0F3RSxzQkFBQUEsS0FBSyxHQUFHZixJQUFJLEdBQUksS0FBS25LLFFBQUwsQ0FBY3NMLE9BQWQsR0FBd0IsS0FBSzlFLFNBQUwsQ0FBZUUsS0FBdkQ7QUFDQXdFLHNCQUFBQSxLQUFLLElBQUssS0FBS2pNLE9BQUwsQ0FBYXFNLE9BQWIsR0FBdUIsS0FBS3JNLE9BQUwsQ0FBYXlILEtBQTlDO0FBQ0E7QUFDSDs7QUFDRCx1QkFBSzdNLEVBQUUsQ0FBQ3NGLE1BQUgsQ0FBVXlFLG1CQUFWLENBQThCRyxhQUFuQztBQUFrRDtBQUM5Q21HLHNCQUFBQSxLQUFLLEdBQUcsQ0FBQyxLQUFLakksU0FBTixHQUFtQixDQUFDLEtBQUt1RSxTQUFMLENBQWVFLEtBQWYsR0FBdUIsS0FBS25FLFVBQTdCLElBQTJDaUosT0FBdEU7QUFDQXJCLHNCQUFBQSxJQUFJLEdBQUdELEtBQUssR0FBRyxLQUFLMUQsU0FBTCxDQUFlRSxLQUE5QjtBQUNBd0Usc0JBQUFBLEtBQUssR0FBR2YsSUFBSSxHQUFJLEtBQUtuSyxRQUFMLENBQWNzTCxPQUFkLEdBQXdCLEtBQUs5RSxTQUFMLENBQWVFLEtBQXZEO0FBQ0F3RSxzQkFBQUEsS0FBSyxJQUFLLENBQUMsSUFBSSxLQUFLak0sT0FBTCxDQUFhcU0sT0FBbEIsSUFBNkIsS0FBS3JNLE9BQUwsQ0FBYXlILEtBQXBEO0FBQ0E7QUFDSDtBQWRMOztBQWdCQXlFLGdCQUFBQSxLQUFLLEdBQUcsQ0FBQyxLQUFLcEosT0FBTixHQUFrQjBJLEVBQUUsR0FBRyxLQUFLOUgsV0FBWCxJQUEyQixLQUFLNkQsU0FBTCxDQUFlRyxNQUFmLEdBQXdCLEtBQUtsRSxRQUF4RCxDQUF6Qjs7QUFDQSx3QkFBUSxLQUFLRyxZQUFiO0FBQ0ksdUJBQUsvSSxFQUFFLENBQUNzRixNQUFILENBQVU4RSxpQkFBVixDQUE0QkMsYUFBakM7QUFBZ0Q7QUFDNUNpSCxzQkFBQUEsS0FBSyxJQUFLLENBQUMsSUFBSSxLQUFLbkwsUUFBTCxDQUFjdUwsT0FBbkIsSUFBOEIsS0FBSy9FLFNBQUwsQ0FBZUcsTUFBdkQ7QUFDQXdFLHNCQUFBQSxLQUFLLElBQUssQ0FBQyxJQUFJLEtBQUtsTSxPQUFMLENBQWFzTSxPQUFsQixJQUE2QixLQUFLdE0sT0FBTCxDQUFhMEgsTUFBcEQ7QUFDQTtBQUNIOztBQUNELHVCQUFLOU0sRUFBRSxDQUFDc0YsTUFBSCxDQUFVOEUsaUJBQVYsQ0FBNEJFLGFBQWpDO0FBQWdEO0FBQzVDZ0gsc0JBQUFBLEtBQUssSUFBTSxLQUFLbkwsUUFBTCxDQUFjdUwsT0FBZixHQUEwQixLQUFLL0UsU0FBTCxDQUFlRyxNQUFuRDtBQUNBd0Usc0JBQUFBLEtBQUssSUFBSyxLQUFLbE0sT0FBTCxDQUFhc00sT0FBYixHQUF1QixLQUFLdE0sT0FBTCxDQUFhMEgsTUFBOUM7QUFDQXdFLHNCQUFBQSxLQUFLLElBQUksQ0FBQyxDQUFWO0FBQ0E7QUFDSDtBQVhMOztBQWFBLHVCQUFPO0FBQ0hWLGtCQUFBQSxFQUFFLEVBQUVBLEVBREQ7QUFFSE4sa0JBQUFBLElBQUksRUFBRUEsSUFGSDtBQUdIRCxrQkFBQUEsS0FBSyxFQUFFQSxLQUhKO0FBSUhsQixrQkFBQUEsQ0FBQyxFQUFFa0MsS0FKQTtBQUtIbkMsa0JBQUFBLENBQUMsRUFBRW9DO0FBTEEsaUJBQVA7QUFPSDtBQTVFTDs7QUE4RUE7QUFDSDtBQW5NTDtBQXFNSCxHQTdrQ0k7QUE4a0NMO0FBQ0FNLEVBQUFBLGlCQS9rQ0ssNkJBK2tDYWhCLEVBL2tDYixFQStrQ2lCO0FBQ2xCLFFBQUloTixJQUFJLEdBQUcsS0FBS0MsZUFBTCxDQUFxQitNLEVBQXJCLENBQVg7QUFDQSxRQUFJLENBQUNoTixJQUFMLEVBQ0ksT0FBTyxJQUFQO0FBQ0osUUFBSWlPLElBQUksR0FBRztBQUNQakIsTUFBQUEsRUFBRSxFQUFFQSxFQURHO0FBRVB6QixNQUFBQSxDQUFDLEVBQUV2TCxJQUFJLENBQUN1TCxDQUZEO0FBR1BELE1BQUFBLENBQUMsRUFBRXRMLElBQUksQ0FBQ3NMO0FBSEQsS0FBWDs7QUFLQSxRQUFJLEtBQUs3QixTQUFULEVBQW9CO0FBQ2hCd0UsTUFBQUEsSUFBSSxDQUFDcEIsR0FBTCxHQUFXN00sSUFBSSxDQUFDc0wsQ0FBTCxHQUFVdEwsSUFBSSxDQUFDa0osTUFBTCxJQUFlLElBQUlsSixJQUFJLENBQUM4TixPQUF4QixDQUFyQjtBQUNBRyxNQUFBQSxJQUFJLENBQUNyQixNQUFMLEdBQWM1TSxJQUFJLENBQUNzTCxDQUFMLEdBQVV0TCxJQUFJLENBQUNrSixNQUFMLEdBQWNsSixJQUFJLENBQUM4TixPQUEzQztBQUNILEtBSEQsTUFHTztBQUNIRyxNQUFBQSxJQUFJLENBQUN2QixJQUFMLEdBQVkxTSxJQUFJLENBQUN1TCxDQUFMLEdBQVV2TCxJQUFJLENBQUNpSixLQUFMLEdBQWFqSixJQUFJLENBQUM2TixPQUF4QztBQUNBSSxNQUFBQSxJQUFJLENBQUN4QixLQUFMLEdBQWF6TSxJQUFJLENBQUN1TCxDQUFMLEdBQVV2TCxJQUFJLENBQUNpSixLQUFMLElBQWMsSUFBSWpKLElBQUksQ0FBQzZOLE9BQXZCLENBQXZCO0FBQ0g7O0FBQ0QsV0FBT0ksSUFBUDtBQUNILEdBaG1DSTtBQWltQ0w7QUFDQUMsRUFBQUEsVUFsbUNLLHNCQWttQ01sQixFQWxtQ04sRUFrbUNVO0FBQ1gsUUFBSSxLQUFLck8sUUFBVCxFQUNJLE9BQU8sS0FBSzZOLFlBQUwsQ0FBa0JRLEVBQWxCLENBQVAsQ0FESixLQUVLO0FBQ0QsVUFBSSxLQUFLMU4scUJBQVQsRUFDSSxPQUFPLEtBQUtrTixZQUFMLENBQWtCUSxFQUFsQixDQUFQLENBREosS0FHSSxPQUFPLEtBQUtnQixpQkFBTCxDQUF1QmhCLEVBQXZCLENBQVA7QUFDUDtBQUNKLEdBM21DSTtBQTRtQ0w7QUFDQS9DLEVBQUFBLGFBN21DSyx5QkE2bUNTa0UsTUE3bUNULEVBNm1DaUI7QUFDbEIsUUFBSSxDQUFDLEtBQUtwRSxXQUFWLEVBQ0ksT0FBTyxJQUFQO0FBQ0osUUFBSW9FLE1BQU0sSUFBSSxJQUFkLEVBQ0lBLE1BQU0sR0FBRyxLQUFLdFAsU0FBZDtBQUNKLFFBQUltTCxLQUFLLEdBQUcsQ0FBWjtBQUNBLFFBQUlFLEtBQUssR0FBRyxDQUFaOztBQUNBLFNBQUssSUFBSThDLEVBQVQsSUFBZSxLQUFLakQsV0FBcEIsRUFBaUM7QUFDN0IsVUFBSXFFLFFBQVEsQ0FBQ3BCLEVBQUQsQ0FBUixHQUFlbUIsTUFBbkIsRUFBMkI7QUFDdkJuRSxRQUFBQSxLQUFLLElBQUksS0FBS0QsV0FBTCxDQUFpQmlELEVBQWpCLENBQVQ7QUFDQTlDLFFBQUFBLEtBQUs7QUFDUjtBQUNKOztBQUNELFdBQU87QUFDSC9MLE1BQUFBLEdBQUcsRUFBRTZMLEtBREY7QUFFSEUsTUFBQUEsS0FBSyxFQUFFQTtBQUZKLEtBQVA7QUFJSCxHQTluQ0k7QUErbkNMO0FBQ0ExRyxFQUFBQSxjQWhvQ0ssNEJBZ29DWTtBQUNiLFNBQUs2SyxTQUFMLEdBQWlCLEtBQUs1RSxTQUFMLEdBQWlCLEtBQUt1QyxPQUF0QixHQUFnQyxLQUFLRyxRQUF0RDtBQUNILEdBbG9DSTtBQW1vQ0w7QUFDQTFJLEVBQUFBLGNBcG9DSyw0QkFvb0NZO0FBQ2IsUUFBSTFELENBQUMsR0FBRyxJQUFSOztBQUNBLFFBQUlBLENBQUMsQ0FBQ3VPLGNBQUYsSUFBb0IsSUFBeEIsRUFBOEI7QUFDMUIsVUFBSXRPLElBQUksR0FBR0QsQ0FBQyxDQUFDRSxlQUFGLENBQWtCRixDQUFDLENBQUN1TyxjQUFwQixDQUFYO0FBQ0F2TyxNQUFBQSxDQUFDLENBQUN1TyxjQUFGLEdBQW1CLElBQW5COztBQUNBLFVBQUl0TyxJQUFKLEVBQVU7QUFDTkEsUUFBQUEsSUFBSSxDQUFDdU8sU0FBTCxDQUFlLElBQUluUyxFQUFFLENBQUNvUyxRQUFQLENBQ1gsSUFBSXBTLEVBQUUsQ0FBQ3FTLE9BQVAsQ0FBZSxFQUFmLEVBQW1CLElBQW5CLENBRFcsRUFFWCxJQUFJclMsRUFBRSxDQUFDcVMsT0FBUCxDQUFlLEVBQWYsRUFBbUIsQ0FBbkIsQ0FGVyxDQUFmO0FBT0g7QUFDSjs7QUFDRDFPLElBQUFBLENBQUMsQ0FBQ2pCLFlBQUY7O0FBRUEsUUFBSWlCLENBQUMsQ0FBQ2hDLFVBQUYsSUFBZ0J6QixTQUFTLENBQUNtSixRQUExQixJQUNBLENBQUMxRixDQUFDLENBQUMyTyxRQURQLEVBRUU7QUFDRTtBQUNBM08sTUFBQUEsQ0FBQyxDQUFDNE8sTUFBRjtBQUNILEtBTEQsTUFLTyxJQUFJNU8sQ0FBQyxDQUFDaEMsVUFBRixJQUFnQnpCLFNBQVMsQ0FBQ2tDLElBQTlCLEVBQW9DO0FBQ3ZDLFVBQUl1QixDQUFDLENBQUNzTyxTQUFGLElBQWUsSUFBbkIsRUFBeUI7QUFDckIsYUFBS08sV0FBTDtBQUNILE9BRkQsTUFFTztBQUNIN08sUUFBQUEsQ0FBQyxDQUFDNE8sTUFBRjtBQUNIO0FBQ0o7QUFDSixHQWpxQ0k7QUFrcUNMO0FBQ0F2TCxFQUFBQSxhQW5xQ0sseUJBbXFDUzZILEVBbnFDVCxFQW1xQ2E0RCxnQkFucUNiLEVBbXFDK0I7QUFDaEMsUUFBSSxLQUFLL0ssV0FBTCxDQUFpQmdMLG1CQUFqQixDQUFxQzdELEVBQXJDLEVBQXlDNEQsZ0JBQXpDLENBQUosRUFDSTtBQUNKLFFBQUlFLElBQUksR0FBRzlELEVBQUUsQ0FBQytELFVBQUgsS0FBa0I1UyxFQUFFLENBQUM2UyxLQUFILENBQVNDLFNBQTNCLElBQXdDakUsRUFBRSxDQUFDa0UsTUFBSCxLQUFjLEtBQUt2TSxJQUF0RTs7QUFDQSxRQUFJLENBQUNtTSxJQUFMLEVBQVc7QUFDUCxVQUFJSyxRQUFRLEdBQUduRSxFQUFFLENBQUNrRSxNQUFsQjs7QUFDQSxhQUFPQyxRQUFRLENBQUNDLE9BQVQsSUFBb0IsSUFBcEIsSUFBNEJELFFBQVEsQ0FBQ0UsTUFBNUM7QUFDSUYsUUFBQUEsUUFBUSxHQUFHQSxRQUFRLENBQUNFLE1BQXBCO0FBREo7O0FBRUEsV0FBS0MsV0FBTCxHQUFtQkgsUUFBUSxDQUFDQyxPQUFULElBQW9CLElBQXBCLEdBQTJCRCxRQUEzQixHQUFzQ25FLEVBQUUsQ0FBQ2tFLE1BQTVEO0FBQW1FO0FBQ3RFO0FBQ0osR0E3cUNJO0FBOHFDTDtBQUNBOUwsRUFBQUEsVUEvcUNLLHdCQStxQ1E7QUFDVCxRQUFJdEQsQ0FBQyxHQUFHLElBQVI7QUFDQUEsSUFBQUEsQ0FBQyxDQUFDeVAsVUFBRixHQUFlLElBQWY7O0FBQ0EsUUFBSXpQLENBQUMsQ0FBQ2hDLFVBQUYsSUFBZ0J6QixTQUFTLENBQUNtSixRQUE5QixFQUF3QztBQUNwQyxVQUFJMUYsQ0FBQyxDQUFDMk8sUUFBTixFQUNJM08sQ0FBQyxDQUFDMFAsZ0JBQUYsR0FBcUIsSUFBckI7QUFDSjFQLE1BQUFBLENBQUMsQ0FBQzRPLE1BQUY7QUFDSCxLQUpELE1BSU8sSUFBSTVPLENBQUMsQ0FBQ2hDLFVBQUYsSUFBZ0J6QixTQUFTLENBQUNrQyxJQUE5QixFQUFvQztBQUN2QyxVQUFJdUIsQ0FBQyxDQUFDc08sU0FBRixJQUFlLElBQW5CLEVBQXlCO0FBQ3JCdE8sUUFBQUEsQ0FBQyxDQUFDNk8sV0FBRjtBQUNILE9BRkQsTUFFTztBQUNIN08sUUFBQUEsQ0FBQyxDQUFDNE8sTUFBRjtBQUNIO0FBQ0o7O0FBQ0QsU0FBS1ksV0FBTCxHQUFtQixJQUFuQjtBQUNILEdBOXJDSTtBQWdzQ0xoTSxFQUFBQSxpQkFoc0NLLDZCQWdzQ2EwSCxFQWhzQ2IsRUFnc0NpQjRELGdCQWhzQ2pCLEVBZ3NDbUM7QUFDcEMsUUFBSTlPLENBQUMsR0FBRyxJQUFSO0FBQ0EsUUFBSUEsQ0FBQyxDQUFDK0QsV0FBRixDQUFjZ0wsbUJBQWQsQ0FBa0M3RCxFQUFsQyxFQUFzQzRELGdCQUF0QyxLQUEyRDVELEVBQUUsQ0FBQ3lFLFFBQWxFLEVBQ0k7QUFFSjNQLElBQUFBLENBQUMsQ0FBQ3lQLFVBQUYsR0FBZSxJQUFmOztBQUNBLFFBQUl6UCxDQUFDLENBQUNoQyxVQUFGLElBQWdCekIsU0FBUyxDQUFDbUosUUFBOUIsRUFBd0M7QUFDcEMsVUFBSTFGLENBQUMsQ0FBQzJPLFFBQU4sRUFDSTNPLENBQUMsQ0FBQzBQLGdCQUFGLEdBQXFCLElBQXJCO0FBQ0oxUCxNQUFBQSxDQUFDLENBQUM0TyxNQUFGO0FBQ0gsS0FKRCxNQUlPLElBQUk1TyxDQUFDLENBQUNoQyxVQUFGLElBQWdCekIsU0FBUyxDQUFDa0MsSUFBOUIsRUFBb0M7QUFDdkMsVUFBSXVCLENBQUMsQ0FBQ3NPLFNBQUYsSUFBZSxJQUFuQixFQUF5QjtBQUNyQnRPLFFBQUFBLENBQUMsQ0FBQzZPLFdBQUY7QUFDSCxPQUZELE1BRU87QUFDSDdPLFFBQUFBLENBQUMsQ0FBQzRPLE1BQUY7QUFDSDtBQUNKOztBQUNELFNBQUtZLFdBQUwsR0FBbUIsSUFBbkI7QUFDSCxHQWx0Q0k7QUFtdENMO0FBQ0E1TCxFQUFBQSxjQXB0Q0ssNEJBb3RDWTtBQUNiLFFBQUksS0FBSzNDLFdBQUwsQ0FBaUIsS0FBakIsQ0FBSixFQUNJLEtBQUtsQyxZQUFMO0FBQ1AsR0F2dENJO0FBd3RDTDtBQUNBNlEsRUFBQUEsZUF6dENLLDJCQXl0Q1czUCxJQXp0Q1gsRUF5dENpQjtBQUFBOztBQUNsQixRQUFJLEtBQUtnQixXQUFMLENBQWlCLEtBQWpCLENBQUosRUFBNkI7QUFDekIsVUFDSyxDQUFDLEtBQUt5SSxTQUFOLElBQW1CekosSUFBSSxDQUFDaUosS0FBTCxJQUFjLEtBQUtGLFNBQUwsQ0FBZUUsS0FBakQsSUFDSSxLQUFLUSxTQUFMLElBQWtCekosSUFBSSxDQUFDa0osTUFBTCxJQUFlLEtBQUtILFNBQUwsQ0FBZUcsTUFGeEQsRUFHRTtBQUNFLFlBQUksQ0FBQyxLQUFLYSxXQUFWLEVBQ0ksS0FBS0EsV0FBTCxHQUFtQixFQUFuQjtBQUNKLFlBQUk1TCxHQUFHLEdBQUcsS0FBS3NMLFNBQUwsR0FBaUJ6SixJQUFJLENBQUNrSixNQUF0QixHQUErQmxKLElBQUksQ0FBQ2lKLEtBQTlDOztBQUNBLFlBQUksS0FBS2MsV0FBTCxDQUFpQi9KLElBQUksQ0FBQ3FQLE9BQXRCLEtBQWtDbFIsR0FBdEMsRUFBMkM7QUFDdkMsZUFBSzRMLFdBQUwsQ0FBaUIvSixJQUFJLENBQUNxUCxPQUF0QixJQUFpQ2xSLEdBQWpDOztBQUNBLGVBQUtnRCxjQUFMOztBQUNBLGVBQUtLLE9BQUwsQ0FBYXFGLFFBQWIsQ0FBc0JDLE9BQXRCLENBQThCLFVBQUFDLEtBQUssRUFBSTtBQUNuQyxZQUFBLEtBQUksQ0FBQzZJLGNBQUwsQ0FBb0I3SSxLQUFwQjtBQUNILFdBRkQsRUFIdUMsQ0FNdkM7O0FBQ0EsY0FBSSxDQUFDOEksS0FBSyxDQUFDLEtBQUtDLGVBQU4sQ0FBVixFQUFrQztBQUM5QixpQkFBS04sVUFBTCxHQUFrQixJQUFsQjtBQUNBLGlCQUFLTyxVQUFMLENBQWdCLEtBQUtDLFdBQXJCO0FBQ0EsaUJBQUtDLFFBQUwsQ0FBYyxLQUFLSCxlQUFuQixFQUFvQ3pJLElBQUksQ0FBQzZJLEdBQUwsQ0FBUyxDQUFULEVBQVksS0FBS0MsZ0JBQUwsR0FBMEIsSUFBSUMsSUFBSixFQUFELENBQWFDLE9BQWIsS0FBeUIsSUFBOUQsQ0FBcEM7QUFDSDtBQUNKO0FBQ0o7QUFDSjtBQUNKLEdBanZDSTtBQWt2Q0w7QUFDQXpCLEVBQUFBLFdBbnZDSyx5QkFtdkNTO0FBQ1YsUUFBSTdPLENBQUMsR0FBRyxJQUFSO0FBQ0EsUUFBSSxDQUFDQSxDQUFDLENBQUNoQixNQUFILEtBQWNnQixDQUFDLENBQUN3TixVQUFGLEdBQWUsQ0FBZixJQUFvQnhOLENBQUMsQ0FBQ3VOLFlBQUYsR0FBaUIsQ0FBckMsSUFBMEN2TixDQUFDLENBQUN5TixhQUFGLEdBQWtCLENBQTVELElBQWlFek4sQ0FBQyxDQUFDc04sV0FBRixHQUFnQixDQUEvRixDQUFKLEVBQ0k7QUFDSixRQUFJaUQsTUFBTSxHQUFHdlEsQ0FBQyxDQUFDMEosU0FBRixHQUFjMUosQ0FBQyxDQUFDaU0sT0FBaEIsR0FBMEJqTSxDQUFDLENBQUNvTSxRQUF6QztBQUNBLFFBQUlvRSxHQUFHLEdBQUcsQ0FBQ3hRLENBQUMsQ0FBQzBKLFNBQUYsR0FBYzFKLENBQUMsQ0FBQzZDLElBQUYsQ0FBT3NHLE1BQXJCLEdBQThCbkosQ0FBQyxDQUFDNkMsSUFBRixDQUFPcUcsS0FBdEMsSUFBK0NsSixDQUFDLENBQUMzQixZQUEzRDtBQUNBLFFBQUlvUyxPQUFPLEdBQUduSixJQUFJLENBQUNhLEdBQUwsQ0FBU25JLENBQUMsQ0FBQ3NPLFNBQUYsR0FBY2lDLE1BQXZCLElBQWlDQyxHQUEvQzs7QUFDQSxRQUFJQyxPQUFKLEVBQWE7QUFDVCxVQUFJQyxZQUFZLEdBQUcsRUFBbkI7O0FBQ0EsY0FBUTFRLENBQUMsQ0FBQ3NHLGNBQVY7QUFDSSxhQUFLLENBQUwsQ0FESixDQUNXOztBQUNQLGFBQUssQ0FBTDtBQUFPO0FBQ0gsY0FBSXRHLENBQUMsQ0FBQ3NPLFNBQUYsR0FBY2lDLE1BQWxCLEVBQTBCO0FBQ3RCdlEsWUFBQUEsQ0FBQyxDQUFDMlEsT0FBRixDQUFVRCxZQUFWLEVBRHNCLENBRXRCO0FBQ0gsV0FIRCxNQUdPO0FBQ0gxUSxZQUFBQSxDQUFDLENBQUM0USxRQUFGLENBQVdGLFlBQVgsRUFERyxDQUVIO0FBQ0g7O0FBQ0Q7O0FBQ0osYUFBSyxDQUFMLENBWEosQ0FXVzs7QUFDUCxhQUFLLENBQUw7QUFBTztBQUNILGNBQUkxUSxDQUFDLENBQUNzTyxTQUFGLEdBQWNpQyxNQUFsQixFQUEwQjtBQUN0QnZRLFlBQUFBLENBQUMsQ0FBQzJRLE9BQUYsQ0FBVUQsWUFBVjtBQUNILFdBRkQsTUFFTztBQUNIMVEsWUFBQUEsQ0FBQyxDQUFDNFEsUUFBRixDQUFXRixZQUFYO0FBQ0g7O0FBQ0Q7QUFsQlI7QUFvQkgsS0F0QkQsTUFzQk8sSUFBSTFRLENBQUMsQ0FBQ3dOLFVBQUYsSUFBZ0IsQ0FBaEIsSUFBcUJ4TixDQUFDLENBQUN1TixZQUFGLElBQWtCLENBQXZDLElBQTRDdk4sQ0FBQyxDQUFDeU4sYUFBRixJQUFtQixDQUEvRCxJQUFvRXpOLENBQUMsQ0FBQ3NOLFdBQUYsSUFBaUIsQ0FBekYsRUFBNEY7QUFDL0Z0TixNQUFBQSxDQUFDLENBQUM0TyxNQUFGO0FBQ0g7O0FBQ0Q1TyxJQUFBQSxDQUFDLENBQUNzTyxTQUFGLEdBQWMsSUFBZDtBQUNILEdBcHhDSTtBQXF4Q0w7QUFDQU0sRUFBQUEsTUF0eENLLG9CQXN4Q0k7QUFDTCxRQUFJNU8sQ0FBQyxHQUFHLElBQVI7QUFDQSxRQUFJLENBQUNBLENBQUMsQ0FBQ2lCLFdBQUYsRUFBTCxFQUNJO0FBQ0osUUFBSWpCLENBQUMsQ0FBQ3dOLFVBQUYsR0FBZSxDQUFmLElBQW9CeE4sQ0FBQyxDQUFDdU4sWUFBRixHQUFpQixDQUFyQyxJQUEwQ3ZOLENBQUMsQ0FBQ3lOLGFBQUYsR0FBa0IsQ0FBNUQsSUFBaUV6TixDQUFDLENBQUNzTixXQUFGLEdBQWdCLENBQXJGLEVBQ0k7QUFDSnROLElBQUFBLENBQUMsQ0FBQzJPLFFBQUYsR0FBYSxJQUFiLENBTkssQ0FPTDs7QUFDQTNPLElBQUFBLENBQUMsQ0FBQ3FOLGdCQUFGOztBQUNBLFFBQUlRLE1BQU0sR0FBRyxDQUFDN04sQ0FBQyxDQUFDMEosU0FBRixHQUFjMUosQ0FBQyxDQUFDdUUsT0FBaEIsR0FBMEJ2RSxDQUFDLENBQUM2RSxRQUE3QixLQUEwQzdFLENBQUMsQ0FBQzBKLFNBQUYsR0FBYzFKLENBQUMsQ0FBQzZDLElBQUYsQ0FBT3NHLE1BQXJCLEdBQThCbkosQ0FBQyxDQUFDNkMsSUFBRixDQUFPcUcsS0FBL0UsQ0FBYjtBQUNBLFFBQUl3SCxZQUFZLEdBQUcsRUFBbkI7QUFDQTFRLElBQUFBLENBQUMsQ0FBQ2tRLFFBQUYsQ0FBV2xRLENBQUMsQ0FBQ3VCLGFBQWIsRUFBNEJtUCxZQUE1QixFQUEwQzdDLE1BQTFDO0FBQ0gsR0FseUNJO0FBbXlDTDtBQUNBZ0QsRUFBQUEsTUFweUNLLG9CQW95Q0k7QUFDTCxRQUFJLEtBQUt0UixxQkFBTCxJQUE4QixDQUE5QixJQUFtQyxLQUFLNEMsV0FBNUMsRUFDSSxPQUZDLENBR0w7O0FBQ0EsUUFBSSxLQUFLdkQsUUFBVCxFQUFtQjtBQUNmLFVBQUltRCxHQUFHLEdBQUksS0FBS0csY0FBTCxHQUFzQixLQUFLM0MscUJBQTVCLEdBQXFELEtBQUs2QyxjQUExRCxHQUEyRSxLQUFLQSxjQUFoRixHQUFrRyxLQUFLRixjQUFMLEdBQXNCLEtBQUszQyxxQkFBdkk7O0FBQ0EsV0FBSyxJQUFJeUMsQ0FBQyxHQUFHLEtBQUtFLGNBQWxCLEVBQWtDRixDQUFDLEdBQUdELEdBQXRDLEVBQTJDQyxDQUFDLEVBQTVDLEVBQWdEO0FBQzVDLFlBQUlrTSxJQUFJLEdBQUcsS0FBS3JJLFdBQUwsQ0FBaUI3RCxDQUFqQixDQUFYO0FBQ0EsWUFBSWtNLElBQUosRUFDSSxLQUFLZCxtQkFBTCxDQUF5QmMsSUFBekI7QUFDUDs7QUFFRCxVQUFJLEtBQUtoTSxjQUFMLElBQXVCLEtBQUtFLGNBQUwsR0FBc0IsQ0FBakQsRUFBb0Q7QUFBRTtBQUNsRCxZQUFJLEtBQUs4SyxnQkFBVCxFQUEyQjtBQUN2QixlQUFLaEwsY0FBTCxHQUFzQixDQUF0QjtBQUNBLGVBQUtDLFdBQUwsR0FBbUIsS0FBbkI7QUFDQSxjQUFJLENBQUMsS0FBSzRCLFdBQUwsQ0FBaUIrTSxXQUFqQixFQUFMLEVBQ0ksS0FBSzVELGdCQUFMLEdBQXdCLEtBQXhCO0FBQ1AsU0FMRCxNQUtPO0FBQ0gsZUFBSy9LLFdBQUwsR0FBbUIsSUFBbkI7O0FBQ0EsZUFBS04saUJBQUw7O0FBQ0EsZUFBS1YsWUFBTCxHQUFvQixLQUFwQjs7QUFDQSxlQUFLa00sZ0JBQUw7O0FBQ0EsY0FBSSxLQUFLcFAsU0FBTCxJQUFrQjFCLFNBQVMsQ0FBQ2tDLElBQWhDLEVBQ0ksS0FBSzZDLFVBQUwsR0FBa0IsS0FBS0MsYUFBdkI7QUFDUDtBQUNKLE9BZEQsTUFjTztBQUNILGFBQUtXLGNBQUwsSUFBdUIsS0FBSzNDLHFCQUE1QjtBQUNIO0FBQ0osS0F6QkQsTUF5Qk87QUFDSCxVQUFJLEtBQUsyQyxjQUFMLEdBQXNCLEtBQUtwRCxTQUEvQixFQUEwQztBQUN0QyxZQUFJaUQsSUFBRyxHQUFJLEtBQUtHLGNBQUwsR0FBc0IsS0FBSzNDLHFCQUE1QixHQUFxRCxLQUFLVCxTQUExRCxHQUFzRSxLQUFLQSxTQUEzRSxHQUF3RixLQUFLb0QsY0FBTCxHQUFzQixLQUFLM0MscUJBQTdIOztBQUNBLGFBQUssSUFBSXlDLEdBQUMsR0FBRyxLQUFLRSxjQUFsQixFQUFrQ0YsR0FBQyxHQUFHRCxJQUF0QyxFQUEyQ0MsR0FBQyxFQUE1QyxFQUFnRDtBQUM1QyxlQUFLQyxvQkFBTCxDQUEwQkQsR0FBMUI7QUFDSDs7QUFDRCxhQUFLRSxjQUFMLElBQXVCLEtBQUszQyxxQkFBNUI7QUFDSCxPQU5ELE1BTU87QUFDSCxhQUFLNEMsV0FBTCxHQUFtQixJQUFuQjs7QUFDQSxhQUFLa0wsZ0JBQUw7O0FBQ0EsWUFBSSxLQUFLcFAsU0FBTCxJQUFrQjFCLFNBQVMsQ0FBQ2tDLElBQWhDLEVBQ0ksS0FBSzZDLFVBQUwsR0FBa0IsS0FBS0MsYUFBdkI7QUFDUDtBQUNKO0FBQ0osR0EvMENJOztBQWcxQ0w7Ozs7QUFJQTZMLEVBQUFBLG1CQXAxQ0ssK0JBbzFDZWMsSUFwMUNmLEVBbzFDcUI7QUFDdEIsUUFBSWpPLElBQUksR0FBRyxLQUFLQyxlQUFMLENBQXFCZ08sSUFBSSxDQUFDakIsRUFBMUIsQ0FBWDs7QUFDQSxRQUFJLENBQUNoTixJQUFMLEVBQVc7QUFBRTtBQUNULFVBQUk4USxNQUFNLEdBQUcsS0FBS3BPLEtBQUwsQ0FBV0MsSUFBWCxLQUFvQixDQUFqQzs7QUFDQSxVQUFJbU8sTUFBSixFQUFZO0FBQ1I5USxRQUFBQSxJQUFJLEdBQUcsS0FBSzBDLEtBQUwsQ0FBV3pFLEdBQVgsRUFBUCxDQURRLENBRVI7QUFDSCxPQUhELE1BR087QUFDSCtCLFFBQUFBLElBQUksR0FBRzVELEVBQUUsQ0FBQ29KLFdBQUgsQ0FBZSxLQUFLakQsUUFBcEIsQ0FBUCxDQURHLENBRUg7QUFDSDs7QUFDRCxVQUFJdkMsSUFBSSxDQUFDcVAsT0FBTCxJQUFnQnBCLElBQUksQ0FBQ2pCLEVBQXpCLEVBQTZCO0FBQ3pCaE4sUUFBQUEsSUFBSSxDQUFDcVAsT0FBTCxHQUFlcEIsSUFBSSxDQUFDakIsRUFBcEI7QUFDQWhOLFFBQUFBLElBQUksQ0FBQytRLGNBQUwsQ0FBb0IsS0FBS2hJLFNBQXpCO0FBQ0g7O0FBQ0QvSSxNQUFBQSxJQUFJLENBQUNnUixXQUFMLENBQWlCLElBQUk1VSxFQUFFLENBQUNxUCxFQUFQLENBQVV3QyxJQUFJLENBQUMxQyxDQUFmLEVBQWtCMEMsSUFBSSxDQUFDM0MsQ0FBdkIsQ0FBakI7O0FBQ0EsV0FBSzJGLGNBQUwsQ0FBb0JqUixJQUFwQjs7QUFDQSxXQUFLd0IsT0FBTCxDQUFhMFAsUUFBYixDQUFzQmxSLElBQXRCOztBQUNBLFVBQUk4USxNQUFNLElBQUksS0FBS3RILGlCQUFuQixFQUFzQztBQUNsQyxZQUFJMkgsTUFBTSxHQUFHblIsSUFBSSxDQUFDeUIsWUFBTCxDQUFrQnJGLEVBQUUsQ0FBQ21OLE1BQXJCLENBQWI7QUFDQSxZQUFJNEgsTUFBSixFQUNJQSxNQUFNLENBQUNDLGVBQVA7QUFDUDs7QUFDRHBSLE1BQUFBLElBQUksQ0FBQ3FSLGVBQUwsQ0FBcUIsS0FBSzdQLE9BQUwsQ0FBYThQLGFBQWIsR0FBNkIsQ0FBbEQ7QUFFQSxVQUFJblIsUUFBUSxHQUFHSCxJQUFJLENBQUN5QixZQUFMLENBQWtCakYsUUFBbEIsQ0FBZjtBQUNBd0QsTUFBQUEsSUFBSSxDQUFDRyxRQUFMLEdBQWdCQSxRQUFoQjs7QUFDQSxVQUFJQSxRQUFKLEVBQWM7QUFDVkEsUUFBQUEsUUFBUSxDQUFDb1IsS0FBVCxHQUFpQixJQUFqQjs7QUFDQXBSLFFBQUFBLFFBQVEsQ0FBQzJDLGNBQVQ7QUFDSDs7QUFDRCxVQUFJLEtBQUt2RCxXQUFULEVBQXNCO0FBQ2xCbkQsUUFBQUEsRUFBRSxDQUFDTyxTQUFILENBQWErQixZQUFiLENBQTBCNEIsVUFBMUIsQ0FBcUMsQ0FBQyxLQUFLZixXQUFOLENBQXJDLEVBQXlEUyxJQUF6RCxFQUErRGlPLElBQUksQ0FBQ2pCLEVBQUwsR0FBVSxLQUFLek0sZUFBOUU7QUFDSDtBQUNKLEtBaENELE1BZ0NPLElBQUksS0FBS1csWUFBTCxJQUFxQixLQUFLM0IsV0FBOUIsRUFBMkM7QUFBRTtBQUNoRFMsTUFBQUEsSUFBSSxDQUFDZ1IsV0FBTCxDQUFpQixJQUFJNVUsRUFBRSxDQUFDcVAsRUFBUCxDQUFVd0MsSUFBSSxDQUFDMUMsQ0FBZixFQUFrQjBDLElBQUksQ0FBQzNDLENBQXZCLENBQWpCOztBQUNBLFdBQUsyRixjQUFMLENBQW9CalIsSUFBcEIsRUFGOEMsQ0FHOUM7OztBQUNBLFVBQUksS0FBS1QsV0FBVCxFQUFzQjtBQUNsQm5ELFFBQUFBLEVBQUUsQ0FBQ08sU0FBSCxDQUFhK0IsWUFBYixDQUEwQjRCLFVBQTFCLENBQXFDLENBQUMsS0FBS2YsV0FBTixDQUFyQyxFQUF5RFMsSUFBekQsRUFBK0RpTyxJQUFJLENBQUNqQixFQUFMLEdBQVUsS0FBS3pNLGVBQTlFO0FBQ0g7QUFDSjs7QUFDRCxTQUFLMFEsY0FBTCxDQUFvQmpSLElBQXBCOztBQUVBLFNBQUt3UixlQUFMLENBQXFCeFIsSUFBSSxDQUFDRyxRQUExQjs7QUFDQSxRQUFJLEtBQUt3RixnQkFBTCxDQUFzQmhGLE9BQXRCLENBQThCc04sSUFBSSxDQUFDakIsRUFBbkMsSUFBeUMsQ0FBN0MsRUFBZ0Q7QUFDNUMsV0FBS3JILGdCQUFMLENBQXNCL0UsSUFBdEIsQ0FBMkJxTixJQUFJLENBQUNqQixFQUFoQztBQUNIO0FBQ0osR0FwNENJO0FBcTRDTDtBQUNBaEwsRUFBQUEsb0JBdDRDSyxnQ0FzNENnQm1NLE1BdDRDaEIsRUFzNEN3QjtBQUN6QixRQUFJbk8sSUFBSSxHQUFHLEtBQUt3QixPQUFMLENBQWFxRixRQUFiLENBQXNCc0gsTUFBdEIsQ0FBWDs7QUFDQSxRQUFJLENBQUNuTyxJQUFMLEVBQVc7QUFBRTtBQUNUQSxNQUFBQSxJQUFJLEdBQUc1RCxFQUFFLENBQUNvSixXQUFILENBQWUsS0FBS2pELFFBQXBCLENBQVA7QUFDQXZDLE1BQUFBLElBQUksQ0FBQ3FQLE9BQUwsR0FBZWxCLE1BQWY7QUFDQSxXQUFLM00sT0FBTCxDQUFhMFAsUUFBYixDQUFzQmxSLElBQXRCO0FBQ0EsVUFBSUcsUUFBUSxHQUFHSCxJQUFJLENBQUN5QixZQUFMLENBQWtCakYsUUFBbEIsQ0FBZjtBQUNBd0QsTUFBQUEsSUFBSSxDQUFDRyxRQUFMLEdBQWdCQSxRQUFoQjs7QUFDQSxVQUFJQSxRQUFKLEVBQWM7QUFDVkEsUUFBQUEsUUFBUSxDQUFDb1IsS0FBVCxHQUFpQixJQUFqQjs7QUFDQXBSLFFBQUFBLFFBQVEsQ0FBQzJDLGNBQVQ7QUFDSDs7QUFDRCxVQUFJLEtBQUt2RCxXQUFULEVBQXNCO0FBQ2xCbkQsUUFBQUEsRUFBRSxDQUFDTyxTQUFILENBQWErQixZQUFiLENBQTBCNEIsVUFBMUIsQ0FBcUMsQ0FBQyxLQUFLZixXQUFOLENBQXJDLEVBQXlEUyxJQUF6RCxFQUErRG1PLE1BQS9EO0FBQ0g7QUFDSixLQWJELE1BYU8sSUFBSSxLQUFLak4sWUFBTCxJQUFxQixLQUFLM0IsV0FBOUIsRUFBMkM7QUFBRTtBQUNoRFMsTUFBQUEsSUFBSSxDQUFDcVAsT0FBTCxHQUFlbEIsTUFBZjs7QUFDQSxVQUFJLEtBQUs1TyxXQUFULEVBQXNCO0FBQ2xCbkQsUUFBQUEsRUFBRSxDQUFDTyxTQUFILENBQWErQixZQUFiLENBQTBCNEIsVUFBMUIsQ0FBcUMsQ0FBQyxLQUFLZixXQUFOLENBQXJDLEVBQXlEUyxJQUF6RCxFQUErRG1PLE1BQS9EO0FBQ0g7QUFDSjs7QUFDRCxTQUFLcUQsZUFBTCxDQUFxQnhSLElBQUksQ0FBQ0csUUFBMUI7O0FBQ0EsUUFBSSxLQUFLd0YsZ0JBQUwsQ0FBc0JoRixPQUF0QixDQUE4QndOLE1BQTlCLElBQXdDLENBQTVDLEVBQStDO0FBQzNDLFdBQUt4SSxnQkFBTCxDQUFzQi9FLElBQXRCLENBQTJCdU4sTUFBM0I7QUFDSDtBQUNKLEdBLzVDSTtBQWk2Q0xxRCxFQUFBQSxlQWo2Q0ssMkJBaTZDV3JSLFFBajZDWCxFQWk2Q3FCO0FBQ3RCLFFBQUksQ0FBQ0EsUUFBTCxFQUNJOztBQUNKLFFBQUksS0FBS1gsWUFBTCxHQUFvQmpELFlBQVksQ0FBQ2tELElBQXJDLEVBQTJDO0FBQ3ZDLGNBQVEsS0FBS0QsWUFBYjtBQUNJLGFBQUtqRCxZQUFZLENBQUNvRCxNQUFsQjtBQUNJUSxVQUFBQSxRQUFRLENBQUNDLFFBQVQsR0FBb0IsS0FBS04sVUFBTCxJQUFtQkssUUFBUSxDQUFDeUMsSUFBVCxDQUFjeU0sT0FBckQ7QUFDQTs7QUFDSixhQUFLOVMsWUFBWSxDQUFDaUUsSUFBbEI7QUFDSUwsVUFBQUEsUUFBUSxDQUFDQyxRQUFULEdBQW9CLEtBQUtNLFlBQUwsQ0FBa0JDLE9BQWxCLENBQTBCUixRQUFRLENBQUN5QyxJQUFULENBQWN5TSxPQUF4QyxLQUFvRCxDQUF4RTtBQUNBO0FBTlI7QUFRSDtBQUNKLEdBOTZDSTtBQSs2Q0w7QUFDQTRCLEVBQUFBLGNBaDdDSywwQkFnN0NValIsSUFoN0NWLEVBZzdDZ0I7QUFDakI7QUFDQSxRQUFJMkMsSUFBSjs7QUFDQSxRQUFJLEtBQUtvSCxXQUFMLElBQW9CLEtBQUtBLFdBQUwsQ0FBaUIvSixJQUFJLENBQUNxUCxPQUF0QixDQUF4QixFQUF3RDtBQUNwRDFNLE1BQUFBLElBQUksR0FBRyxLQUFLb0gsV0FBTCxDQUFpQi9KLElBQUksQ0FBQ3FQLE9BQXRCLENBQVA7QUFDSCxLQUZELE1BRU87QUFDSCxVQUFJLEtBQUtuSyxXQUFMLEdBQW1CLENBQXZCLEVBQ0lsRixJQUFJLENBQUMrUSxjQUFMLENBQW9CLEtBQUtoSSxTQUF6QixFQURKLEtBR0lwRyxJQUFJLEdBQUcsS0FBSzhHLFNBQUwsR0FBaUIsS0FBS1YsU0FBTCxDQUFlRyxNQUFoQyxHQUF5QyxLQUFLSCxTQUFMLENBQWVFLEtBQS9EO0FBQ1A7O0FBQ0QsUUFBSXRHLElBQUosRUFBVTtBQUNOLFVBQUksS0FBSzhHLFNBQVQsRUFDSXpKLElBQUksQ0FBQ2tKLE1BQUwsR0FBY3ZHLElBQWQsQ0FESixLQUdJM0MsSUFBSSxDQUFDaUosS0FBTCxHQUFhdEcsSUFBYjtBQUNQO0FBQ0osR0FqOENJOztBQWs4Q0w7Ozs7QUFJQWlOLEVBQUFBLGNBdDhDSywwQkFzOENVNkIsWUF0OENWLEVBczhDd0I7QUFDekIsUUFBSXpSLElBQUksR0FBRzZQLEtBQUssQ0FBQzRCLFlBQUQsQ0FBTCxHQUFzQkEsWUFBdEIsR0FBcUMsS0FBS3hSLGVBQUwsQ0FBcUJ3UixZQUFyQixDQUFoRDtBQUNBLFFBQUlDLEdBQUcsR0FBRyxLQUFLeEQsVUFBTCxDQUFnQmxPLElBQUksQ0FBQ3FQLE9BQXJCLENBQVY7QUFDQXJQLElBQUFBLElBQUksQ0FBQ2dSLFdBQUwsQ0FBaUJVLEdBQUcsQ0FBQ25HLENBQXJCLEVBQXdCbUcsR0FBRyxDQUFDcEcsQ0FBNUI7QUFDSCxHQTE4Q0k7O0FBMjhDTDs7Ozs7QUFLQXFHLEVBQUFBLGVBaDlDSywyQkFnOUNXQyxJQWg5Q1gsRUFnOUNpQmpVLElBaDlDakIsRUFnOUN1QjtBQUN4QixRQUFJb0MsQ0FBQyxHQUFHLElBQVI7QUFDQSxRQUFJLENBQUNBLENBQUMsQ0FBQ2lCLFdBQUYsRUFBTCxFQUNJOztBQUNKLFFBQUksQ0FBQzZRLEtBQUssQ0FBQ0MsT0FBTixDQUFjRixJQUFkLENBQUwsRUFBMEI7QUFDdEJBLE1BQUFBLElBQUksR0FBRyxDQUFDQSxJQUFELENBQVA7QUFDSDs7QUFDRCxRQUFJalUsSUFBSSxJQUFJLElBQVosRUFBa0I7QUFDZG9DLE1BQUFBLENBQUMsQ0FBQ1csWUFBRixHQUFpQmtSLElBQWpCO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsVUFBSXpELE1BQUosRUFBWTFOLEdBQVo7O0FBQ0EsVUFBSTlDLElBQUosRUFBVTtBQUNOLGFBQUssSUFBSW9FLENBQUMsR0FBRzZQLElBQUksQ0FBQ2pGLE1BQUwsR0FBYyxDQUEzQixFQUE4QjVLLENBQUMsSUFBSSxDQUFuQyxFQUFzQ0EsQ0FBQyxFQUF2QyxFQUEyQztBQUN2Q29NLFVBQUFBLE1BQU0sR0FBR3lELElBQUksQ0FBQzdQLENBQUQsQ0FBYjtBQUNBdEIsVUFBQUEsR0FBRyxHQUFHVixDQUFDLENBQUNXLFlBQUYsQ0FBZUMsT0FBZixDQUF1QndOLE1BQXZCLENBQU47O0FBQ0EsY0FBSTFOLEdBQUcsR0FBRyxDQUFWLEVBQWE7QUFDVFYsWUFBQUEsQ0FBQyxDQUFDVyxZQUFGLENBQWVFLElBQWYsQ0FBb0J1TixNQUFwQjtBQUNIO0FBQ0o7QUFDSixPQVJELE1BUU87QUFDSCxhQUFLLElBQUlwTSxHQUFDLEdBQUc2UCxJQUFJLENBQUNqRixNQUFMLEdBQWMsQ0FBM0IsRUFBOEI1SyxHQUFDLElBQUksQ0FBbkMsRUFBc0NBLEdBQUMsRUFBdkMsRUFBMkM7QUFDdkNvTSxVQUFBQSxNQUFNLEdBQUd5RCxJQUFJLENBQUM3UCxHQUFELENBQWI7QUFDQXRCLFVBQUFBLEdBQUcsR0FBR1YsQ0FBQyxDQUFDVyxZQUFGLENBQWVDLE9BQWYsQ0FBdUJ3TixNQUF2QixDQUFOOztBQUNBLGNBQUkxTixHQUFHLElBQUksQ0FBWCxFQUFjO0FBQ1ZWLFlBQUFBLENBQUMsQ0FBQ1csWUFBRixDQUFlRyxNQUFmLENBQXNCSixHQUF0QixFQUEyQixDQUEzQjtBQUNIO0FBQ0o7QUFDSjtBQUNKOztBQUNEVixJQUFBQSxDQUFDLENBQUNtQixZQUFGLEdBQWlCLElBQWpCOztBQUNBbkIsSUFBQUEsQ0FBQyxDQUFDakIsWUFBRjtBQUNILEdBLytDSTs7QUFnL0NMOzs7OztBQUtBaVQsRUFBQUEsVUFyL0NLLHNCQXEvQ01ILElBci9DTixFQXEvQ1k7QUFDYixRQUFJLENBQUMsS0FBSzVRLFdBQUwsRUFBTCxFQUNJOztBQUNKLFFBQUksQ0FBQzZRLEtBQUssQ0FBQ0MsT0FBTixDQUFjRixJQUFkLENBQUwsRUFBMEI7QUFDdEJBLE1BQUFBLElBQUksR0FBRyxDQUFDQSxJQUFELENBQVA7QUFDSDs7QUFDRCxTQUFLLElBQUk3UCxDQUFDLEdBQUcsQ0FBUixFQUFXRCxHQUFHLEdBQUc4UCxJQUFJLENBQUNqRixNQUEzQixFQUFtQzVLLENBQUMsR0FBR0QsR0FBdkMsRUFBNENDLENBQUMsRUFBN0MsRUFBaUQ7QUFDN0MsVUFBSW9NLE1BQU0sR0FBR3lELElBQUksQ0FBQzdQLENBQUQsQ0FBakI7QUFDQSxVQUFJL0IsSUFBSSxHQUFHLEtBQUtDLGVBQUwsQ0FBcUJrTyxNQUFyQixDQUFYOztBQUNBLFVBQUluTyxJQUFKLEVBQVU7QUFDTjVELFFBQUFBLEVBQUUsQ0FBQ08sU0FBSCxDQUFhK0IsWUFBYixDQUEwQjRCLFVBQTFCLENBQXFDLENBQUMsS0FBS2YsV0FBTixDQUFyQyxFQUF5RFMsSUFBekQsRUFBK0RtTyxNQUFNLEdBQUcsS0FBSzVOLGVBQTdFO0FBQ0g7QUFDSjtBQUNKLEdBbGdESTs7QUFtZ0RMOzs7QUFHQXlSLEVBQUFBLFNBdGdESyx1QkFzZ0RPO0FBQ1IsUUFBSSxDQUFDLEtBQUtoUixXQUFMLEVBQUwsRUFDSTtBQUNKLFNBQUtELFFBQUwsR0FBZ0IsS0FBS0EsUUFBckI7QUFDSCxHQTFnREk7O0FBMmdETDs7Ozs7QUFLQWQsRUFBQUEsZUFoaERLLDJCQWdoRFdrTyxNQWhoRFgsRUFnaERtQjtBQUNwQixTQUFLLElBQUlwTSxDQUFDLEdBQUcsS0FBS1AsT0FBTCxDQUFhOFAsYUFBYixHQUE2QixDQUExQyxFQUE2Q3ZQLENBQUMsSUFBSSxDQUFsRCxFQUFxREEsQ0FBQyxFQUF0RCxFQUEwRDtBQUN0RCxVQUFJLEtBQUtQLE9BQUwsQ0FBYXFGLFFBQWIsQ0FBc0I5RSxDQUF0QixFQUF5QnNOLE9BQXpCLElBQW9DbEIsTUFBeEMsRUFDSSxPQUFPLEtBQUszTSxPQUFMLENBQWFxRixRQUFiLENBQXNCOUUsQ0FBdEIsQ0FBUDtBQUNQO0FBQ0osR0FyaERJOztBQXNoREw7Ozs7QUFJQWtRLEVBQUFBLGVBMWhESyw2QkEwaERhO0FBQ2QsUUFBSWpTLElBQUosRUFBVWtTLFNBQVY7QUFDQSxRQUFJcEksTUFBTSxHQUFHLEVBQWI7O0FBQ0EsU0FBSyxJQUFJL0gsQ0FBQyxHQUFHLEtBQUtQLE9BQUwsQ0FBYThQLGFBQWIsR0FBNkIsQ0FBMUMsRUFBNkN2UCxDQUFDLElBQUksQ0FBbEQsRUFBcURBLENBQUMsRUFBdEQsRUFBMEQ7QUFDdEQvQixNQUFBQSxJQUFJLEdBQUcsS0FBS3dCLE9BQUwsQ0FBYXFGLFFBQWIsQ0FBc0I5RSxDQUF0QixDQUFQO0FBQ0FtUSxNQUFBQSxTQUFTLEdBQUcsSUFBWjs7QUFDQSxVQUFJQSxTQUFKLEVBQWU7QUFDWCxhQUFLLElBQUloRixDQUFDLEdBQUcsS0FBSy9LLGNBQUwsR0FBc0IsQ0FBbkMsRUFBc0MrSyxDQUFDLElBQUksQ0FBM0MsRUFBOENBLENBQUMsRUFBL0MsRUFBbUQ7QUFDL0MsY0FBSSxDQUFDLEtBQUt0SCxXQUFMLENBQWlCc0gsQ0FBakIsQ0FBTCxFQUNJO0FBQ0osY0FBSWlCLE1BQU0sR0FBRyxLQUFLdkksV0FBTCxDQUFpQnNILENBQWpCLEVBQW9CRixFQUFqQzs7QUFDQSxjQUFJaE4sSUFBSSxDQUFDcVAsT0FBTCxJQUFnQmxCLE1BQXBCLEVBQTRCO0FBQ3hCK0QsWUFBQUEsU0FBUyxHQUFHLEtBQVo7QUFDQTtBQUNIO0FBQ0o7QUFDSjs7QUFDRCxVQUFJQSxTQUFKLEVBQWU7QUFDWHBJLFFBQUFBLE1BQU0sQ0FBQ2xKLElBQVAsQ0FBWVosSUFBWjtBQUNIO0FBQ0o7O0FBQ0QsV0FBTzhKLE1BQVA7QUFDSCxHQWhqREk7QUFpakRMO0FBQ0FsSSxFQUFBQSxpQkFsakRLLCtCQWtqRGU7QUFDaEIsUUFBSSxLQUFLakQsUUFBVCxFQUFtQjtBQUNmLFVBQUl3VCxHQUFHLEdBQUcsS0FBS0YsZUFBTCxFQUFWOztBQUNBLFdBQUssSUFBSWxRLENBQUMsR0FBR29RLEdBQUcsQ0FBQ3hGLE1BQUosR0FBYSxDQUExQixFQUE2QjVLLENBQUMsSUFBSSxDQUFsQyxFQUFxQ0EsQ0FBQyxFQUF0QyxFQUEwQztBQUN0QyxZQUFJL0IsSUFBSSxHQUFHbVMsR0FBRyxDQUFDcFEsQ0FBRCxDQUFkO0FBQ0EsWUFBSSxLQUFLd04sV0FBTCxJQUFvQnZQLElBQUksQ0FBQ3FQLE9BQUwsSUFBZ0IsS0FBS0UsV0FBTCxDQUFpQkYsT0FBekQsRUFDSTs7QUFDSixhQUFLM00sS0FBTCxDQUFXMFAsR0FBWCxDQUFlcFMsSUFBZjtBQUNILE9BUGMsQ0FRZjs7QUFDSCxLQVRELE1BU087QUFDSCxhQUFPLEtBQUt3QixPQUFMLENBQWE4UCxhQUFiLEdBQTZCLEtBQUt6UyxTQUF6QyxFQUFvRDtBQUNoRCxhQUFLd1QsY0FBTCxDQUFvQixLQUFLN1EsT0FBTCxDQUFhcUYsUUFBYixDQUFzQixLQUFLckYsT0FBTCxDQUFhOFAsYUFBYixHQUE2QixDQUFuRCxDQUFwQjtBQUNIO0FBQ0o7QUFDSixHQWprREk7QUFra0RMO0FBQ0FlLEVBQUFBLGNBbmtESywwQkFta0RVclMsSUFua0RWLEVBbWtEZ0I7QUFDakI7QUFDQUEsSUFBQUEsSUFBSSxDQUFDZ0gsZ0JBQUw7QUFDQSxRQUFJaEgsSUFBSSxDQUFDeUMsT0FBVCxFQUNJekMsSUFBSSxDQUFDeUMsT0FBTDtBQUNKekMsSUFBQUEsSUFBSSxHQUFHLElBQVA7QUFDSCxHQXprREk7O0FBMGtETDs7OztBQUlBc1MsRUFBQUEsVUE5a0RLLHNCQThrRE1uRSxNQTlrRE4sRUE4a0Rjb0UsUUE5a0RkLEVBOGtEd0JDLE9BOWtEeEIsRUE4a0RpQztBQUNsQyxRQUFJelMsQ0FBQyxHQUFHLElBQVI7QUFFQSxRQUFJLENBQUNBLENBQUMsQ0FBQ2lCLFdBQUYsRUFBRCxJQUFvQmpCLENBQUMsQ0FBQ2hCLE1BQXRCLElBQWdDLENBQUNnQixDQUFDLENBQUNwQixRQUF2QyxFQUNJLE9BQU92QyxFQUFFLENBQUM2RSxLQUFILENBQVMsNENBQVQsQ0FBUDtBQUVKLFFBQUlsQixDQUFDLENBQUNvTCxhQUFOLEVBQ0ksT0FBTy9PLEVBQUUsQ0FBQ3FXLElBQUgsQ0FBUSxpREFBUixDQUFQO0FBRUosUUFBSXpTLElBQUksR0FBR0QsQ0FBQyxDQUFDRSxlQUFGLENBQWtCa08sTUFBbEIsQ0FBWDs7QUFDQSxRQUFJLENBQUNuTyxJQUFMLEVBQVc7QUFDUHVTLE1BQUFBLFFBQVEsQ0FBQ3BFLE1BQUQsQ0FBUjtBQUNBO0FBQ0g7O0FBQ0RwTyxJQUFBQSxDQUFDLENBQUNvTCxhQUFGLEdBQWtCLElBQWxCO0FBQ0EsUUFBSXVILFNBQVMsR0FBRzNTLENBQUMsQ0FBQzZGLFdBQUYsQ0FBYzdGLENBQUMsQ0FBQzZGLFdBQUYsQ0FBYytHLE1BQWQsR0FBdUIsQ0FBckMsRUFBd0NLLEVBQXhEO0FBQ0EsUUFBSTJGLGVBQWUsR0FBRzNTLElBQUksQ0FBQ0csUUFBTCxDQUFjQyxRQUFwQztBQUNBSixJQUFBQSxJQUFJLENBQUNHLFFBQUwsQ0FBY3lTLE9BQWQsQ0FBc0JKLE9BQXRCLEVBQStCLFlBQU07QUFDakM7QUFDQSxVQUFJSyxLQUFKOztBQUNBLFVBQUlILFNBQVMsR0FBRzNTLENBQUMsQ0FBQ2xCLFNBQUYsR0FBYyxDQUE5QixFQUFpQztBQUM3QmdVLFFBQUFBLEtBQUssR0FBR0gsU0FBUyxHQUFHLENBQXBCO0FBQ0g7O0FBQ0QsVUFBSUcsS0FBSyxJQUFJLElBQWIsRUFBbUI7QUFDZixZQUFJQyxPQUFPLEdBQUcvUyxDQUFDLENBQUN5TSxZQUFGLENBQWVxRyxLQUFmLENBQWQ7O0FBQ0E5UyxRQUFBQSxDQUFDLENBQUM2RixXQUFGLENBQWNoRixJQUFkLENBQW1Ca1MsT0FBbkI7QUFDQSxZQUFJL1MsQ0FBQyxDQUFDcEIsUUFBTixFQUNJb0IsQ0FBQyxDQUFDb04sbUJBQUYsQ0FBc0IyRixPQUF0QixFQURKLEtBR0kvUyxDQUFDLENBQUNpQyxvQkFBRixDQUF1QjZRLEtBQXZCO0FBQ1AsT0FQRCxNQVFJOVMsQ0FBQyxDQUFDbEIsU0FBRjs7QUFDSixVQUFJa0IsQ0FBQyxDQUFDUCxZQUFGLElBQWtCakQsWUFBWSxDQUFDb0QsTUFBbkMsRUFBMkM7QUFDdkMsWUFBSWdULGVBQUosRUFBcUI7QUFDakI1UyxVQUFBQSxDQUFDLENBQUNGLFdBQUYsR0FBZ0IsQ0FBQyxDQUFqQjtBQUNILFNBRkQsTUFFTyxJQUFJRSxDQUFDLENBQUNGLFdBQUYsR0FBZ0IsQ0FBaEIsSUFBcUIsQ0FBekIsRUFBNEI7QUFDL0JFLFVBQUFBLENBQUMsQ0FBQ0YsV0FBRjtBQUNIO0FBQ0osT0FORCxNQU1PLElBQUlFLENBQUMsQ0FBQ1AsWUFBRixJQUFrQmpELFlBQVksQ0FBQ2lFLElBQS9CLElBQXVDVCxDQUFDLENBQUNXLFlBQUYsQ0FBZWlNLE1BQTFELEVBQWtFO0FBQ3JFLFlBQUlsTSxHQUFHLEdBQUdWLENBQUMsQ0FBQ1csWUFBRixDQUFlQyxPQUFmLENBQXVCd04sTUFBdkIsQ0FBVixDQURxRSxDQUVyRTs7QUFDQSxZQUFJMU4sR0FBRyxJQUFJLENBQVgsRUFBYztBQUNWVixVQUFBQSxDQUFDLENBQUNXLFlBQUYsQ0FBZUcsTUFBZixDQUFzQkosR0FBdEIsRUFBMkIsQ0FBM0I7QUFDSCxTQUxvRSxDQU1yRTs7O0FBQ0EsYUFBSyxJQUFJc0IsQ0FBQyxHQUFHaEMsQ0FBQyxDQUFDVyxZQUFGLENBQWVpTSxNQUFmLEdBQXdCLENBQXJDLEVBQXdDNUssQ0FBQyxJQUFJLENBQTdDLEVBQWdEQSxDQUFDLEVBQWpELEVBQXFEO0FBQ2pELGNBQUlpTCxFQUFFLEdBQUdqTixDQUFDLENBQUNXLFlBQUYsQ0FBZXFCLENBQWYsQ0FBVDtBQUNBLGNBQUlpTCxFQUFFLElBQUltQixNQUFWLEVBQ0lwTyxDQUFDLENBQUNXLFlBQUYsQ0FBZXFCLENBQWY7QUFDUDtBQUNKOztBQUNELFVBQUloQyxDQUFDLENBQUNnSyxXQUFOLEVBQW1CO0FBQ2YsWUFBSWhLLENBQUMsQ0FBQ2dLLFdBQUYsQ0FBY29FLE1BQWQsQ0FBSixFQUNJLE9BQU9wTyxDQUFDLENBQUNnSyxXQUFGLENBQWNvRSxNQUFkLENBQVA7QUFDSixZQUFJNEUsYUFBYSxHQUFHLEVBQXBCO0FBQ0EsWUFBSXBRLElBQUo7O0FBQ0EsYUFBSyxJQUFJcUssR0FBVCxJQUFlak4sQ0FBQyxDQUFDZ0ssV0FBakIsRUFBOEI7QUFDMUJwSCxVQUFBQSxJQUFJLEdBQUc1QyxDQUFDLENBQUNnSyxXQUFGLENBQWNpRCxHQUFkLENBQVA7QUFDQUEsVUFBQUEsR0FBRSxHQUFHb0IsUUFBUSxDQUFDcEIsR0FBRCxDQUFiO0FBQ0ErRixVQUFBQSxhQUFhLENBQUMvRixHQUFFLElBQUlBLEdBQUUsSUFBSW1CLE1BQU4sR0FBZSxDQUFmLEdBQW1CLENBQXZCLENBQUgsQ0FBYixHQUE2Q3hMLElBQTdDO0FBQ0g7O0FBQ0Q1QyxRQUFBQSxDQUFDLENBQUNnSyxXQUFGLEdBQWdCZ0osYUFBaEI7QUFDSCxPQTdDZ0MsQ0E4Q2pDOzs7QUFDQSxVQUFJQyxHQUFHLEdBQUcsS0FBVjtBQUNBLFVBQUlDLElBQUosRUFBVUMsTUFBVjs7QUFDQSxXQUFLLElBQUluUixHQUFDLEdBQUc4USxLQUFLLElBQUksSUFBVCxHQUFnQkEsS0FBaEIsR0FBd0JILFNBQXJDLEVBQWdEM1EsR0FBQyxJQUFJb00sTUFBTSxHQUFHLENBQTlELEVBQWlFcE0sR0FBQyxFQUFsRSxFQUFzRTtBQUNsRS9CLFFBQUFBLElBQUksR0FBR0QsQ0FBQyxDQUFDRSxlQUFGLENBQWtCOEIsR0FBbEIsQ0FBUDs7QUFDQSxZQUFJL0IsSUFBSixFQUFVO0FBQ04sY0FBSW1ULE9BQU8sR0FBR3BULENBQUMsQ0FBQ3lNLFlBQUYsQ0FBZXpLLEdBQUMsR0FBRyxDQUFuQixDQUFkOztBQUNBa1IsVUFBQUEsSUFBSSxHQUFHLENBQ0gsSUFBSTdXLEVBQUUsQ0FBQ2dYLE1BQVAsQ0FBY0osR0FBZCxFQUFtQixJQUFJNVcsRUFBRSxDQUFDcVAsRUFBUCxDQUFVMEgsT0FBTyxDQUFDNUgsQ0FBbEIsRUFBcUI0SCxPQUFPLENBQUM3SCxDQUE3QixDQUFuQixDQURHLENBQVA7O0FBR0EsY0FBSXZKLEdBQUMsSUFBSW9NLE1BQU0sR0FBRyxDQUFsQixFQUFxQjtBQUNqQitFLFlBQUFBLE1BQU0sR0FBRyxJQUFUO0FBQ0FELFlBQUFBLElBQUksQ0FBQ3JTLElBQUwsQ0FBVSxJQUFJeEUsRUFBRSxDQUFDaVgsUUFBUCxDQUFnQixZQUFNO0FBQzVCdFQsY0FBQUEsQ0FBQyxDQUFDb0wsYUFBRixHQUFrQixLQUFsQjtBQUNBb0gsY0FBQUEsUUFBUSxDQUFDcEUsTUFBRCxDQUFSO0FBQ0gsYUFIUyxDQUFWO0FBSUg7O0FBQ0QsY0FBSThFLElBQUksQ0FBQ3RHLE1BQUwsR0FBYyxDQUFsQixFQUNJM00sSUFBSSxDQUFDdU8sU0FBTCxDQUFlLElBQUluUyxFQUFFLENBQUNrWCxRQUFQLENBQWdCTCxJQUFoQixDQUFmLEVBREosS0FHSWpULElBQUksQ0FBQ3VPLFNBQUwsQ0FBZTBFLElBQUksQ0FBQyxDQUFELENBQW5CO0FBQ1A7QUFDSjs7QUFDRCxVQUFJLENBQUNDLE1BQUwsRUFBYTtBQUNUblQsUUFBQUEsQ0FBQyxDQUFDb0wsYUFBRixHQUFrQixLQUFsQjtBQUNBb0gsUUFBQUEsUUFBUSxDQUFDcEUsTUFBRCxDQUFSO0FBQ0g7QUFDSixLQXpFRCxFQXlFRyxJQXpFSDtBQTBFSCxHQXpxREk7O0FBMHFETDs7Ozs7OztBQU9BOEIsRUFBQUEsUUFqckRLLG9CQWlyREk5QixNQWpyREosRUFpckRZc0MsWUFqckRaLEVBaXJEMEI3QyxNQWpyRDFCLEVBaXJEa0MyRixVQWpyRGxDLEVBaXJEOEM7QUFDL0MsUUFBSXhULENBQUMsR0FBRyxJQUFSO0FBQ0EsUUFBSSxDQUFDQSxDQUFDLENBQUNpQixXQUFGLEVBQUwsRUFDSTs7QUFDSmpCLElBQUFBLENBQUMsQ0FBQytELFdBQUYsQ0FBYzBQLGNBQWQ7O0FBQ0EsUUFBSS9DLFlBQVksSUFBSSxJQUFwQixFQUE0QjtBQUN4QkEsTUFBQUEsWUFBWSxHQUFHLEVBQWYsQ0FESixLQUVLLElBQUlBLFlBQVksR0FBRyxDQUFuQixFQUNEQSxZQUFZLEdBQUcsQ0FBZjtBQUNKLFFBQUl0QyxNQUFNLEdBQUcsQ0FBYixFQUNJQSxNQUFNLEdBQUcsQ0FBVCxDQURKLEtBRUssSUFBSUEsTUFBTSxJQUFJcE8sQ0FBQyxDQUFDbEIsU0FBaEIsRUFDRHNQLE1BQU0sR0FBR3BPLENBQUMsQ0FBQ2xCLFNBQUYsR0FBYyxDQUF2QixDQVoyQyxDQWEvQzs7QUFDQSxRQUFJLENBQUNrQixDQUFDLENBQUNwQixRQUFILElBQWVvQixDQUFDLENBQUNpRSxPQUFqQixJQUE0QmpFLENBQUMsQ0FBQ2lFLE9BQUYsQ0FBVXJDLE9BQTFDLEVBQ0k1QixDQUFDLENBQUNpRSxPQUFGLENBQVV5UCxZQUFWO0FBRUosUUFBSS9CLEdBQUcsR0FBRzNSLENBQUMsQ0FBQ21PLFVBQUYsQ0FBYUMsTUFBYixDQUFWO0FBQ0EsUUFBSXVGLE9BQUosRUFBYUMsT0FBYjs7QUFFQSxZQUFRNVQsQ0FBQyxDQUFDc0csY0FBVjtBQUNJLFdBQUssQ0FBTDtBQUFPO0FBQ0hxTixRQUFBQSxPQUFPLEdBQUdoQyxHQUFHLENBQUNoRixJQUFkO0FBQ0EsWUFBSWtCLE1BQU0sSUFBSSxJQUFkLEVBQ0k4RixPQUFPLElBQUkzVCxDQUFDLENBQUM2QyxJQUFGLENBQU9xRyxLQUFQLEdBQWUyRSxNQUExQixDQURKLEtBR0k4RixPQUFPLElBQUkzVCxDQUFDLENBQUM2RSxRQUFiO0FBQ0o4TSxRQUFBQSxHQUFHLEdBQUcsSUFBSXRWLEVBQUUsQ0FBQ3FQLEVBQVAsQ0FBVWlJLE9BQVYsRUFBbUIsQ0FBbkIsQ0FBTjtBQUNBOztBQUNKLFdBQUssQ0FBTDtBQUFPO0FBQ0hBLFFBQUFBLE9BQU8sR0FBR2hDLEdBQUcsQ0FBQ2pGLEtBQUosR0FBWTFNLENBQUMsQ0FBQzZDLElBQUYsQ0FBT3FHLEtBQTdCO0FBQ0EsWUFBSTJFLE1BQU0sSUFBSSxJQUFkLEVBQ0k4RixPQUFPLElBQUkzVCxDQUFDLENBQUM2QyxJQUFGLENBQU9xRyxLQUFQLEdBQWUyRSxNQUExQixDQURKLEtBR0k4RixPQUFPLElBQUkzVCxDQUFDLENBQUN5RSxTQUFiO0FBQ0prTixRQUFBQSxHQUFHLEdBQUcsSUFBSXRWLEVBQUUsQ0FBQ3FQLEVBQVAsQ0FBVWlJLE9BQU8sR0FBRzNULENBQUMsQ0FBQ3lCLE9BQUYsQ0FBVXlILEtBQTlCLEVBQXFDLENBQXJDLENBQU47QUFDQTs7QUFDSixXQUFLLENBQUw7QUFBTztBQUNIMEssUUFBQUEsT0FBTyxHQUFHakMsR0FBRyxDQUFDN0UsR0FBZDtBQUNBLFlBQUllLE1BQU0sSUFBSSxJQUFkLEVBQ0krRixPQUFPLElBQUk1VCxDQUFDLENBQUM2QyxJQUFGLENBQU9zRyxNQUFQLEdBQWdCMEUsTUFBM0IsQ0FESixLQUdJK0YsT0FBTyxJQUFJNVQsQ0FBQyxDQUFDdUUsT0FBYjtBQUNKb04sUUFBQUEsR0FBRyxHQUFHLElBQUl0VixFQUFFLENBQUNxUCxFQUFQLENBQVUsQ0FBVixFQUFhLENBQUNrSSxPQUFkLENBQU47QUFDQTs7QUFDSixXQUFLLENBQUw7QUFBTztBQUNIQSxRQUFBQSxPQUFPLEdBQUdqQyxHQUFHLENBQUM5RSxNQUFKLEdBQWE3TSxDQUFDLENBQUM2QyxJQUFGLENBQU9zRyxNQUE5QjtBQUNBLFlBQUkwRSxNQUFNLElBQUksSUFBZCxFQUNJK0YsT0FBTyxJQUFJNVQsQ0FBQyxDQUFDNkMsSUFBRixDQUFPc0csTUFBUCxHQUFnQjBFLE1BQTNCLENBREosS0FHSStGLE9BQU8sSUFBSTVULENBQUMsQ0FBQzJFLFVBQWI7QUFDSmdOLFFBQUFBLEdBQUcsR0FBRyxJQUFJdFYsRUFBRSxDQUFDcVAsRUFBUCxDQUFVLENBQVYsRUFBYSxDQUFDa0ksT0FBRCxHQUFXNVQsQ0FBQyxDQUFDeUIsT0FBRixDQUFVMEgsTUFBbEMsQ0FBTjtBQUNBO0FBaENSOztBQWtDQSxRQUFJMEssT0FBTyxHQUFHN1QsQ0FBQyxDQUFDeUIsT0FBRixDQUFVNkosV0FBVixFQUFkO0FBQ0F1SSxJQUFBQSxPQUFPLEdBQUd2TSxJQUFJLENBQUNhLEdBQUwsQ0FBU25JLENBQUMsQ0FBQzBKLFNBQUYsR0FBY21LLE9BQU8sQ0FBQ3RJLENBQXRCLEdBQTBCc0ksT0FBTyxDQUFDckksQ0FBM0MsQ0FBVjtBQUVBLFFBQUlzSSxVQUFVLEdBQUc5VCxDQUFDLENBQUMwSixTQUFGLEdBQWNpSSxHQUFHLENBQUNwRyxDQUFsQixHQUFzQm9HLEdBQUcsQ0FBQ25HLENBQTNDO0FBQ0EsUUFBSXVJLFNBQVMsR0FBR3pNLElBQUksQ0FBQ2EsR0FBTCxDQUFTLENBQUNuSSxDQUFDLENBQUN5UCxVQUFGLElBQWdCLElBQWhCLEdBQXVCelAsQ0FBQyxDQUFDeVAsVUFBekIsR0FBc0NvRSxPQUF2QyxJQUFrREMsVUFBM0QsSUFBeUUsRUFBekYsQ0ExRCtDLENBMkQvQzs7QUFFQTlULElBQUFBLENBQUMsQ0FBQytELFdBQUYsQ0FBYzBQLGNBQWQ7O0FBRUEsUUFBSU0sU0FBSixFQUFlO0FBQ1gvVCxNQUFBQSxDQUFDLENBQUN5UCxVQUFGLEdBQWVxRSxVQUFmO0FBQ0E5VCxNQUFBQSxDQUFDLENBQUMrUCxlQUFGLEdBQW9CM0IsTUFBcEI7QUFDQXBPLE1BQUFBLENBQUMsQ0FBQ29RLGdCQUFGLEdBQXVCLElBQUlDLElBQUosRUFBRCxDQUFhQyxPQUFiLEtBQXlCLElBQTFCLEdBQWtDSSxZQUF2RDs7QUFDQTFRLE1BQUFBLENBQUMsQ0FBQytELFdBQUYsQ0FBY2lRLGNBQWQsQ0FBNkJyQyxHQUE3QixFQUFrQ2pCLFlBQWxDLEVBSlcsQ0FLWDs7O0FBQ0ExUSxNQUFBQSxDQUFDLENBQUNpUSxXQUFGLEdBQWdCalEsQ0FBQyxDQUFDaVUsWUFBRixDQUFlLFlBQU07QUFDakMsWUFBSSxDQUFDalUsQ0FBQyxDQUFDMFAsZ0JBQVAsRUFBeUI7QUFDckIxUCxVQUFBQSxDQUFDLENBQUMyTyxRQUFGLEdBQWEzTyxDQUFDLENBQUMwUCxnQkFBRixHQUFxQixLQUFsQztBQUNIOztBQUNEMVAsUUFBQUEsQ0FBQyxDQUFDeVAsVUFBRixHQUNJelAsQ0FBQyxDQUFDK1AsZUFBRixHQUNBL1AsQ0FBQyxDQUFDb1EsZ0JBQUYsR0FDQXBRLENBQUMsQ0FBQ2lRLFdBQUYsR0FDQSxJQUpKLENBSmlDLENBU2pDOztBQUNBLFlBQUl1RCxVQUFKLEVBQWdCO0FBQ1o7QUFDQSxjQUFJdlQsSUFBSSxHQUFHRCxDQUFDLENBQUNFLGVBQUYsQ0FBa0JrTyxNQUFsQixDQUFYOztBQUNBLGNBQUluTyxJQUFKLEVBQVU7QUFDTkEsWUFBQUEsSUFBSSxDQUFDdU8sU0FBTCxDQUFlLElBQUluUyxFQUFFLENBQUNvUyxRQUFQLENBQ1gsSUFBSXBTLEVBQUUsQ0FBQ3FTLE9BQVAsQ0FBZSxFQUFmLEVBQW1CLElBQW5CLENBRFcsRUFFWCxJQUFJclMsRUFBRSxDQUFDcVMsT0FBUCxDQUFlLEVBQWYsRUFBbUIsQ0FBbkIsQ0FGVyxDQUFmO0FBSUg7QUFDSjtBQUNKLE9BcEJlLEVBb0JiZ0MsWUFBWSxHQUFHLEVBcEJGLENBQWhCOztBQXNCQSxVQUFJQSxZQUFZLElBQUksQ0FBcEIsRUFBdUI7QUFDbkIxUSxRQUFBQSxDQUFDLENBQUNqQixZQUFGO0FBQ0g7QUFDSjtBQUNKLEdBaHhESTs7QUFpeERMOzs7QUFHQXNPLEVBQUFBLGdCQXB4REssOEJBb3hEYztBQUNmLFFBQUlyTixDQUFDLEdBQUcsSUFBUjtBQUNBQSxJQUFBQSxDQUFDLENBQUN1QixhQUFGLEdBQWtCLElBQWxCO0FBQ0EsUUFBSTJNLElBQUosRUFBVWdHLE1BQVY7QUFFQSxRQUFJbFUsQ0FBQyxDQUFDcEIsUUFBTixFQUNJb0IsQ0FBQyxDQUFDNEwsWUFBRjtBQUVKLFFBQUlDLElBQUosRUFBVUMsTUFBVixFQUFrQkMsT0FBbEIsRUFBMkJDLEtBQTNCO0FBQ0FILElBQUFBLElBQUksR0FBRzdMLENBQUMsQ0FBQ2lNLE9BQVQ7QUFDQUgsSUFBQUEsTUFBTSxHQUFHOUwsQ0FBQyxDQUFDbU0sU0FBWDtBQUNBSixJQUFBQSxPQUFPLEdBQUcvTCxDQUFDLENBQUNrTSxVQUFaO0FBQ0FGLElBQUFBLEtBQUssR0FBR2hNLENBQUMsQ0FBQ29NLFFBQVY7QUFFQSxRQUFJSSxRQUFRLEdBQUcsS0FBZjs7QUFDQSxTQUFLLElBQUl4SyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHaEMsQ0FBQyxDQUFDeUIsT0FBRixDQUFVOFAsYUFBZCxJQUErQixDQUFDL0UsUUFBaEQsRUFBMER4SyxDQUFDLElBQUloQyxDQUFDLENBQUNtRixXQUFqRSxFQUE4RTtBQUMxRStJLE1BQUFBLElBQUksR0FBRyxLQUFLdFAsUUFBTCxHQUFnQixLQUFLaUgsV0FBTCxDQUFpQjdELENBQWpCLENBQWhCLEdBQXNDLEtBQUtpTSxpQkFBTCxDQUF1QmpNLENBQXZCLENBQTdDO0FBQ0FrUyxNQUFBQSxNQUFNLEdBQUcsS0FBS3hLLFNBQUwsR0FBa0IsQ0FBQ3dFLElBQUksQ0FBQ3BCLEdBQUwsR0FBV29CLElBQUksQ0FBQ3JCLE1BQWpCLElBQTJCLENBQTdDLEdBQW1EcUgsTUFBTSxHQUFHLENBQUNoRyxJQUFJLENBQUN2QixJQUFMLEdBQVl1QixJQUFJLENBQUN4QixLQUFsQixJQUEyQixDQUFoRzs7QUFDQSxjQUFRLEtBQUtwRyxjQUFiO0FBQ0ksYUFBSyxDQUFMO0FBQU87QUFDSCxjQUFJNEgsSUFBSSxDQUFDeEIsS0FBTCxJQUFjVixLQUFsQixFQUF5QjtBQUNyQixpQkFBS3pLLGFBQUwsR0FBcUIyTSxJQUFJLENBQUNqQixFQUExQjtBQUNBLGdCQUFJakIsS0FBSyxHQUFHa0ksTUFBWixFQUNJLEtBQUszUyxhQUFMLElBQXNCLEtBQUs0RCxXQUEzQjtBQUNKcUgsWUFBQUEsUUFBUSxHQUFHLElBQVg7QUFDSDs7QUFDRDs7QUFDSixhQUFLLENBQUw7QUFBTztBQUNILGNBQUkwQixJQUFJLENBQUN2QixJQUFMLElBQWFiLE1BQWpCLEVBQXlCO0FBQ3JCLGlCQUFLdkssYUFBTCxHQUFxQjJNLElBQUksQ0FBQ2pCLEVBQTFCO0FBQ0EsZ0JBQUluQixNQUFNLEdBQUdvSSxNQUFiLEVBQ0ksS0FBSzNTLGFBQUwsSUFBc0IsS0FBSzRELFdBQTNCO0FBQ0pxSCxZQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNIOztBQUNEOztBQUNKLGFBQUssQ0FBTDtBQUFPO0FBQ0gsY0FBSTBCLElBQUksQ0FBQ3JCLE1BQUwsSUFBZWhCLElBQW5CLEVBQXlCO0FBQ3JCLGlCQUFLdEssYUFBTCxHQUFxQjJNLElBQUksQ0FBQ2pCLEVBQTFCO0FBQ0EsZ0JBQUlwQixJQUFJLEdBQUdxSSxNQUFYLEVBQ0ksS0FBSzNTLGFBQUwsSUFBc0IsS0FBSzRELFdBQTNCO0FBQ0pxSCxZQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNIOztBQUNEOztBQUNKLGFBQUssQ0FBTDtBQUFPO0FBQ0gsY0FBSTBCLElBQUksQ0FBQ3BCLEdBQUwsSUFBWWYsT0FBaEIsRUFBeUI7QUFDckIsaUJBQUt4SyxhQUFMLEdBQXFCMk0sSUFBSSxDQUFDakIsRUFBMUI7QUFDQSxnQkFBSWxCLE9BQU8sR0FBR21JLE1BQWQsRUFDSSxLQUFLM1MsYUFBTCxJQUFzQixLQUFLNEQsV0FBM0I7QUFDSnFILFlBQUFBLFFBQVEsR0FBRyxJQUFYO0FBQ0g7O0FBQ0Q7QUFoQ1I7QUFrQ0gsS0FwRGMsQ0FxRGY7OztBQUNBMEIsSUFBQUEsSUFBSSxHQUFHLEtBQUt0UCxRQUFMLEdBQWdCLEtBQUtpSCxXQUFMLENBQWlCLEtBQUt6RCxjQUFMLEdBQXNCLENBQXZDLENBQWhCLEdBQTRELEtBQUs2TCxpQkFBTCxDQUF1QixLQUFLblAsU0FBTCxHQUFpQixDQUF4QyxDQUFuRTs7QUFDQSxRQUFJb1AsSUFBSSxJQUFJQSxJQUFJLENBQUNqQixFQUFMLElBQVdqTixDQUFDLENBQUNsQixTQUFGLEdBQWMsQ0FBckMsRUFBd0M7QUFDcENvVixNQUFBQSxNQUFNLEdBQUdsVSxDQUFDLENBQUMwSixTQUFGLEdBQWUsQ0FBQ3dFLElBQUksQ0FBQ3BCLEdBQUwsR0FBV29CLElBQUksQ0FBQ3JCLE1BQWpCLElBQTJCLENBQTFDLEdBQWdEcUgsTUFBTSxHQUFHLENBQUNoRyxJQUFJLENBQUN2QixJQUFMLEdBQVl1QixJQUFJLENBQUN4QixLQUFsQixJQUEyQixDQUE3Rjs7QUFDQSxjQUFRMU0sQ0FBQyxDQUFDc0csY0FBVjtBQUNJLGFBQUssQ0FBTDtBQUFPO0FBQ0gsY0FBSXdGLE1BQU0sR0FBR29JLE1BQWIsRUFDSWxVLENBQUMsQ0FBQ3VCLGFBQUYsR0FBa0IyTSxJQUFJLENBQUNqQixFQUF2QjtBQUNKOztBQUNKLGFBQUssQ0FBTDtBQUFPO0FBQ0gsY0FBSWpCLEtBQUssR0FBR2tJLE1BQVosRUFDSWxVLENBQUMsQ0FBQ3VCLGFBQUYsR0FBa0IyTSxJQUFJLENBQUNqQixFQUF2QjtBQUNKOztBQUNKLGFBQUssQ0FBTDtBQUFPO0FBQ0gsY0FBSWxCLE9BQU8sR0FBR21JLE1BQWQsRUFDSWxVLENBQUMsQ0FBQ3VCLGFBQUYsR0FBa0IyTSxJQUFJLENBQUNqQixFQUF2QjtBQUNKOztBQUNKLGFBQUssQ0FBTDtBQUFPO0FBQ0gsY0FBSXBCLElBQUksR0FBR3FJLE1BQVgsRUFDSWxVLENBQUMsQ0FBQ3VCLGFBQUYsR0FBa0IyTSxJQUFJLENBQUNqQixFQUF2QjtBQUNKO0FBaEJSO0FBa0JILEtBM0VjLENBNEVmOztBQUNILEdBajJESTtBQWsyREw7QUFDQTBELEVBQUFBLE9BbjJESyxtQkFtMkRHRCxZQW4yREgsRUFtMkRpQjtBQUNsQjtBQUNBLFFBQUksQ0FBQyxLQUFLelAsV0FBTCxFQUFMLEVBQ0k7QUFDSixRQUFJeVAsWUFBWSxJQUFJLElBQXBCLEVBQ0lBLFlBQVksR0FBRyxFQUFmO0FBQ0osU0FBS3lELFFBQUwsQ0FBYyxLQUFLN1MsVUFBTCxHQUFrQixDQUFoQyxFQUFtQ29QLFlBQW5DO0FBQ0gsR0ExMkRJO0FBMjJETDtBQUNBRSxFQUFBQSxRQTUyREssb0JBNDJESUYsWUE1MkRKLEVBNDJEa0I7QUFDbkI7QUFDQSxRQUFJLENBQUMsS0FBS3pQLFdBQUwsRUFBTCxFQUNJO0FBQ0osUUFBSXlQLFlBQVksSUFBSSxJQUFwQixFQUNJQSxZQUFZLEdBQUcsRUFBZjtBQUNKLFNBQUt5RCxRQUFMLENBQWMsS0FBSzdTLFVBQUwsR0FBa0IsQ0FBaEMsRUFBbUNvUCxZQUFuQztBQUNILEdBbjNESTtBQW8zREw7QUFDQXlELEVBQUFBLFFBcjNESyxvQkFxM0RJQyxPQXIzREosRUFxM0RhMUQsWUFyM0RiLEVBcTNEMkI7QUFDNUIsUUFBSTFRLENBQUMsR0FBRyxJQUFSO0FBQ0EsUUFBSSxDQUFDQSxDQUFDLENBQUNpQixXQUFGLEVBQUwsRUFDSTtBQUNKLFFBQUlqQixDQUFDLENBQUNoQyxVQUFGLElBQWdCekIsU0FBUyxDQUFDa0MsSUFBOUIsRUFDSSxPQUFPcEMsRUFBRSxDQUFDNkUsS0FBSCxDQUFTLG1FQUFULENBQVA7QUFDSixRQUFJa1QsT0FBTyxHQUFHLENBQVYsSUFBZUEsT0FBTyxJQUFJcFUsQ0FBQyxDQUFDbEIsU0FBaEMsRUFDSTtBQUNKLFFBQUlrQixDQUFDLENBQUNzQixVQUFGLElBQWdCOFMsT0FBcEIsRUFDSSxPQVR3QixDQVU1Qjs7QUFDQXBVLElBQUFBLENBQUMsQ0FBQ3NCLFVBQUYsR0FBZThTLE9BQWY7O0FBQ0EsUUFBSXBVLENBQUMsQ0FBQ3RCLGVBQU4sRUFBdUI7QUFDbkJyQyxNQUFBQSxFQUFFLENBQUNPLFNBQUgsQ0FBYStCLFlBQWIsQ0FBMEI0QixVQUExQixDQUFxQyxDQUFDUCxDQUFDLENBQUN0QixlQUFILENBQXJDLEVBQTBEMFYsT0FBMUQ7QUFDSDs7QUFDRHBVLElBQUFBLENBQUMsQ0FBQ2tRLFFBQUYsQ0FBV2tFLE9BQVgsRUFBb0IxRCxZQUFwQjtBQUNILEdBcjRESTtBQXM0REw7QUFDQTJELEVBQUFBLGNBdjRESywwQkF1NERVclQsUUF2NERWLEVBdTREb0I7QUFDckIsUUFBSWhCLENBQUMsR0FBRyxJQUFSO0FBQ0EsUUFBSSxDQUFDQSxDQUFDLENBQUNpQixXQUFGLEVBQUwsRUFDSTtBQUNKLFFBQUksQ0FBQ2pCLENBQUMsQ0FBQ3dDLFFBQVAsRUFDSSxPQUFPbkcsRUFBRSxDQUFDNkUsS0FBSCxDQUFTLHNCQUFULENBQVA7QUFDSixRQUFJLENBQUNsQixDQUFDLENBQUNSLFdBQVAsRUFDSSxPQUFPbkQsRUFBRSxDQUFDNkUsS0FBSCxDQUFTLHFCQUFULENBQVA7QUFDSmxCLElBQUFBLENBQUMsQ0FBQ2dLLFdBQUYsR0FBZ0IsRUFBaEI7QUFDQSxRQUFJc0ssSUFBSSxHQUFHalksRUFBRSxDQUFDb0osV0FBSCxDQUFlekYsQ0FBQyxDQUFDd0MsUUFBakIsQ0FBWDtBQUNBeEMsSUFBQUEsQ0FBQyxDQUFDeUIsT0FBRixDQUFVMFAsUUFBVixDQUFtQm1ELElBQW5COztBQUNBLFNBQUssSUFBSXRTLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdoQixRQUFwQixFQUE4QmdCLENBQUMsRUFBL0IsRUFBbUM7QUFDL0IzRixNQUFBQSxFQUFFLENBQUNPLFNBQUgsQ0FBYStCLFlBQWIsQ0FBMEI0QixVQUExQixDQUFxQyxDQUFDUCxDQUFDLENBQUNSLFdBQUgsQ0FBckMsRUFBc0Q4VSxJQUF0RCxFQUE0RHRTLENBQTVEOztBQUNBLFVBQUlzUyxJQUFJLENBQUNuTCxNQUFMLElBQWVuSixDQUFDLENBQUNnSixTQUFGLENBQVlHLE1BQTNCLElBQXFDbUwsSUFBSSxDQUFDcEwsS0FBTCxJQUFjbEosQ0FBQyxDQUFDZ0osU0FBRixDQUFZRSxLQUFuRSxFQUEwRTtBQUN0RWxKLFFBQUFBLENBQUMsQ0FBQ2dLLFdBQUYsQ0FBY2hJLENBQWQsSUFBbUJoQyxDQUFDLENBQUMwSixTQUFGLEdBQWM0SyxJQUFJLENBQUNuTCxNQUFuQixHQUE0Qm1MLElBQUksQ0FBQ3BMLEtBQXBEO0FBQ0g7QUFDSjs7QUFDRCxRQUFJLENBQUNxTCxNQUFNLENBQUNDLElBQVAsQ0FBWXhVLENBQUMsQ0FBQ2dLLFdBQWQsRUFBMkI0QyxNQUFoQyxFQUNJNU0sQ0FBQyxDQUFDZ0ssV0FBRixHQUFnQixJQUFoQjtBQUNKc0ssSUFBQUEsSUFBSSxDQUFDck4sZ0JBQUw7QUFDQSxRQUFJcU4sSUFBSSxDQUFDNVIsT0FBVCxFQUNJNFIsSUFBSSxDQUFDNVIsT0FBTDtBQUNKLFdBQU8xQyxDQUFDLENBQUNnSyxXQUFUO0FBQ0g7QUE5NURJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICogQGF1dGhvciBrTCA8a2xrMEBxcS5jb20+XHJcbiAqIEBkYXRlIDIwMTkvMS81XHJcbiAqIEBkb2Mg5YiX6KGo57uE5Lu2LlxyXG4gKiBAZW5kXHJcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbmNvbnN0IFRlbXBsYXRlVHlwZSA9IGNjLkVudW0oe1xyXG4gICAgJ05PREUnOiAxLFxyXG4gICAgJ1BSRUZBQic6IDIsXHJcbn0pO1xyXG5jb25zdCBTbGlkZVR5cGUgPSBjYy5FbnVtKHtcclxuICAgICdOT1JNQUwnOiAxLCAvL+aZrumAmlxyXG4gICAgJ0FESEVSSU5HJzogMiwgLy/nspjpmYTmqKHlvI/vvIzlsIblvLrliLblhbPpl63mu5rliqjmg6/mgKdcclxuICAgICdQQUdFJzogMywgICAvL+mhtemdouaooeW8j++8jOWwhuW8uuWItuWFs+mXrea7muWKqOaDr+aAp1xyXG59KTtcclxuY29uc3QgU2VsZWN0ZWRUeXBlID0gY2MuRW51bSh7XHJcbiAgICAnTk9ORSc6IDAsXHJcbiAgICAnU0lOR0xFJzogMSwgLy/ljZXpgIlcclxuICAgICdNVUxUJzogMiwgLy/lpJrpgIlcclxufSk7XHJcblxyXG5jb25zdCBMaXN0SXRlbSA9IHJlcXVpcmUoJ0xpc3RJdGVtJyk7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgZWRpdG9yOiB7XHJcbiAgICAgICAgZGlzYWxsb3dNdWx0aXBsZTogZmFsc2UsXHJcbiAgICAgICAgbWVudTogJ+iHquWumuS5iee7hOS7ti9MaXN0JyxcclxuICAgICAgICByZXF1aXJlQ29tcG9uZW50OiBjYy5TY3JvbGxWaWV3LFxyXG4gICAgICAgIC8v6ISa5pys55Sf5ZG95ZGo5pyf5Zue6LCD55qE5omn6KGM5LyY5YWI57qn44CC5bCP5LqOIDAg55qE6ISa5pys5bCG5LyY5YWI5omn6KGM77yM5aSn5LqOIDAg55qE6ISa5pys5bCG5pyA5ZCO5omn6KGM44CC6K+l5LyY5YWI57qn5Y+q5a+5IG9uTG9hZCwgb25FbmFibGUsIHN0YXJ0LCB1cGRhdGUg5ZKMIGxhdGVVcGRhdGUg5pyJ5pWI77yM5a+5IG9uRGlzYWJsZSDlkowgb25EZXN0cm95IOaXoOaViOOAglxyXG4gICAgICAgIGV4ZWN1dGlvbk9yZGVyOiAtNTAwMCxcclxuICAgIH0sXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHRlbXBsYXRlVHlwZToge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBUZW1wbGF0ZVR5cGUuTk9ERSxcclxuICAgICAgICAgICAgdHlwZTogVGVtcGxhdGVUeXBlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdG1wTm9kZToge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICB0b29sdGlwOiBDQ19ERVYgJiYgJ0l0ZW3mqKHniYjvvIx0eXBlOmNjLk5vZGUnLFxyXG4gICAgICAgICAgICB2aXNpYmxlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgYm9vbCA9IHRoaXMudGVtcGxhdGVUeXBlID09IFRlbXBsYXRlVHlwZS5OT0RFO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFib29sKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudG1wTm9kZSA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYm9vbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdG1wUHJlZmFiOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICdJdGVt5qih54mI77yMdHlwZTpjYy5QcmVmYWInLFxyXG4gICAgICAgICAgICB2aXNpYmxlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgYm9vbCA9IHRoaXMudGVtcGxhdGVUeXBlID09IFRlbXBsYXRlVHlwZS5QUkVGQUI7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWJvb2wpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50bXBQcmVmYWIgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGJvb2w7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIF9zbGlkZU1vZGU6IDEsXHJcbiAgICAgICAgc2xpZGVNb2RlOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IFNsaWRlVHlwZSxcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICfmu5HliqjmqKHlvI8nLFxyXG4gICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zbGlkZU1vZGU7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNldDogZnVuY3Rpb24gKHZhbCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbCAhPSBudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NsaWRlTW9kZSA9IHZhbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcGFnZURpc3RhbmNlOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IC4zLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5GbG9hdCxcclxuICAgICAgICAgICAgcmFuZ2U6IFswLCAxLCAuMV0sXHJcbiAgICAgICAgICAgIHRvb2x0aXA6IENDX0RFViAmJiAn57+76aG15L2c55So6Led56a7JyxcclxuICAgICAgICAgICAgc2xpZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHZpc2libGU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zbGlkZU1vZGUgPT0gU2xpZGVUeXBlLlBBR0U7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICBwYWdlQ2hhbmdlRXZlbnQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuQ29tcG9uZW50LkV2ZW50SGFuZGxlcixcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICfpobXpnaLmlLnlj5jkuovku7YnLFxyXG4gICAgICAgICAgICB2aXNpYmxlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgYm9vbCA9IHRoaXMuX3NsaWRlTW9kZSA9PSBTbGlkZVR5cGUuUEFHRTtcclxuICAgICAgICAgICAgICAgIGlmICghYm9vbClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBhZ2VDaGFuZ2VFdmVudCA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYm9vbDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIF92aXJ0dWFsOiB0cnVlLFxyXG4gICAgICAgIHZpcnR1YWw6IHtcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICfmmK/lkKbkuLromZrmi5/liJfooajvvIjliqjmgIHliJfooajvvIknLFxyXG4gICAgICAgICAgICBnZXQoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fdmlydHVhbDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2V0KHZhbCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbCAhPSBudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3ZpcnR1YWwgPSB2YWw7XHJcbiAgICAgICAgICAgICAgICBpZiAoIUNDX0RFViAmJiB0aGlzLl9udW1JdGVtcyAhPSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb25TY3JvbGxpbmcoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY3ljbGljOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IGZhbHNlLFxyXG4gICAgICAgICAgICB0b29sdGlwOiBDQ19ERVYgJiYgJ+aYr+WQpuS4uuW+queOr+WIl+ihqCcsXHJcbiAgICAgICAgICAgIHZpc2libGU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGxldCB2YWwgPSB0aGlzLnZpcnR1YWwgJiYgdGhpcy5zbGlkZU1vZGUgPT0gU2xpZGVUeXBlLk5PUk1BTDtcclxuICAgICAgICAgICAgICAgIGlmICghdmFsKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3ljbGljID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbGFja0NlbnRlcjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBmYWxzZSxcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICdJdGVt5pWw6YeP5LiN6Laz5Lul5aGr5ruhQ29udGVudOaXtu+8jOaYr+WQpuWxheS4reaYvuekukl0ZW3vvIjkuI3mlK/mjIFHcmlk5biD5bGA77yJJyxcclxuICAgICAgICAgICAgdmlzaWJsZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMudmlydHVhbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbGFja1NsaWRlOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IGZhbHNlLFxyXG4gICAgICAgICAgICB0b29sdGlwOiBDQ19ERVYgJiYgJ0l0ZW3mlbDph4/kuI3otrPku6Xloavmu6FDb250ZW505pe277yM5piv5ZCm5Y+v5ruR5YqoJyxcclxuICAgICAgICAgICAgdmlzaWJsZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHZhbCA9IHRoaXMudmlydHVhbCAmJiAhdGhpcy5sYWNrQ2VudGVyO1xyXG4gICAgICAgICAgICAgICAgaWYgKCF2YWwpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sYWNrU2xpZGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB2YWw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIF91cGRhdGVSYXRlOiAwLFxyXG4gICAgICAgIHVwZGF0ZVJhdGU6IHtcclxuICAgICAgICAgICAgdHlwZTogY2MuSW50ZWdlcixcclxuICAgICAgICAgICAgcmFuZ2U6IFswLCA2LCAxXSxcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICfliLfmlrDpopHnjofvvIjlgLzotorlpKfliLfmlrDpopHnjofotorkvY7jgIHmgKfog73otorpq5jvvIknLFxyXG4gICAgICAgICAgICBzbGlkZTogdHJ1ZSxcclxuICAgICAgICAgICAgZ2V0KCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3VwZGF0ZVJhdGU7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNldCh2YWwpIHtcclxuICAgICAgICAgICAgICAgIGlmICh2YWwgPj0gMCAmJiB2YWwgPD0gNikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVJhdGUgPSB2YWw7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGZyYW1lQnlGcmFtZVJlbmRlck51bToge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5JbnRlZ2VyLFxyXG4gICAgICAgICAgICByYW5nZTogWzAsIDEyLCAxXSxcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICfpgJDluKfmuLLmn5Pml7bvvIzmr4/luKfmuLLmn5PnmoRJdGVt5pWw6YeP77yIPD0w5pe25YWz6Zet5YiG5bin5riy5p+T77yJJyxcclxuICAgICAgICAgICAgc2xpZGU6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICByZW5kZXJFdmVudDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Db21wb25lbnQuRXZlbnRIYW5kbGVyLFxyXG4gICAgICAgICAgICB0b29sdGlwOiBDQ19ERVYgJiYgJ+a4suafk+S6i+S7tu+8iOa4suafk+WZqO+8iScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzZWxlY3RlZE1vZGU6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogU2VsZWN0ZWRUeXBlLk5PTkUsXHJcbiAgICAgICAgICAgIHR5cGU6IFNlbGVjdGVkVHlwZSxcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICfpgInmi6nmqKHlvI8nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcmVwZWF0RXZlbnRTaW5nbGU6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogZmFsc2UsXHJcbiAgICAgICAgICAgIHRvb2x0aXA6IENDX0RFViAmJiAn5piv5ZCm6YeN5aSN5ZON5bqU5Y2V6YCJ5LqL5Lu2JyxcclxuICAgICAgICAgICAgdmlzaWJsZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2VsZWN0ZWRNb2RlID09IFNlbGVjdGVkVHlwZS5TSU5HTEU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHNlbGVjdGVkRXZlbnQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuQ29tcG9uZW50LkV2ZW50SGFuZGxlcixcclxuICAgICAgICAgICAgdG9vbHRpcDogQ0NfREVWICYmICfop6blj5HpgInmi6nkuovku7YnLFxyXG4gICAgICAgICAgICB2aXNpYmxlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgYm9vbCA9IHRoaXMuc2VsZWN0ZWRNb2RlID4gMDtcclxuICAgICAgICAgICAgICAgIGlmICghYm9vbClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdGVkRXZlbnQgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGJvb2w7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICBfc2VsZWN0ZWRJZDogLTEsXHJcbiAgICAgICAgc2VsZWN0ZWRJZDoge1xyXG4gICAgICAgICAgICB2aXNpYmxlOiBmYWxzZSxcclxuICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc2VsZWN0ZWRJZDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2V0OiBmdW5jdGlvbiAodmFsKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXRlbTtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAodC5zZWxlY3RlZE1vZGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFNlbGVjdGVkVHlwZS5TSU5HTEU6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF0LnJlcGVhdEV2ZW50U2luZ2xlICYmIHZhbCA9PSB0Ll9zZWxlY3RlZElkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtID0gdC5nZXRJdGVtQnlMaXN0SWQodmFsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKCFpdGVtICYmIHZhbCA+PSAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodC5fc2VsZWN0ZWRJZCA+PSAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fbGFzdFNlbGVjdGVkSWQgPSB0Ll9zZWxlY3RlZElkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIC8v5aaC5p6c77ycMOWImeWPlua2iOmAieaLqe+8jOaKil9sYXN0U2VsZWN0ZWRJZOS5n+e9ruepuuWQp++8jOWmguaenOS7peWQjuacieeJueauiumcgOaxguWGjeaUueWQp+OAglxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fbGFzdFNlbGVjdGVkSWQgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Ll9zZWxlY3RlZElkID0gdmFsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ubGlzdEl0ZW0uc2VsZWN0ZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodC5fbGFzdFNlbGVjdGVkSWQgPj0gMCAmJiB0Ll9sYXN0U2VsZWN0ZWRJZCAhPSB0Ll9zZWxlY3RlZElkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbGFzdEl0ZW0gPSB0LmdldEl0ZW1CeUxpc3RJZCh0Ll9sYXN0U2VsZWN0ZWRJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobGFzdEl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXN0SXRlbS5saXN0SXRlbS5zZWxlY3RlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0LnNlbGVjdGVkRXZlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIuZW1pdEV2ZW50cyhbdC5zZWxlY3RlZEV2ZW50XSwgaXRlbSwgdmFsICUgdGhpcy5fYWN0dWFsTnVtSXRlbXMsIHQuX2xhc3RTZWxlY3RlZElkICUgdGhpcy5fYWN0dWFsTnVtSXRlbXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFNlbGVjdGVkVHlwZS5NVUxUOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0gPSB0LmdldEl0ZW1CeUxpc3RJZCh2YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWl0ZW0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0Ll9zZWxlY3RlZElkID49IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0Ll9sYXN0U2VsZWN0ZWRJZCA9IHQuX3NlbGVjdGVkSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQuX3NlbGVjdGVkSWQgPSB2YWw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBib29sID0gIWl0ZW0ubGlzdEl0ZW0uc2VsZWN0ZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ubGlzdEl0ZW0uc2VsZWN0ZWQgPSBib29sO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3ViID0gdC5tdWx0U2VsZWN0ZWQuaW5kZXhPZih2YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYm9vbCAmJiBzdWIgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0Lm11bHRTZWxlY3RlZC5wdXNoKHZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoIWJvb2wgJiYgc3ViID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHQubXVsdFNlbGVjdGVkLnNwbGljZShzdWIsIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0LnNlbGVjdGVkRXZlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIuZW1pdEV2ZW50cyhbdC5zZWxlY3RlZEV2ZW50XSwgaXRlbSwgdmFsICUgdGhpcy5fYWN0dWFsTnVtSXRlbXMsIHQuX2xhc3RTZWxlY3RlZElkICUgdGhpcy5fYWN0dWFsTnVtSXRlbXMsIGJvb2wpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIF9udW1JdGVtczoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgICAgICBzZXJpYWxpemFibGU6IGZhbHNlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbnVtSXRlbXM6IHtcclxuICAgICAgICAgICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgIGdldCgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9hY3R1YWxOdW1JdGVtcztcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2V0KHZhbCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHQgPSB0aGlzO1xyXG4gICAgICAgICAgICAgICAgaWYgKCF0LmNoZWNrSW5pdGVkKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbCA9PSBudWxsIHx8IHZhbCA8IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcignbnVtSXRlbXMgc2V0IHRoZSB3cm9uZzo6JywgdmFsKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0Ll9hY3R1YWxOdW1JdGVtcyA9IHQuX251bUl0ZW1zID0gdmFsO1xyXG4gICAgICAgICAgICAgICAgdC5fZm9yY2VVcGRhdGUgPSB0cnVlO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0Ll92aXJ0dWFsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdC5fcmVzaXplQ29udGVudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0LmN5Y2xpYykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Ll9udW1JdGVtcyA9IHQuX2N5Y2xpY051bSAqIHQuX251bUl0ZW1zO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0Ll9vblNjcm9sbGluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdC5mcmFtZUJ5RnJhbWVSZW5kZXJOdW0gJiYgdC5zbGlkZU1vZGUgPT0gU2xpZGVUeXBlLlBBR0UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQuY3VyUGFnZU51bSA9IHQubmVhcmVzdExpc3RJZDtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxheW91dCA9IHQuY29udGVudC5nZXRDb21wb25lbnQoY2MuTGF5b3V0KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobGF5b3V0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxheW91dC5lbmFibGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdC5fZGVsUmVkdW5kYW50SXRlbSgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0LmZpcnN0TGlzdElkID0gMDtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodC5mcmFtZUJ5RnJhbWVSZW5kZXJOdW0gPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8v5YWI5riy5p+T5Yeg5Liq5Ye65p2lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBsZW4gPSB0LmZyYW1lQnlGcmFtZVJlbmRlck51bSA+IHQuX251bUl0ZW1zID8gdC5fbnVtSXRlbXMgOiB0LmZyYW1lQnlGcmFtZVJlbmRlck51bTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgbiA9IDA7IG4gPCBsZW47IG4rKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fY3JlYXRlT3JVcGRhdGVJdGVtMihuKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodC5mcmFtZUJ5RnJhbWVSZW5kZXJOdW0gPCB0Ll9udW1JdGVtcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fdXBkYXRlQ291bnRlciA9IHQuZnJhbWVCeUZyYW1lUmVuZGVyTnVtO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fdXBkYXRlRG9uZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgbiA9IDA7IG4gPCB2YWw7IG4rKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fY3JlYXRlT3JVcGRhdGVJdGVtMihuKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0LmRpc3BsYXlJdGVtTnVtID0gdmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICB0aGlzLl9pbml0KCk7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uRGVzdHJveSgpIHtcclxuICAgICAgICBpZiAodGhpcy5faXRlbVRtcCAmJiB0aGlzLl9pdGVtVG1wLmlzVmFsaWQpXHJcbiAgICAgICAgICAgIHRoaXMuX2l0ZW1UbXAuZGVzdHJveSgpO1xyXG4gICAgICAgIC8vIGxldCB0b3RhbCA9IHRoaXMuX3Bvb2wuc2l6ZSgpO1xyXG4gICAgICAgIHdoaWxlICh0aGlzLl9wb29sLnNpemUoKSkge1xyXG4gICAgICAgICAgICBsZXQgbm9kZSA9IHRoaXMuX3Bvb2wuZ2V0KCk7XHJcbiAgICAgICAgICAgIG5vZGUuZGVzdHJveSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBpZiAodG90YWwpXHJcbiAgICAgICAgLy8gICAgIGNjLmxvZygnLS0tLS0tLS0tLS0tLS0tLS0nICsgdGhpcy5ub2RlLm5hbWUgKyAnPExpc3Q+IGRlc3Ryb3kgbm9kZSB0b3RhbCBudW0uID0+JywgdG90YWwpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkVuYWJsZSgpIHtcclxuICAgICAgICAvLyBpZiAoIUNDX0VESVRPUilcclxuICAgICAgICB0aGlzLl9yZWdpc3RlckV2ZW50KCk7XHJcbiAgICAgICAgdGhpcy5faW5pdCgpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkRpc2FibGUoKSB7XHJcbiAgICAgICAgLy8gaWYgKCFDQ19FRElUT1IpXHJcbiAgICAgICAgdGhpcy5fdW5yZWdpc3RlckV2ZW50KCk7XHJcbiAgICB9LFxyXG4gICAgLy/ms6jlhozkuovku7ZcclxuICAgIF9yZWdpc3RlckV2ZW50KCkge1xyXG4gICAgICAgIGxldCB0ID0gdGhpcztcclxuICAgICAgICB0Lm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHQuX29uVG91Y2hTdGFydCwgdCwgdHJ1ZSk7XHJcbiAgICAgICAgdC5ub2RlLm9uKCd0b3VjaC11cCcsIHQuX29uVG91Y2hVcCwgdCwgdHJ1ZSk7XHJcbiAgICAgICAgdC5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdC5fb25Ub3VjaENhbmNlbGxlZCwgdCwgdHJ1ZSk7XHJcbiAgICAgICAgdC5ub2RlLm9uKCdzY3JvbGwtYmVnYW4nLCB0Ll9vblNjcm9sbEJlZ2FuLCB0LCB0cnVlKTtcclxuICAgICAgICB0Lm5vZGUub24oJ3Njcm9sbC1lbmRlZCcsIHQuX29uU2Nyb2xsRW5kZWQsIHQsIHRydWUpO1xyXG4gICAgICAgIHQubm9kZS5vbignc2Nyb2xsaW5nJywgdC5fb25TY3JvbGxpbmcsIHQsIHRydWUpO1xyXG4gICAgICAgIHQubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5TSVpFX0NIQU5HRUQsIHQuX29uU2l6ZUNoYW5nZWQsIHQpO1xyXG4gICAgfSxcclxuICAgIC8v5Y246L295LqL5Lu2XHJcbiAgICBfdW5yZWdpc3RlckV2ZW50KCkge1xyXG4gICAgICAgIGxldCB0ID0gdGhpcztcclxuICAgICAgICB0Lm5vZGUub2ZmKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0Ll9vblRvdWNoU3RhcnQsIHQsIHRydWUpO1xyXG4gICAgICAgIHQubm9kZS5vZmYoJ3RvdWNoLXVwJywgdC5fb25Ub3VjaFVwLCB0LCB0cnVlKTtcclxuICAgICAgICB0Lm5vZGUub2ZmKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdC5fb25Ub3VjaENhbmNlbGxlZCwgdCwgdHJ1ZSk7XHJcbiAgICAgICAgdC5ub2RlLm9mZignc2Nyb2xsLWJlZ2FuJywgdC5fb25TY3JvbGxCZWdhbiwgdCwgdHJ1ZSk7XHJcbiAgICAgICAgdC5ub2RlLm9mZignc2Nyb2xsLWVuZGVkJywgdC5fb25TY3JvbGxFbmRlZCwgdCwgdHJ1ZSk7XHJcbiAgICAgICAgdC5ub2RlLm9mZignc2Nyb2xsaW5nJywgdC5fb25TY3JvbGxpbmcsIHQsIHRydWUpO1xyXG4gICAgICAgIHQubm9kZS5vZmYoY2MuTm9kZS5FdmVudFR5cGUuU0laRV9DSEFOR0VELCB0Ll9vblNpemVDaGFuZ2VkLCB0KTtcclxuICAgIH0sXHJcbiAgICAvL+WIneWni+WMluWQhOenjS4uXHJcbiAgICBfaW5pdCgpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgaWYgKHQuX2luaXRlZClcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG5cclxuICAgICAgICB0Ll9zY3JvbGxWaWV3ID0gdC5ub2RlLmdldENvbXBvbmVudChjYy5TY3JvbGxWaWV3KTtcclxuXHJcbiAgICAgICAgdC5jb250ZW50ID0gdC5fc2Nyb2xsVmlldy5jb250ZW50O1xyXG4gICAgICAgIGlmICghdC5jb250ZW50KSB7XHJcbiAgICAgICAgICAgIGNjLmVycm9yKHQubm9kZS5uYW1lICsgXCIncyBjYy5TY3JvbGxWaWV3IHVuc2V0IGNvbnRlbnQhXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0Ll9sYXlvdXQgPSB0LmNvbnRlbnQuZ2V0Q29tcG9uZW50KGNjLkxheW91dCk7XHJcblxyXG4gICAgICAgIHQuX2FsaWduID0gdC5fbGF5b3V0LnR5cGU7IC8v5o6S5YiX5qih5byPXHJcbiAgICAgICAgdC5fcmVzaXplTW9kZSA9IHQuX2xheW91dC5yZXNpemVNb2RlOyAvL+iHqumAguW6lOaooeW8j1xyXG4gICAgICAgIHQuX3N0YXJ0QXhpcyA9IHQuX2xheW91dC5zdGFydEF4aXM7XHJcblxyXG4gICAgICAgIHQuX3RvcEdhcCA9IHQuX2xheW91dC5wYWRkaW5nVG9wOyAgICAgICAvL+mhtui+uei3nVxyXG4gICAgICAgIHQuX3JpZ2h0R2FwID0gdC5fbGF5b3V0LnBhZGRpbmdSaWdodDsgICAvL+WPs+i+uei3nVxyXG4gICAgICAgIHQuX2JvdHRvbUdhcCA9IHQuX2xheW91dC5wYWRkaW5nQm90dG9tOyAvL+W6lei+uei3nVxyXG4gICAgICAgIHQuX2xlZnRHYXAgPSB0Ll9sYXlvdXQucGFkZGluZ0xlZnQ7ICAgICAvL+W3pui+uei3nVxyXG5cclxuICAgICAgICB0Ll9jb2x1bW5HYXAgPSB0Ll9sYXlvdXQuc3BhY2luZ1g7ICAgICAgLy/liJfot51cclxuICAgICAgICB0Ll9saW5lR2FwID0gdC5fbGF5b3V0LnNwYWNpbmdZOyAgICAgICAgLy/ooYzot51cclxuXHJcbiAgICAgICAgdC5fY29sTGluZU51bTsgLy/liJfmlbDmiJbooYzmlbDvvIjpnZ5HUklE5qih5byP5YiZPTHvvIzooajnpLrljZXliJfmiJbljZXooYzvvIk7XHJcblxyXG4gICAgICAgIHQuX3ZlcnRpY2FsRGlyID0gdC5fbGF5b3V0LnZlcnRpY2FsRGlyZWN0aW9uOyAvL+WeguebtOaOkuWIl+WtkOiKgueCueeahOaWueWQkVxyXG4gICAgICAgIHQuX2hvcml6b250YWxEaXIgPSB0Ll9sYXlvdXQuaG9yaXpvbnRhbERpcmVjdGlvbjsgLy/msLTlubPmjpLliJflrZDoioLngrnnmoTmlrnlkJFcclxuXHJcbiAgICAgICAgdC5zZXRUZW1wbGF0ZUl0ZW0oY2MuaW5zdGFudGlhdGUodC50ZW1wbGF0ZVR5cGUgPT0gVGVtcGxhdGVUeXBlLlBSRUZBQiA/IHQudG1wUHJlZmFiIDogdC50bXBOb2RlKSk7XHJcblxyXG4gICAgICAgIGlmICh0Ll9zbGlkZU1vZGUgPT0gU2xpZGVUeXBlLkFESEVSSU5HIHx8IHQuX3NsaWRlTW9kZSA9PSBTbGlkZVR5cGUuUEFHRSkvL+eJueWumueahOa7keWKqOaooeW8j+mcgOimgeWFs+mXreaDr+aAp1xyXG4gICAgICAgICAgICB0Ll9zY3JvbGxWaWV3LmluZXJ0aWEgPSBmYWxzZTtcclxuICAgICAgICBpZiAoIXQudmlydHVhbCkgICAgICAgICAvLyBsYWNrQ2VudGVyIOS7heaUr+aMgSBWaXJ0dWFsIOaooeW8j1xyXG4gICAgICAgICAgICB0LmxhY2tDZW50ZXIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgdC5fbGFzdERpc3BsYXlEYXRhID0gW107Ly/mnIDlkI7kuIDmrKHliLfmlrDnmoTmlbDmja5cclxuICAgICAgICB0LmRpc3BsYXlEYXRhID0gW107ICAgICAvL+W9k+WJjeaVsOaNrlxyXG4gICAgICAgIHQuX3Bvb2wgPSBuZXcgY2MuTm9kZVBvb2woKTsgICAgLy/ov5nmmK/kuKrmsaDlrZAuLlxyXG4gICAgICAgIHQuX2ZvcmNlVXBkYXRlID0gZmFsc2U7IC8v5piv5ZCm5by65Yi25pu05pawXHJcbiAgICAgICAgdC5fdXBkYXRlQ291bnRlciA9IDA7ICAgLy/lvZPliY3liIbluKfmuLLmn5PluKfmlbBcclxuICAgICAgICB0Ll91cGRhdGVEb25lID0gdHJ1ZTsgICAvL+WIhuW4p+a4suafk+aYr+WQpuWujOaIkFxyXG5cclxuICAgICAgICB0LmN1clBhZ2VOdW0gPSAwOyAgIC8v5b2T5YmN6aG15pWwXHJcblxyXG4gICAgICAgIGlmICh0LmN5Y2xpYykgeyAvLyDlpoLmnpzmmK/lvqrnjq/liJfooajvvIzopoblhpnkuIDkuptjYy5TY3JvbGxWaWV355qE5Ye95pWwXHJcbiAgICAgICAgICAgIHQuX3Njcm9sbFZpZXcuX3Byb2Nlc3NBdXRvU2Nyb2xsaW5nID0gdGhpcy5fcHJvY2Vzc0F1dG9TY3JvbGxpbmcuYmluZCh0KTtcclxuICAgICAgICAgICAgdC5fc2Nyb2xsVmlldy5fc3RhcnRCb3VuY2VCYWNrSWZOZWVkZWQgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gdC5fc2Nyb2xsVmlldy5fc2Nyb2xsQ2hpbGRyZW4gPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIC8vICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHN3aXRjaCAodC5fYWxpZ24pIHtcclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5IT1JJWk9OVEFMOiB7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHQuX2hvcml6b250YWxEaXIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5Ib3Jpem9udGFsRGlyZWN0aW9uLkxFRlRfVE9fUklHSFQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQuX2FsaWduQ2FsY1R5cGUgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5Ib3Jpem9udGFsRGlyZWN0aW9uLlJJR0hUX1RPX0xFRlQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQuX2FsaWduQ2FsY1R5cGUgPSAyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlR5cGUuVkVSVElDQUw6IHtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAodC5fdmVydGljYWxEaXIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5WZXJ0aWNhbERpcmVjdGlvbi5UT1BfVE9fQk9UVE9NOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Ll9hbGlnbkNhbGNUeXBlID0gMztcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVmVydGljYWxEaXJlY3Rpb24uQk9UVE9NX1RPX1RPUDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgdC5fYWxpZ25DYWxjVHlwZSA9IDQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5HUklEOiB7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHQuX3N0YXJ0QXhpcykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LkF4aXNEaXJlY3Rpb24uSE9SSVpPTlRBTDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0Ll92ZXJ0aWNhbERpcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVmVydGljYWxEaXJlY3Rpb24uVE9QX1RPX0JPVFRPTTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0Ll9hbGlnbkNhbGNUeXBlID0gMztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlZlcnRpY2FsRGlyZWN0aW9uLkJPVFRPTV9UT19UT1A6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fYWxpZ25DYWxjVHlwZSA9IDQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuQXhpc0RpcmVjdGlvbi5WRVJUSUNBTDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0Ll9ob3Jpem9udGFsRGlyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5Ib3Jpem9udGFsRGlyZWN0aW9uLkxFRlRfVE9fUklHSFQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fYWxpZ25DYWxjVHlwZSA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5Ib3Jpem9udGFsRGlyZWN0aW9uLlJJR0hUX1RPX0xFRlQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5fYWxpZ25DYWxjVHlwZSA9IDI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmuIXnqbogY29udGVudFxyXG4gICAgICAgIHQuY29udGVudC5jaGlsZHJlbi5mb3JFYWNoKGNoaWxkID0+IHtcclxuICAgICAgICAgICAgY2hpbGQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICBpZiAoY2hpbGQuaXNWYWxpZClcclxuICAgICAgICAgICAgICAgIGNoaWxkLmRlc3Ryb3koKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0Ll9pbml0ZWQgPSB0cnVlO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5Li65LqG5a6e546w5b6q546v5YiX6KGo77yM5b+F6aG76KaG5YaZY2MuU2Nyb2xsVmlld+eahOafkOS6m+WHveaVsFxyXG4gICAgICogQHBhcmFtIHtOdW1iZXJ9IGR0XHJcbiAgICAgKi9cclxuICAgIF9wcm9jZXNzQXV0b1Njcm9sbGluZyhkdCkge1xyXG4gICAgICAgIC8vIGxldCBpc0F1dG9TY3JvbGxCcmFrZSA9IHRoaXMuX3Njcm9sbFZpZXcuX2lzTmVjZXNzYXJ5QXV0b1Njcm9sbEJyYWtlKCk7XHJcbiAgICAgICAgbGV0IGJyYWtpbmdGYWN0b3IgPSAxO1xyXG4gICAgICAgIHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxBY2N1bXVsYXRlZFRpbWUgKz0gZHQgKiAoMSAvIGJyYWtpbmdGYWN0b3IpO1xyXG5cclxuICAgICAgICBsZXQgcGVyY2VudGFnZSA9IE1hdGgubWluKDEsIHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxBY2N1bXVsYXRlZFRpbWUgLyB0aGlzLl9zY3JvbGxWaWV3Ll9hdXRvU2Nyb2xsVG90YWxUaW1lKTtcclxuICAgICAgICBpZiAodGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbEF0dGVudWF0ZSkge1xyXG4gICAgICAgICAgICBsZXQgdGltZSA9IHBlcmNlbnRhZ2UgLSAxO1xyXG4gICAgICAgICAgICBwZXJjZW50YWdlID0gdGltZSAqIHRpbWUgKiB0aW1lICogdGltZSAqIHRpbWUgKyAxO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG5ld1Bvc2l0aW9uID0gdGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbFN0YXJ0UG9zaXRpb24uYWRkKHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxUYXJnZXREZWx0YS5tdWwocGVyY2VudGFnZSkpO1xyXG4gICAgICAgIGxldCBFUFNJTE9OID0gdGhpcy5fc2Nyb2xsVmlldy5nZXRTY3JvbGxFbmRlZEV2ZW50VGltaW5nKCk7XHJcbiAgICAgICAgbGV0IHJlYWNoZWRFbmQgPSBNYXRoLmFicyhwZXJjZW50YWdlIC0gMSkgPD0gRVBTSUxPTjtcclxuICAgICAgICAvLyBjYy5sb2cocmVhY2hlZEVuZCwgTWF0aC5hYnMocGVyY2VudGFnZSAtIDEpLCBFUFNJTE9OKVxyXG5cclxuICAgICAgICBsZXQgZmlyZUV2ZW50ID0gTWF0aC5hYnMocGVyY2VudGFnZSAtIDEpIDw9IHRoaXMuX3Njcm9sbFZpZXcuZ2V0U2Nyb2xsRW5kZWRFdmVudFRpbWluZygpO1xyXG4gICAgICAgIGlmIChmaXJlRXZlbnQgJiYgIXRoaXMuX3Njcm9sbFZpZXcuX2lzU2Nyb2xsRW5kZWRXaXRoVGhyZXNob2xkRXZlbnRGaXJlZCkge1xyXG4gICAgICAgICAgICB0aGlzLl9zY3JvbGxWaWV3Ll9kaXNwYXRjaEV2ZW50KCdzY3JvbGwtZW5kZWQtd2l0aC10aHJlc2hvbGQnKTtcclxuICAgICAgICAgICAgdGhpcy5fc2Nyb2xsVmlldy5faXNTY3JvbGxFbmRlZFdpdGhUaHJlc2hvbGRFdmVudEZpcmVkID0gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIGlmICh0aGlzLl9zY3JvbGxWaWV3LmVsYXN0aWMgJiYgIXJlYWNoZWRFbmQpIHtcclxuICAgICAgICAvLyAgICAgbGV0IGJyYWtlT2Zmc2V0UG9zaXRpb24gPSBuZXdQb3NpdGlvbi5zdWIodGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbEJyYWtpbmdTdGFydFBvc2l0aW9uKTtcclxuICAgICAgICAvLyAgICAgaWYgKGlzQXV0b1Njcm9sbEJyYWtlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICBicmFrZU9mZnNldFBvc2l0aW9uID0gYnJha2VPZmZzZXRQb3NpdGlvbi5tdWwoYnJha2luZ0ZhY3Rvcik7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyAgICAgbmV3UG9zaXRpb24gPSB0aGlzLl9zY3JvbGxWaWV3Ll9hdXRvU2Nyb2xsQnJha2luZ1N0YXJ0UG9zaXRpb24uYWRkKGJyYWtlT2Zmc2V0UG9zaXRpb24pO1xyXG4gICAgICAgIC8vIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gICAgIGxldCBtb3ZlRGVsdGEgPSBuZXdQb3NpdGlvbi5zdWIodGhpcy5fc2Nyb2xsVmlldy5nZXRDb250ZW50UG9zaXRpb24oKSk7XHJcbiAgICAgICAgLy8gICAgIGxldCBvdXRPZkJvdW5kYXJ5ID0gdGhpcy5fc2Nyb2xsVmlldy5fZ2V0SG93TXVjaE91dE9mQm91bmRhcnkobW92ZURlbHRhKTtcclxuICAgICAgICAvLyAgICAgaWYgKCFvdXRPZkJvdW5kYXJ5LmZ1enp5RXF1YWxzKGNjLnYyKDAsIDApLCBFUFNJTE9OKSkge1xyXG4gICAgICAgIC8vICAgICAgICAgbmV3UG9zaXRpb24gPSBuZXdQb3NpdGlvbi5hZGQob3V0T2ZCb3VuZGFyeSk7XHJcbiAgICAgICAgLy8gICAgICAgICByZWFjaGVkRW5kID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgaWYgKHJlYWNoZWRFbmQpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbGluZyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGRlbHRhTW92ZSA9IG5ld1Bvc2l0aW9uLnN1Yih0aGlzLl9zY3JvbGxWaWV3LmdldENvbnRlbnRQb3NpdGlvbigpKTtcclxuICAgICAgICAvLyBjYy5sb2coZGVsdGFNb3ZlKVxyXG4gICAgICAgIHRoaXMuX3Njcm9sbFZpZXcuX21vdmVDb250ZW50KHRoaXMuX3Njcm9sbFZpZXcuX2NsYW1wRGVsdGEoZGVsdGFNb3ZlKSwgcmVhY2hlZEVuZCk7XHJcbiAgICAgICAgdGhpcy5fc2Nyb2xsVmlldy5fZGlzcGF0Y2hFdmVudCgnc2Nyb2xsaW5nJyk7XHJcblxyXG4gICAgICAgIC8vIHNjb2xsVG8gQVBJIGNvbnRyb2xsIG1vdmVcclxuICAgICAgICBpZiAoIXRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxpbmcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2Nyb2xsVmlldy5faXNCb3VuY2luZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9zY3JvbGxWaWV3Ll9zY3JvbGxpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5fc2Nyb2xsVmlldy5fZGlzcGF0Y2hFdmVudCgnc2Nyb2xsLWVuZGVkJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8v6K6+572u5qih5p2/SXRlbVxyXG4gICAgc2V0VGVtcGxhdGVJdGVtKGl0ZW0pIHtcclxuICAgICAgICBpZiAoIWl0ZW0pXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgdC5faXRlbVRtcCA9IGl0ZW07XHJcblxyXG4gICAgICAgIGlmICh0Ll9yZXNpemVNb2RlID09IGNjLkxheW91dC5SZXNpemVNb2RlLkNISUxEUkVOKVxyXG4gICAgICAgICAgICB0Ll9pdGVtU2l6ZSA9IHQuX2xheW91dC5jZWxsU2l6ZTtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIHQuX2l0ZW1TaXplID0gbmV3IGNjLnNpemUoaXRlbS53aWR0aCwgaXRlbS5oZWlnaHQpO1xyXG5cclxuICAgICAgICAvL+iOt+WPlkxpc3RJdGVt77yM5aaC5p6c5rKh5pyJ5bCx5Y+W5raI6YCJ5oup5qih5byPXHJcbiAgICAgICAgbGV0IGNvbSA9IGl0ZW0uZ2V0Q29tcG9uZW50KExpc3RJdGVtKTtcclxuICAgICAgICBsZXQgcmVtb3ZlID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKCFjb20pXHJcbiAgICAgICAgICAgIHJlbW92ZSA9IHRydWU7XHJcbiAgICAgICAgaWYgKGNvbSkge1xyXG4gICAgICAgICAgICBpZiAoIWNvbS5fYnRuQ29tICYmICFpdGVtLmdldENvbXBvbmVudChjYy5CdXR0b24pKSB7XHJcbiAgICAgICAgICAgICAgICByZW1vdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyZW1vdmUpIHtcclxuICAgICAgICAgICAgdC5zZWxlY3RlZE1vZGUgPSBTZWxlY3RlZFR5cGUuTk9ORTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29tID0gaXRlbS5nZXRDb21wb25lbnQoY2MuV2lkZ2V0KTtcclxuICAgICAgICBpZiAoY29tICYmIGNvbS5lbmFibGVkKSB7XHJcbiAgICAgICAgICAgIHQuX25lZWRVcGRhdGVXaWRnZXQgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodC5zZWxlY3RlZE1vZGUgPT0gU2VsZWN0ZWRUeXBlLk1VTFQpXHJcbiAgICAgICAgICAgIHQubXVsdFNlbGVjdGVkID0gW107XHJcblxyXG4gICAgICAgIHN3aXRjaCAodC5fYWxpZ24pIHtcclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5IT1JJWk9OVEFMOlxyXG4gICAgICAgICAgICAgICAgdC5fY29sTGluZU51bSA9IDE7XHJcbiAgICAgICAgICAgICAgICB0Ll9zaXplVHlwZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlR5cGUuVkVSVElDQUw6XHJcbiAgICAgICAgICAgICAgICB0Ll9jb2xMaW5lTnVtID0gMTtcclxuICAgICAgICAgICAgICAgIHQuX3NpemVUeXBlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLkxheW91dC5UeXBlLkdSSUQ6XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHQuX3N0YXJ0QXhpcykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LkF4aXNEaXJlY3Rpb24uSE9SSVpPTlRBTDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy/orqHnrpfliJfmlbBcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRyaW1XID0gdC5jb250ZW50LndpZHRoIC0gdC5fbGVmdEdhcCAtIHQuX3JpZ2h0R2FwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Ll9jb2xMaW5lTnVtID0gTWF0aC5mbG9vcigodHJpbVcgKyB0Ll9jb2x1bW5HYXApIC8gKHQuX2l0ZW1TaXplLndpZHRoICsgdC5fY29sdW1uR2FwKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQuX3NpemVUeXBlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuQXhpc0RpcmVjdGlvbi5WRVJUSUNBTDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy/orqHnrpfooYzmlbBcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRyaW1IID0gdC5jb250ZW50LmhlaWdodCAtIHQuX3RvcEdhcCAtIHQuX2JvdHRvbUdhcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdC5fY29sTGluZU51bSA9IE1hdGguZmxvb3IoKHRyaW1IICsgdC5fbGluZUdhcCkgLyAodC5faXRlbVNpemUuaGVpZ2h0ICsgdC5fbGluZUdhcCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Ll9zaXplVHlwZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOajgOafpeaYr+WQpuWIneWni+WMllxyXG4gICAgICogQHBhcmFtIHtCb29sZWFufSBwcmludExvZyDmmK/lkKbmiZPljbDplJnor6/kv6Hmga9cclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIGNoZWNrSW5pdGVkKHByaW50TG9nKSB7XHJcbiAgICAgICAgcHJpbnRMb2cgPSBwcmludExvZyA9PSBudWxsID8gdHJ1ZSA6IHByaW50TG9nO1xyXG4gICAgICAgIGlmICghdGhpcy5faW5pdGVkKSB7XHJcbiAgICAgICAgICAgIGlmIChwcmludExvZykge1xyXG4gICAgICAgICAgICAgICAgY2MuZXJyb3IoJ0xpc3QgaW5pdGlhbGl6YXRpb24gbm90IGNvbXBsZXRlZCEnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfSxcclxuICAgIC8v56aB55SoIExheW91dCDnu4Tku7bvvIzoh6rooYzorqHnrpcgQ29udGVudCBTaXplXHJcbiAgICBfcmVzaXplQ29udGVudCgpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgbGV0IHJlc3VsdDtcclxuICAgICAgICBzd2l0Y2ggKHQuX2FsaWduKSB7XHJcbiAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlR5cGUuSE9SSVpPTlRBTDoge1xyXG4gICAgICAgICAgICAgICAgaWYgKHQuX2N1c3RvbVNpemUpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZml4ZWQgPSB0Ll9nZXRGaXhlZFNpemUoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSB0Ll9sZWZ0R2FwICsgZml4ZWQudmFsICsgKHQuX2l0ZW1TaXplLndpZHRoICogKHQuX251bUl0ZW1zIC0gZml4ZWQuY291bnQpKSArICh0Ll9jb2x1bW5HYXAgKiAodC5fbnVtSXRlbXMgLSAxKSkgKyB0Ll9yaWdodEdhcDtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gdC5fbGVmdEdhcCArICh0Ll9pdGVtU2l6ZS53aWR0aCAqIHQuX251bUl0ZW1zKSArICh0Ll9jb2x1bW5HYXAgKiAodC5fbnVtSXRlbXMgLSAxKSkgKyB0Ll9yaWdodEdhcDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlR5cGUuVkVSVElDQUw6IHtcclxuICAgICAgICAgICAgICAgIGlmICh0Ll9jdXN0b21TaXplKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGZpeGVkID0gdC5fZ2V0Rml4ZWRTaXplKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gdC5fdG9wR2FwICsgZml4ZWQudmFsICsgKHQuX2l0ZW1TaXplLmhlaWdodCAqICh0Ll9udW1JdGVtcyAtIGZpeGVkLmNvdW50KSkgKyAodC5fbGluZUdhcCAqICh0Ll9udW1JdGVtcyAtIDEpKSArIHQuX2JvdHRvbUdhcDtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gdC5fdG9wR2FwICsgKHQuX2l0ZW1TaXplLmhlaWdodCAqIHQuX251bUl0ZW1zKSArICh0Ll9saW5lR2FwICogKHQuX251bUl0ZW1zIC0gMSkpICsgdC5fYm90dG9tR2FwO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5HUklEOiB7XHJcbiAgICAgICAgICAgICAgICAvL+e9keagvOaooeW8j+S4jeaUr+aMgeWxheS4rVxyXG4gICAgICAgICAgICAgICAgaWYgKHQubGFja0NlbnRlcilcclxuICAgICAgICAgICAgICAgICAgICB0LmxhY2tDZW50ZXIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAodC5fc3RhcnRBeGlzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuQXhpc0RpcmVjdGlvbi5IT1JJWk9OVEFMOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgbGluZU51bSA9IE1hdGguY2VpbCh0Ll9udW1JdGVtcyAvIHQuX2NvbExpbmVOdW0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSB0Ll90b3BHYXAgKyAodC5faXRlbVNpemUuaGVpZ2h0ICogbGluZU51bSkgKyAodC5fbGluZUdhcCAqIChsaW5lTnVtIC0gMSkpICsgdC5fYm90dG9tR2FwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5BeGlzRGlyZWN0aW9uLlZFUlRJQ0FMOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29sTnVtID0gTWF0aC5jZWlsKHQuX251bUl0ZW1zIC8gdC5fY29sTGluZU51bSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IHQuX2xlZnRHYXAgKyAodC5faXRlbVNpemUud2lkdGggKiBjb2xOdW0pICsgKHQuX2NvbHVtbkdhcCAqIChjb2xOdW0gLSAxKSkgKyB0Ll9yaWdodEdhcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGxheW91dCA9IHQuY29udGVudC5nZXRDb21wb25lbnQoY2MuTGF5b3V0KTtcclxuICAgICAgICBpZiAobGF5b3V0KVxyXG4gICAgICAgICAgICBsYXlvdXQuZW5hYmxlZCA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0Ll9hbGxJdGVtU2l6ZSA9IHJlc3VsdDtcclxuICAgICAgICB0Ll9hbGxJdGVtU2l6ZU5vRWRnZSA9IHQuX2FsbEl0ZW1TaXplIC0gKHQuX3NpemVUeXBlID8gKHQuX3RvcEdhcCArIHQuX2JvdHRvbUdhcCkgOiAodC5fbGVmdEdhcCArIHQuX3JpZ2h0R2FwKSk7XHJcblxyXG4gICAgICAgIGlmICh0LmN5Y2xpYykge1xyXG4gICAgICAgICAgICBsZXQgdG90YWxTaXplID0gKHQuX3NpemVUeXBlID8gdC5ub2RlLmhlaWdodCA6IHQubm9kZS53aWR0aCk7XHJcblxyXG4gICAgICAgICAgICB0Ll9jeWNsaWNQb3MxID0gMDtcclxuICAgICAgICAgICAgdG90YWxTaXplIC09IHQuX2N5Y2xpY1BvczE7XHJcbiAgICAgICAgICAgIHQuX2N5Y2xpY051bSA9IE1hdGguY2VpbCh0b3RhbFNpemUgLyB0Ll9hbGxJdGVtU2l6ZU5vRWRnZSkgKyAxO1xyXG4gICAgICAgICAgICBsZXQgc3BhY2luZyA9IHQuX3NpemVUeXBlID8gdC5fbGluZUdhcCA6IHQuX2NvbHVtbkdhcDtcclxuICAgICAgICAgICAgdC5fY3ljbGljUG9zMiA9IHQuX2N5Y2xpY1BvczEgKyB0Ll9hbGxJdGVtU2l6ZU5vRWRnZSArIHNwYWNpbmc7XHJcbiAgICAgICAgICAgIHQuX2N5Y2xpY0FsbEl0ZW1TaXplID0gdC5fYWxsSXRlbVNpemUgKyAodC5fYWxsSXRlbVNpemVOb0VkZ2UgKiAodC5fY3ljbGljTnVtIC0gMSkpICsgKHNwYWNpbmcgKiAodC5fY3ljbGljTnVtIC0gMSkpO1xyXG4gICAgICAgICAgICB0Ll9jeWNpbGNBbGxJdGVtU2l6ZU5vRWRnZSA9IHQuX2FsbEl0ZW1TaXplTm9FZGdlICogdC5fY3ljbGljTnVtO1xyXG4gICAgICAgICAgICB0Ll9jeWNpbGNBbGxJdGVtU2l6ZU5vRWRnZSArPSBzcGFjaW5nICogKHQuX2N5Y2xpY051bSAtIDEpO1xyXG4gICAgICAgICAgICAvLyBjYy5sb2coJ19jeWNsaWNOdW0gLT4nLCB0Ll9jeWNsaWNOdW0sIHQuX2FsbEl0ZW1TaXplTm9FZGdlLCB0Ll9hbGxJdGVtU2l6ZSwgdC5fY3ljbGljUG9zMSwgdC5fY3ljbGljUG9zMik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0Ll9sYWNrID0gIXQuY3ljbGljICYmIHQuX2FsbEl0ZW1TaXplIDwgKHQuX3NpemVUeXBlID8gdC5ub2RlLmhlaWdodCA6IHQubm9kZS53aWR0aCk7XHJcbiAgICAgICAgbGV0IHNsaWRlT2Zmc2V0ID0gKCghdC5fbGFjayB8fCAhdC5sYWNrQ2VudGVyKSAmJiB0LmxhY2tTbGlkZSkgPyAwIDogLjE7XHJcblxyXG4gICAgICAgIGxldCB0YXJnZXRXSCA9IHQuX2xhY2sgPyAoKHQuX3NpemVUeXBlID8gdC5ub2RlLmhlaWdodCA6IHQubm9kZS53aWR0aCkgLSBzbGlkZU9mZnNldCkgOiAodC5jeWNsaWMgPyB0Ll9jeWNsaWNBbGxJdGVtU2l6ZSA6IHQuX2FsbEl0ZW1TaXplKTtcclxuICAgICAgICBpZiAodGFyZ2V0V0ggPCAwKVxyXG4gICAgICAgICAgICB0YXJnZXRXSCA9IDA7XHJcblxyXG4gICAgICAgIGlmICh0Ll9zaXplVHlwZSkge1xyXG4gICAgICAgICAgICB0LmNvbnRlbnQuaGVpZ2h0ID0gdGFyZ2V0V0g7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdC5jb250ZW50LndpZHRoID0gdGFyZ2V0V0g7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGNjLmxvZygnX3Jlc2l6ZUNvbnRlbnQoKSAgbnVtSXRlbXMgPScsIHQuX251bUl0ZW1zLCAn77yMY29udGVudCA9JywgdC5jb250ZW50KTtcclxuICAgIH0sXHJcbiAgICAvL+a7muWKqOi/m+ihjOaXti4uLlxyXG4gICAgX29uU2Nyb2xsaW5nKGV2KSB7XHJcbiAgICAgICAgaWYgKHRoaXMuZnJhbWVDb3VudCA9PSBudWxsKVxyXG4gICAgICAgICAgICB0aGlzLmZyYW1lQ291bnQgPSB0aGlzLl91cGRhdGVSYXRlO1xyXG4gICAgICAgIGlmICghdGhpcy5fZm9yY2VVcGRhdGUgJiYgKGV2ICYmIGV2LnR5cGUgIT0gJ3Njcm9sbC1lbmRlZCcpICYmIHRoaXMuZnJhbWVDb3VudCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5mcmFtZUNvdW50LS07XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9IGVsc2VcclxuICAgICAgICAgICAgdGhpcy5mcmFtZUNvdW50ID0gdGhpcy5fdXBkYXRlUmF0ZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2FuaURlbFJ1bmluZylcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG5cclxuICAgICAgICAvL+W+queOr+WIl+ihqOWkhOeQhlxyXG4gICAgICAgIGlmICh0aGlzLmN5Y2xpYykge1xyXG4gICAgICAgICAgICBsZXQgc2Nyb2xsUG9zID0gdGhpcy5jb250ZW50LmdldFBvc2l0aW9uKCk7XHJcbiAgICAgICAgICAgIHNjcm9sbFBvcyA9IHRoaXMuX3NpemVUeXBlID8gc2Nyb2xsUG9zLnkgOiBzY3JvbGxQb3MueDtcclxuXHJcbiAgICAgICAgICAgIGxldCBhZGRWYWwgPSB0aGlzLl9hbGxJdGVtU2l6ZU5vRWRnZSArICh0aGlzLl9zaXplVHlwZSA/IHRoaXMuX2xpbmVHYXAgOiB0aGlzLl9jb2x1bW5HYXApO1xyXG4gICAgICAgICAgICBsZXQgYWRkID0gdGhpcy5fc2l6ZVR5cGUgPyBjYy52MigwLCBhZGRWYWwpIDogY2MudjIoYWRkVmFsLCAwKTtcclxuXHJcbiAgICAgICAgICAgIHN3aXRjaCAodGhpcy5fYWxpZ25DYWxjVHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iExFRlRfVE9fUklHSFTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iExFRlRfVE9fUklHSFTvvIlcclxuICAgICAgICAgICAgICAgICAgICBpZiAoc2Nyb2xsUG9zID4gLXRoaXMuX2N5Y2xpY1BvczEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb250ZW50LnggPSAtdGhpcy5fY3ljbGljUG9zMjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Njcm9sbFZpZXcuaXNBdXRvU2Nyb2xsaW5nKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxTdGFydFBvc2l0aW9uID0gdGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbFN0YXJ0UG9zaXRpb24uc3ViKGFkZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKHRoaXMuX2JlZ2FuUG9zKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICB0aGlzLl9iZWdhblBvcyArPSBhZGQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHNjcm9sbFBvcyA8IC10aGlzLl9jeWNsaWNQb3MyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29udGVudC54ID0gLXRoaXMuX2N5Y2xpY1BvczE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9zY3JvbGxWaWV3LmlzQXV0b1Njcm9sbGluZygpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zY3JvbGxWaWV3Ll9hdXRvU2Nyb2xsU3RhcnRQb3NpdGlvbiA9IHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxTdGFydFBvc2l0aW9uLmFkZChhZGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmICh0aGlzLl9iZWdhblBvcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgdGhpcy5fYmVnYW5Qb3MgLT0gYWRkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iFJJR0hUX1RPX0xFRlTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iFJJR0hUX1RPX0xFRlTvvIlcclxuICAgICAgICAgICAgICAgICAgICBpZiAoc2Nyb2xsUG9zIDwgdGhpcy5fY3ljbGljUG9zMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbnRlbnQueCA9IHRoaXMuX2N5Y2xpY1BvczI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9zY3JvbGxWaWV3LmlzQXV0b1Njcm9sbGluZygpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zY3JvbGxWaWV3Ll9hdXRvU2Nyb2xsU3RhcnRQb3NpdGlvbiA9IHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxTdGFydFBvc2l0aW9uLmFkZChhZGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChzY3JvbGxQb3MgPiB0aGlzLl9jeWNsaWNQb3MyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29udGVudC54ID0gdGhpcy5fY3ljbGljUG9zMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Njcm9sbFZpZXcuaXNBdXRvU2Nyb2xsaW5nKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxTdGFydFBvc2l0aW9uID0gdGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbFN0YXJ0UG9zaXRpb24uc3ViKGFkZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6Ly/ljZXliJdWRVJUSUNBTO+8iFRPUF9UT19CT1RUT03vvInjgIHnvZHmoLxIT1JJWk9OVEFM77yIVE9QX1RPX0JPVFRPTe+8iVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChzY3JvbGxQb3MgPCB0aGlzLl9jeWNsaWNQb3MxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29udGVudC55ID0gdGhpcy5fY3ljbGljUG9zMjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Njcm9sbFZpZXcuaXNBdXRvU2Nyb2xsaW5nKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxTdGFydFBvc2l0aW9uID0gdGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbFN0YXJ0UG9zaXRpb24uYWRkKGFkZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHNjcm9sbFBvcyA+IHRoaXMuX2N5Y2xpY1BvczIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb250ZW50LnkgPSB0aGlzLl9jeWNsaWNQb3MxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fc2Nyb2xsVmlldy5pc0F1dG9TY3JvbGxpbmcoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbFN0YXJ0UG9zaXRpb24gPSB0aGlzLl9zY3JvbGxWaWV3Ll9hdXRvU2Nyb2xsU3RhcnRQb3NpdGlvbi5zdWIoYWRkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNDovL+WNleWIl1ZFUlRJQ0FM77yIQk9UVE9NX1RPX1RPUO+8ieOAgee9keagvEhPUklaT05UQUzvvIhCT1RUT01fVE9fVE9Q77yJXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNjcm9sbFBvcyA+IC10aGlzLl9jeWNsaWNQb3MxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29udGVudC55ID0gLXRoaXMuX2N5Y2xpY1BvczI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9zY3JvbGxWaWV3LmlzQXV0b1Njcm9sbGluZygpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zY3JvbGxWaWV3Ll9hdXRvU2Nyb2xsU3RhcnRQb3NpdGlvbiA9IHRoaXMuX3Njcm9sbFZpZXcuX2F1dG9TY3JvbGxTdGFydFBvc2l0aW9uLnN1YihhZGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChzY3JvbGxQb3MgPCAtdGhpcy5fY3ljbGljUG9zMikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbnRlbnQueSA9IC10aGlzLl9jeWNsaWNQb3MxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fc2Nyb2xsVmlldy5pc0F1dG9TY3JvbGxpbmcoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2Nyb2xsVmlldy5fYXV0b1Njcm9sbFN0YXJ0UG9zaXRpb24gPSB0aGlzLl9zY3JvbGxWaWV3Ll9hdXRvU2Nyb2xsU3RhcnRQb3NpdGlvbi5hZGQoYWRkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fY2FsY1ZpZXdQb3MoKTtcclxuXHJcbiAgICAgICAgbGV0IHZUb3AsIHZSaWdodCwgdkJvdHRvbSwgdkxlZnQ7XHJcbiAgICAgICAgaWYgKHRoaXMuX3NpemVUeXBlKSB7XHJcbiAgICAgICAgICAgIHZUb3AgPSB0aGlzLnZpZXdUb3A7XHJcbiAgICAgICAgICAgIHZCb3R0b20gPSB0aGlzLnZpZXdCb3R0b207XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdlJpZ2h0ID0gdGhpcy52aWV3UmlnaHQ7XHJcbiAgICAgICAgICAgIHZMZWZ0ID0gdGhpcy52aWV3TGVmdDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl92aXJ0dWFsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGlzcGxheURhdGEgPSBbXTtcclxuICAgICAgICAgICAgbGV0IGl0ZW1Qb3M7XHJcblxyXG4gICAgICAgICAgICBsZXQgY3VySWQgPSAwO1xyXG4gICAgICAgICAgICBsZXQgZW5kSWQgPSB0aGlzLl9udW1JdGVtcyAtIDE7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fY3VzdG9tU2l6ZSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGJyZWFrRm9yID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAvL+WmguaenOivpWl0ZW3nmoTkvY3nva7lnKjlj6/op4bljLrln5/lhoXvvIzlsLHmjqjlhaVkaXNwbGF5RGF0YVxyXG4gICAgICAgICAgICAgICAgZm9yICg7IGN1cklkIDw9IGVuZElkICYmICFicmVha0ZvcjsgY3VySWQrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1Qb3MgPSB0aGlzLl9jYWxjSXRlbVBvcyhjdXJJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLl9hbGlnbikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5UeXBlLkhPUklaT05UQUw6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbVBvcy5yaWdodCA+PSB2TGVmdCAmJiBpdGVtUG9zLmxlZnQgPD0gdlJpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXNwbGF5RGF0YS5wdXNoKGl0ZW1Qb3MpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjdXJJZCAhPSAwICYmIHRoaXMuZGlzcGxheURhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrRm9yID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5UeXBlLlZFUlRJQ0FMOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW1Qb3MuYm90dG9tIDw9IHZUb3AgJiYgaXRlbVBvcy50b3AgPj0gdkJvdHRvbSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGlzcGxheURhdGEucHVzaChpdGVtUG9zKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY3VySWQgIT0gMCAmJiB0aGlzLmRpc3BsYXlEYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVha0ZvciA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5HUklEOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLl9zdGFydEF4aXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5BeGlzRGlyZWN0aW9uLkhPUklaT05UQUw6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpdGVtUG9zLmJvdHRvbSA8PSB2VG9wICYmIGl0ZW1Qb3MudG9wID49IHZCb3R0b20pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGlzcGxheURhdGEucHVzaChpdGVtUG9zKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjdXJJZCAhPSAwICYmIHRoaXMuZGlzcGxheURhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtGb3IgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LkF4aXNEaXJlY3Rpb24uVkVSVElDQUw6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpdGVtUG9zLnJpZ2h0ID49IHZMZWZ0ICYmIGl0ZW1Qb3MubGVmdCA8PSB2UmlnaHQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGlzcGxheURhdGEucHVzaChpdGVtUG9zKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjdXJJZCAhPSAwICYmIHRoaXMuZGlzcGxheURhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtGb3IgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbGV0IHd3ID0gdGhpcy5faXRlbVNpemUud2lkdGggKyB0aGlzLl9jb2x1bW5HYXA7XHJcbiAgICAgICAgICAgICAgICBsZXQgaGggPSB0aGlzLl9pdGVtU2l6ZS5oZWlnaHQgKyB0aGlzLl9saW5lR2FwO1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLl9hbGlnbkNhbGNUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iExFRlRfVE9fUklHSFTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iExFRlRfVE9fUklHSFTvvIlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VySWQgPSAodkxlZnQgKyB0aGlzLl9sZWZ0R2FwKSAvIHd3O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbmRJZCA9ICh2UmlnaHQgKyB0aGlzLl9yaWdodEdhcCkgLyB3dztcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iFJJR0hUX1RPX0xFRlTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iFJJR0hUX1RPX0xFRlTvvIlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VySWQgPSAoLXZSaWdodCAtIHRoaXMuX3JpZ2h0R2FwKSAvIHd3O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbmRJZCA9ICgtdkxlZnQgLSB0aGlzLl9sZWZ0R2FwKSAvIHd3O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDM6Ly/ljZXliJdWRVJUSUNBTO+8iFRPUF9UT19CT1RUT03vvInjgIHnvZHmoLxIT1JJWk9OVEFM77yIVE9QX1RPX0JPVFRPTe+8iVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJJZCA9ICgtdlRvcCAtIHRoaXMuX3RvcEdhcCkgLyBoaDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW5kSWQgPSAoLXZCb3R0b20gLSB0aGlzLl9ib3R0b21HYXApIC8gaGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgNDovL+WNleWIl1ZFUlRJQ0FM77yIQk9UVE9NX1RPX1RPUO+8ieOAgee9keagvEhPUklaT05UQUzvvIhCT1RUT01fVE9fVE9Q77yJXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cklkID0gKHZCb3R0b20gKyB0aGlzLl9ib3R0b21HYXApIC8gaGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVuZElkID0gKHZUb3AgKyB0aGlzLl90b3BHYXApIC8gaGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY3VySWQgPSBNYXRoLmZsb29yKGN1cklkKSAqIHRoaXMuX2NvbExpbmVOdW07XHJcbiAgICAgICAgICAgICAgICBlbmRJZCA9IE1hdGguY2VpbChlbmRJZCkgKiB0aGlzLl9jb2xMaW5lTnVtO1xyXG4gICAgICAgICAgICAgICAgZW5kSWQtLTtcclxuICAgICAgICAgICAgICAgIGlmIChjdXJJZCA8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgY3VySWQgPSAwO1xyXG4gICAgICAgICAgICAgICAgaWYgKGVuZElkID49IHRoaXMuX251bUl0ZW1zKVxyXG4gICAgICAgICAgICAgICAgICAgIGVuZElkID0gdGhpcy5fbnVtSXRlbXMgLSAxO1xyXG4gICAgICAgICAgICAgICAgLy8gY2MubG9nKGN1cklkLCBlbmRJZCk7XHJcbiAgICAgICAgICAgICAgICBmb3IgKDsgY3VySWQgPD0gZW5kSWQ7IGN1cklkKyspIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmRpc3BsYXlEYXRhLnB1c2godGhpcy5fY2FsY0l0ZW1Qb3MoY3VySWQpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5kaXNwbGF5RGF0YS5sZW5ndGggPD0gMCB8fCAhdGhpcy5fbnVtSXRlbXMpIHsgLy9pZiBub25lLCBkZWxldGUgYWxsLlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGFzdERpc3BsYXlEYXRhID0gW107XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kZWxSZWR1bmRhbnRJdGVtKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5maXJzdExpc3RJZCA9IHRoaXMuZGlzcGxheURhdGFbMF0uaWQ7XHJcbiAgICAgICAgICAgIHRoaXMuZGlzcGxheUl0ZW1OdW0gPSB0aGlzLmRpc3BsYXlEYXRhLmxlbmd0aDtcclxuICAgICAgICAgICAgbGV0IGxlbiA9IHRoaXMuX2xhc3REaXNwbGF5RGF0YS5sZW5ndGg7XHJcbiAgICAgICAgICAgIC8v5Yik5pat5pWw5o2u5piv5ZCm5LiO5b2T5YmN55u45ZCM77yM5aaC5p6c55u45ZCM77yMcmV0dXJu44CCXHJcbiAgICAgICAgICAgIC8v5ZugTGlzdOeahOaYvuekuuaVsOaNruaYr+acieW6j+eahO+8jOaJgOS7peWPqumcgOimgeWIpOaWreaVsOe7hOmVv+W6puaYr+WQpuebuOetie+8jOS7peWPiuWktOOAgeWwvuS4pOS4quWFg+e0oOaYr+WQpuebuOetieWNs+WPr+OAglxyXG4gICAgICAgICAgICBpZiAodGhpcy5fZm9yY2VVcGRhdGUgfHxcclxuICAgICAgICAgICAgICAgIHRoaXMuZGlzcGxheUl0ZW1OdW0gIT0gbGVuIHx8XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZpcnN0TGlzdElkICE9IHRoaXMuX2xhc3REaXNwbGF5RGF0YVswXSB8fFxyXG4gICAgICAgICAgICAgICAgdGhpcy5kaXNwbGF5RGF0YVt0aGlzLmRpc3BsYXlJdGVtTnVtIC0gMV0uaWQgIT0gdGhpcy5fbGFzdERpc3BsYXlEYXRhW2xlbiAtIDFdXHJcbiAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGFzdERpc3BsYXlEYXRhID0gW107XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5mcmFtZUJ5RnJhbWVSZW5kZXJOdW0gPiAwKSB7IC8v6YCQ5bin5riy5p+TXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX251bUl0ZW1zID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuX3VwZGF0ZURvbmUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbmVBZnRlclVwZGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVDb3VudGVyID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVEb25lID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGVsUmVkdW5kYW50SXRlbSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVDb3VudGVyID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlRG9uZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNjLmxvZygnTGlzdCBEaXNwbGF5IERhdGEgSTo6JywgdGhpcy5kaXNwbGF5RGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgeyAvL+ebtOaOpea4suafk1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNjLmxvZygnTGlzdCBEaXNwbGF5IERhdGEgSUk6OicsIHRoaXMuZGlzcGxheURhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGMgPSAwOyBjIDwgdGhpcy5kaXNwbGF5SXRlbU51bTsgYysrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2NyZWF0ZU9yVXBkYXRlSXRlbSh0aGlzLmRpc3BsYXlEYXRhW2NdKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGVsUmVkdW5kYW50SXRlbSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZvcmNlVXBkYXRlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5fY2FsY05lYXJlc3RJdGVtKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8v6K6h566XVmlld+S9jee9rlxyXG4gICAgX2NhbGNWaWV3UG9zKCkge1xyXG4gICAgICAgIGxldCBzY3JvbGxQb3MgPSB0aGlzLmNvbnRlbnQuZ2V0UG9zaXRpb24oKTtcclxuICAgICAgICBzd2l0Y2ggKHRoaXMuX2FsaWduQ2FsY1R5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAxOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iExFRlRfVE9fUklHSFTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iExFRlRfVE9fUklHSFTvvIlcclxuICAgICAgICAgICAgICAgIHRoaXMuZWxhc3RpY0xlZnQgPSBzY3JvbGxQb3MueCA+IDAgPyBzY3JvbGxQb3MueCA6IDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnZpZXdMZWZ0ID0gKHNjcm9sbFBvcy54IDwgMCA/IC1zY3JvbGxQb3MueCA6IDApIC0gdGhpcy5lbGFzdGljTGVmdDtcclxuICAgICAgICAgICAgICAgIHRoaXMudmlld1JpZ2h0ID0gdGhpcy52aWV3TGVmdCArIHRoaXMubm9kZS53aWR0aDtcclxuICAgICAgICAgICAgICAgIHRoaXMuZWxhc3RpY1JpZ2h0ID0gdGhpcy52aWV3UmlnaHQgPiB0aGlzLmNvbnRlbnQud2lkdGggPyBNYXRoLmFicyh0aGlzLnZpZXdSaWdodCAtIHRoaXMuY29udGVudC53aWR0aCkgOiAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3UmlnaHQgKz0gdGhpcy5lbGFzdGljUmlnaHQ7XHJcbiAgICAgICAgICAgICAgICAvLyBjYy5sb2codGhpcy5lbGFzdGljTGVmdCwgdGhpcy5lbGFzdGljUmlnaHQsIHRoaXMudmlld0xlZnQsIHRoaXMudmlld1JpZ2h0KTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIDI6Ly/ljZXooYxIT1JJWk9OVEFM77yIUklHSFRfVE9fTEVGVO+8ieOAgee9keagvFZFUlRJQ0FM77yIUklHSFRfVE9fTEVGVO+8iVxyXG4gICAgICAgICAgICAgICAgdGhpcy5lbGFzdGljUmlnaHQgPSBzY3JvbGxQb3MueCA8IDAgPyAtc2Nyb2xsUG9zLnggOiAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3UmlnaHQgPSAoc2Nyb2xsUG9zLnggPiAwID8gLXNjcm9sbFBvcy54IDogMCkgKyB0aGlzLmVsYXN0aWNSaWdodDtcclxuICAgICAgICAgICAgICAgIHRoaXMudmlld0xlZnQgPSB0aGlzLnZpZXdSaWdodCAtIHRoaXMubm9kZS53aWR0aDtcclxuICAgICAgICAgICAgICAgIHRoaXMuZWxhc3RpY0xlZnQgPSB0aGlzLnZpZXdMZWZ0IDwgLXRoaXMuY29udGVudC53aWR0aCA/IE1hdGguYWJzKHRoaXMudmlld0xlZnQgKyB0aGlzLmNvbnRlbnQud2lkdGgpIDogMDtcclxuICAgICAgICAgICAgICAgIHRoaXMudmlld0xlZnQgLT0gdGhpcy5lbGFzdGljTGVmdDtcclxuICAgICAgICAgICAgICAgIC8vIGNjLmxvZyh0aGlzLmVsYXN0aWNMZWZ0LCB0aGlzLmVsYXN0aWNSaWdodCwgdGhpcy52aWV3TGVmdCwgdGhpcy52aWV3UmlnaHQpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgMzovL+WNleWIl1ZFUlRJQ0FM77yIVE9QX1RPX0JPVFRPTe+8ieOAgee9keagvEhPUklaT05UQUzvvIhUT1BfVE9fQk9UVE9N77yJXHJcbiAgICAgICAgICAgICAgICB0aGlzLmVsYXN0aWNUb3AgPSBzY3JvbGxQb3MueSA8IDAgPyBNYXRoLmFicyhzY3JvbGxQb3MueSkgOiAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3VG9wID0gKHNjcm9sbFBvcy55ID4gMCA/IC1zY3JvbGxQb3MueSA6IDApICsgdGhpcy5lbGFzdGljVG9wO1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3Qm90dG9tID0gdGhpcy52aWV3VG9wIC0gdGhpcy5ub2RlLmhlaWdodDtcclxuICAgICAgICAgICAgICAgIHRoaXMuZWxhc3RpY0JvdHRvbSA9IHRoaXMudmlld0JvdHRvbSA8IC10aGlzLmNvbnRlbnQuaGVpZ2h0ID8gTWF0aC5hYnModGhpcy52aWV3Qm90dG9tICsgdGhpcy5jb250ZW50LmhlaWdodCkgOiAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3Qm90dG9tICs9IHRoaXMuZWxhc3RpY0JvdHRvbTtcclxuICAgICAgICAgICAgICAgIC8vIGNjLmxvZyh0aGlzLmVsYXN0aWNUb3AsIHRoaXMuZWxhc3RpY0JvdHRvbSwgdGhpcy52aWV3VG9wLCB0aGlzLnZpZXdCb3R0b20pO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgNDovL+WNleWIl1ZFUlRJQ0FM77yIQk9UVE9NX1RPX1RPUO+8ieOAgee9keagvEhPUklaT05UQUzvvIhCT1RUT01fVE9fVE9Q77yJXHJcbiAgICAgICAgICAgICAgICB0aGlzLmVsYXN0aWNCb3R0b20gPSBzY3JvbGxQb3MueSA+IDAgPyBNYXRoLmFicyhzY3JvbGxQb3MueSkgOiAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3Qm90dG9tID0gKHNjcm9sbFBvcy55IDwgMCA/IC1zY3JvbGxQb3MueSA6IDApIC0gdGhpcy5lbGFzdGljQm90dG9tO1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3VG9wID0gdGhpcy52aWV3Qm90dG9tICsgdGhpcy5ub2RlLmhlaWdodDtcclxuICAgICAgICAgICAgICAgIHRoaXMuZWxhc3RpY1RvcCA9IHRoaXMudmlld1RvcCA+IHRoaXMuY29udGVudC5oZWlnaHQgPyBNYXRoLmFicyh0aGlzLnZpZXdUb3AgLSB0aGlzLmNvbnRlbnQuaGVpZ2h0KSA6IDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnZpZXdUb3AgLT0gdGhpcy5lbGFzdGljVG9wO1xyXG4gICAgICAgICAgICAgICAgLy8gY2MubG9nKHRoaXMuZWxhc3RpY1RvcCwgdGhpcy5lbGFzdGljQm90dG9tLCB0aGlzLnZpZXdUb3AsIHRoaXMudmlld0JvdHRvbSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy/orqHnrpfkvY3nva4g5qC55o2uaWRcclxuICAgIF9jYWxjSXRlbVBvcyhpZCkge1xyXG4gICAgICAgIGxldCB3aWR0aCwgaGVpZ2h0LCB0b3AsIGJvdHRvbSwgbGVmdCwgcmlnaHQsIGl0ZW1YLCBpdGVtWTtcclxuICAgICAgICBzd2l0Y2ggKHRoaXMuX2FsaWduKSB7XHJcbiAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlR5cGUuSE9SSVpPTlRBTDpcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAodGhpcy5faG9yaXpvbnRhbERpcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0Lkhvcml6b250YWxEaXJlY3Rpb24uTEVGVF9UT19SSUdIVDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fY3VzdG9tU2l6ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGZpeGVkID0gdGhpcy5fZ2V0Rml4ZWRTaXplKGlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQgPSB0aGlzLl9sZWZ0R2FwICsgKCh0aGlzLl9pdGVtU2l6ZS53aWR0aCArIHRoaXMuX2NvbHVtbkdhcCkgKiAoaWQgLSBmaXhlZC5jb3VudCkpICsgKGZpeGVkLnZhbCArICh0aGlzLl9jb2x1bW5HYXAgKiBmaXhlZC5jb3VudCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNzID0gdGhpcy5fY3VzdG9tU2l6ZVtpZF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aCA9IChjcyA+IDAgPyBjcyA6IHRoaXMuX2l0ZW1TaXplLndpZHRoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQgPSB0aGlzLl9sZWZ0R2FwICsgKCh0aGlzLl9pdGVtU2l6ZS53aWR0aCArIHRoaXMuX2NvbHVtbkdhcCkgKiBpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aCA9IHRoaXMuX2l0ZW1TaXplLndpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0ID0gbGVmdCArIHdpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5sYWNrQ2VudGVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgb2Zmc2V0ID0gKHRoaXMuY29udGVudC53aWR0aCAvIDIpIC0gKHRoaXMuX2FsbEl0ZW1TaXplTm9FZGdlIC8gMik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0ICs9IG9mZnNldDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0ICs9IG9mZnNldDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVmdDogbGVmdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0OiByaWdodCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHg6IGxlZnQgKyAodGhpcy5faXRlbVRtcC5hbmNob3JYICogd2lkdGgpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogdGhpcy5faXRlbVRtcC55LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5Ib3Jpem9udGFsRGlyZWN0aW9uLlJJR0hUX1RPX0xFRlQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2N1c3RvbVNpemUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBmaXhlZCA9IHRoaXMuX2dldEZpeGVkU2l6ZShpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodCA9IC10aGlzLl9yaWdodEdhcCAtICgodGhpcy5faXRlbVNpemUud2lkdGggKyB0aGlzLl9jb2x1bW5HYXApICogKGlkIC0gZml4ZWQuY291bnQpKSAtIChmaXhlZC52YWwgKyAodGhpcy5fY29sdW1uR2FwICogZml4ZWQuY291bnQpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjcyA9IHRoaXMuX2N1c3RvbVNpemVbaWRdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGggPSAoY3MgPiAwID8gY3MgOiB0aGlzLl9pdGVtU2l6ZS53aWR0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodCA9IC10aGlzLl9yaWdodEdhcCAtICgodGhpcy5faXRlbVNpemUud2lkdGggKyB0aGlzLl9jb2x1bW5HYXApICogaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGggPSB0aGlzLl9pdGVtU2l6ZS53aWR0aDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0ID0gcmlnaHQgLSB3aWR0aDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubGFja0NlbnRlcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG9mZnNldCA9ICh0aGlzLmNvbnRlbnQud2lkdGggLyAyKSAtICh0aGlzLl9hbGxJdGVtU2l6ZU5vRWRnZSAvIDIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVmdCAtPSBvZmZzZXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodCAtPSBvZmZzZXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBpZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0OiByaWdodCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IGxlZnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB4OiBsZWZ0ICsgKHRoaXMuX2l0ZW1UbXAuYW5jaG9yWCAqIHdpZHRoKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHk6IHRoaXMuX2l0ZW1UbXAueSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVHlwZS5WRVJUSUNBTDoge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLl92ZXJ0aWNhbERpcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlZlcnRpY2FsRGlyZWN0aW9uLlRPUF9UT19CT1RUT006IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2N1c3RvbVNpemUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBmaXhlZCA9IHRoaXMuX2dldEZpeGVkU2l6ZShpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3AgPSAtdGhpcy5fdG9wR2FwIC0gKCh0aGlzLl9pdGVtU2l6ZS5oZWlnaHQgKyB0aGlzLl9saW5lR2FwKSAqIChpZCAtIGZpeGVkLmNvdW50KSkgLSAoZml4ZWQudmFsICsgKHRoaXMuX2xpbmVHYXAgKiBmaXhlZC5jb3VudCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNzID0gdGhpcy5fY3VzdG9tU2l6ZVtpZF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQgPSAoY3MgPiAwID8gY3MgOiB0aGlzLl9pdGVtU2l6ZS5oZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tID0gdG9wIC0gaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wID0gLXRoaXMuX3RvcEdhcCAtICgodGhpcy5faXRlbVNpemUuaGVpZ2h0ICsgdGhpcy5fbGluZUdhcCkgKiBpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQgPSB0aGlzLl9pdGVtU2l6ZS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tID0gdG9wIC0gaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5sYWNrQ2VudGVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgb2Zmc2V0ID0gKHRoaXMuY29udGVudC5oZWlnaHQgLyAyKSAtICh0aGlzLl9hbGxJdGVtU2l6ZU5vRWRnZSAvIDIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wIC09IG9mZnNldDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbSAtPSBvZmZzZXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2MubG9nKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIGlkOiBpZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIHRvcDogdG9wLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgYm90dG9tOiBib3R0b20sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICB4OiB0aGlzLl9pdGVtVG1wLngsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICB5OiBib3R0b20gKyAodGhpcy5faXRlbVRtcC5hbmNob3JZICogaGVpZ2h0KSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IHRvcCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbTogYm90dG9tLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeDogdGhpcy5faXRlbVRtcC54LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogYm90dG9tICsgKHRoaXMuX2l0ZW1UbXAuYW5jaG9yWSAqIGhlaWdodCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LlZlcnRpY2FsRGlyZWN0aW9uLkJPVFRPTV9UT19UT1A6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2N1c3RvbVNpemUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBmaXhlZCA9IHRoaXMuX2dldEZpeGVkU2l6ZShpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b20gPSB0aGlzLl9ib3R0b21HYXAgKyAoKHRoaXMuX2l0ZW1TaXplLmhlaWdodCArIHRoaXMuX2xpbmVHYXApICogKGlkIC0gZml4ZWQuY291bnQpKSArIChmaXhlZC52YWwgKyAodGhpcy5fbGluZUdhcCAqIGZpeGVkLmNvdW50KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY3MgPSB0aGlzLl9jdXN0b21TaXplW2lkXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodCA9IChjcyA+IDAgPyBjcyA6IHRoaXMuX2l0ZW1TaXplLmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b20gPSB0aGlzLl9ib3R0b21HYXAgKyAoKHRoaXMuX2l0ZW1TaXplLmhlaWdodCArIHRoaXMuX2xpbmVHYXApICogaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0ID0gdGhpcy5faXRlbVNpemUuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvcCA9IGJvdHRvbSArIGhlaWdodDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubGFja0NlbnRlcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG9mZnNldCA9ICh0aGlzLmNvbnRlbnQuaGVpZ2h0IC8gMikgLSAodGhpcy5fYWxsSXRlbVNpemVOb0VkZ2UgLyAyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcCArPSBvZmZzZXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b20gKz0gb2Zmc2V0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IHRvcCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbTogYm90dG9tLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeDogdGhpcy5faXRlbVRtcC54LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogYm90dG9tICsgKHRoaXMuX2l0ZW1UbXAuYW5jaG9yWSAqIGhlaWdodCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXNlIGNjLkxheW91dC5UeXBlLkdSSUQ6IHtcclxuICAgICAgICAgICAgICAgIGxldCBjb2xMaW5lID0gTWF0aC5mbG9vcihpZCAvIHRoaXMuX2NvbExpbmVOdW0pO1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLl9zdGFydEF4aXMpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5BeGlzRGlyZWN0aW9uLkhPUklaT05UQUw6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLl92ZXJ0aWNhbERpcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuVmVydGljYWxEaXJlY3Rpb24uVE9QX1RPX0JPVFRPTToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcCA9IC10aGlzLl90b3BHYXAgLSAoKHRoaXMuX2l0ZW1TaXplLmhlaWdodCArIHRoaXMuX2xpbmVHYXApICogY29sTGluZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tID0gdG9wIC0gdGhpcy5faXRlbVNpemUuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1ZID0gYm90dG9tICsgKHRoaXMuX2l0ZW1UbXAuYW5jaG9yWSAqIHRoaXMuX2l0ZW1TaXplLmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5WZXJ0aWNhbERpcmVjdGlvbi5CT1RUT01fVE9fVE9QOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tID0gdGhpcy5fYm90dG9tR2FwICsgKCh0aGlzLl9pdGVtU2l6ZS5oZWlnaHQgKyB0aGlzLl9saW5lR2FwKSAqIGNvbExpbmUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcCA9IGJvdHRvbSArIHRoaXMuX2l0ZW1TaXplLmhlaWdodDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtWSA9IGJvdHRvbSArICh0aGlzLl9pdGVtVG1wLmFuY2hvclkgKiB0aGlzLl9pdGVtU2l6ZS5oZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1YID0gdGhpcy5fbGVmdEdhcCArICgoaWQgJSB0aGlzLl9jb2xMaW5lTnVtKSAqICh0aGlzLl9pdGVtU2l6ZS53aWR0aCArIHRoaXMuX2NvbHVtbkdhcCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHRoaXMuX2hvcml6b250YWxEaXIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0Lkhvcml6b250YWxEaXJlY3Rpb24uTEVGVF9UT19SSUdIVDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1YICs9ICh0aGlzLl9pdGVtVG1wLmFuY2hvclggKiB0aGlzLl9pdGVtU2l6ZS53aWR0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbVggLT0gKHRoaXMuY29udGVudC5hbmNob3JYICogdGhpcy5jb250ZW50LndpZHRoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0Lkhvcml6b250YWxEaXJlY3Rpb24uUklHSFRfVE9fTEVGVDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1YICs9ICgoMSAtIHRoaXMuX2l0ZW1UbXAuYW5jaG9yWCkgKiB0aGlzLl9pdGVtU2l6ZS53aWR0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbVggLT0gKCgxIC0gdGhpcy5jb250ZW50LmFuY2hvclgpICogdGhpcy5jb250ZW50LndpZHRoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtWCAqPSAtMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiB0b3AsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b206IGJvdHRvbSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHg6IGl0ZW1YLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogaXRlbVksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuTGF5b3V0LkF4aXNEaXJlY3Rpb24uVkVSVElDQUw6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0aGlzLl9ob3Jpem9udGFsRGlyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5Ib3Jpem9udGFsRGlyZWN0aW9uLkxFRlRfVE9fUklHSFQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0ID0gdGhpcy5fbGVmdEdhcCArICgodGhpcy5faXRlbVNpemUud2lkdGggKyB0aGlzLl9jb2x1bW5HYXApICogY29sTGluZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQgPSBsZWZ0ICsgdGhpcy5faXRlbVNpemUud2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbVggPSBsZWZ0ICsgKHRoaXMuX2l0ZW1UbXAuYW5jaG9yWCAqIHRoaXMuX2l0ZW1TaXplLndpZHRoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtWCAtPSAodGhpcy5jb250ZW50LmFuY2hvclggKiB0aGlzLmNvbnRlbnQud2lkdGgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5MYXlvdXQuSG9yaXpvbnRhbERpcmVjdGlvbi5SSUdIVF9UT19MRUZUOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQgPSAtdGhpcy5fcmlnaHRHYXAgLSAoKHRoaXMuX2l0ZW1TaXplLndpZHRoICsgdGhpcy5fY29sdW1uR2FwKSAqIGNvbExpbmUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQgPSByaWdodCAtIHRoaXMuX2l0ZW1TaXplLndpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1YID0gbGVmdCArICh0aGlzLl9pdGVtVG1wLmFuY2hvclggKiB0aGlzLl9pdGVtU2l6ZS53aWR0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbVggKz0gKCgxIC0gdGhpcy5jb250ZW50LmFuY2hvclgpICogdGhpcy5jb250ZW50LndpZHRoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtWSA9IC10aGlzLl90b3BHYXAgLSAoKGlkICUgdGhpcy5fY29sTGluZU51bSkgKiAodGhpcy5faXRlbVNpemUuaGVpZ2h0ICsgdGhpcy5fbGluZUdhcCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHRoaXMuX3ZlcnRpY2FsRGlyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5WZXJ0aWNhbERpcmVjdGlvbi5UT1BfVE9fQk9UVE9NOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbVkgLT0gKCgxIC0gdGhpcy5faXRlbVRtcC5hbmNob3JZKSAqIHRoaXMuX2l0ZW1TaXplLmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbVkgKz0gKCgxIC0gdGhpcy5jb250ZW50LmFuY2hvclkpICogdGhpcy5jb250ZW50LmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLkxheW91dC5WZXJ0aWNhbERpcmVjdGlvbi5CT1RUT01fVE9fVE9QOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbVkgLT0gKCh0aGlzLl9pdGVtVG1wLmFuY2hvclkpICogdGhpcy5faXRlbVNpemUuaGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtWSArPSAodGhpcy5jb250ZW50LmFuY2hvclkgKiB0aGlzLmNvbnRlbnQuaGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtWSAqPSAtMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVmdDogbGVmdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0OiByaWdodCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHg6IGl0ZW1YLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogaXRlbVksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy/orqHnrpflt7LlrZjlnKjnmoRJdGVt55qE5L2N572uXHJcbiAgICBfY2FsY0V4aXN0SXRlbVBvcyhpZCkge1xyXG4gICAgICAgIGxldCBpdGVtID0gdGhpcy5nZXRJdGVtQnlMaXN0SWQoaWQpO1xyXG4gICAgICAgIGlmICghaXRlbSlcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgbGV0IGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGlkOiBpZCxcclxuICAgICAgICAgICAgeDogaXRlbS54LFxyXG4gICAgICAgICAgICB5OiBpdGVtLnksXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl9zaXplVHlwZSkge1xyXG4gICAgICAgICAgICBkYXRhLnRvcCA9IGl0ZW0ueSArIChpdGVtLmhlaWdodCAqICgxIC0gaXRlbS5hbmNob3JZKSk7XHJcbiAgICAgICAgICAgIGRhdGEuYm90dG9tID0gaXRlbS55IC0gKGl0ZW0uaGVpZ2h0ICogaXRlbS5hbmNob3JZKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBkYXRhLmxlZnQgPSBpdGVtLnggLSAoaXRlbS53aWR0aCAqIGl0ZW0uYW5jaG9yWCk7XHJcbiAgICAgICAgICAgIGRhdGEucmlnaHQgPSBpdGVtLnggKyAoaXRlbS53aWR0aCAqICgxIC0gaXRlbS5hbmNob3JYKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBkYXRhO1xyXG4gICAgfSxcclxuICAgIC8v6I635Y+WSXRlbeS9jee9rlxyXG4gICAgZ2V0SXRlbVBvcyhpZCkge1xyXG4gICAgICAgIGlmICh0aGlzLl92aXJ0dWFsKVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FsY0l0ZW1Qb3MoaWQpO1xyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5mcmFtZUJ5RnJhbWVSZW5kZXJOdW0pXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FsY0l0ZW1Qb3MoaWQpO1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fY2FsY0V4aXN0SXRlbVBvcyhpZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8v6I635Y+W5Zu65a6a5bC65a+4XHJcbiAgICBfZ2V0Rml4ZWRTaXplKGxpc3RJZCkge1xyXG4gICAgICAgIGlmICghdGhpcy5fY3VzdG9tU2l6ZSlcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgaWYgKGxpc3RJZCA9PSBudWxsKVxyXG4gICAgICAgICAgICBsaXN0SWQgPSB0aGlzLl9udW1JdGVtcztcclxuICAgICAgICBsZXQgZml4ZWQgPSAwO1xyXG4gICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgZm9yIChsZXQgaWQgaW4gdGhpcy5fY3VzdG9tU2l6ZSkge1xyXG4gICAgICAgICAgICBpZiAocGFyc2VJbnQoaWQpIDwgbGlzdElkKSB7XHJcbiAgICAgICAgICAgICAgICBmaXhlZCArPSB0aGlzLl9jdXN0b21TaXplW2lkXTtcclxuICAgICAgICAgICAgICAgIGNvdW50Kys7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgdmFsOiBmaXhlZCxcclxuICAgICAgICAgICAgY291bnQ6IGNvdW50LFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvL+a7muWKqOW8gOWni+aXti4uXHJcbiAgICBfb25TY3JvbGxCZWdhbigpIHtcclxuICAgICAgICB0aGlzLl9iZWdhblBvcyA9IHRoaXMuX3NpemVUeXBlID8gdGhpcy52aWV3VG9wIDogdGhpcy52aWV3TGVmdDtcclxuICAgIH0sXHJcbiAgICAvL+a7muWKqOe7k+adn+aXti4uXHJcbiAgICBfb25TY3JvbGxFbmRlZCgpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgaWYgKHQuc2Nyb2xsVG9MaXN0SWQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBsZXQgaXRlbSA9IHQuZ2V0SXRlbUJ5TGlzdElkKHQuc2Nyb2xsVG9MaXN0SWQpO1xyXG4gICAgICAgICAgICB0LnNjcm9sbFRvTGlzdElkID0gbnVsbDtcclxuICAgICAgICAgICAgaWYgKGl0ZW0pIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0ucnVuQWN0aW9uKG5ldyBjYy5zZXF1ZW5jZShcclxuICAgICAgICAgICAgICAgICAgICBuZXcgY2Muc2NhbGVUbyguMSwgMS4wNiksXHJcbiAgICAgICAgICAgICAgICAgICAgbmV3IGNjLnNjYWxlVG8oLjEsIDEpLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vbmV3IGNjLmNhbGxGdW5jKGZ1bmN0aW9uIChydW5Ob2RlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIH0pXHJcbiAgICAgICAgICAgICAgICApKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0Ll9vblNjcm9sbGluZygpO1xyXG5cclxuICAgICAgICBpZiAodC5fc2xpZGVNb2RlID09IFNsaWRlVHlwZS5BREhFUklORyAmJlxyXG4gICAgICAgICAgICAhdC5hZGhlcmluZ1xyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICAvL2NjLmxvZyh0LmFkaGVyaW5nLCB0Ll9zY3JvbGxWaWV3LmlzQXV0b1Njcm9sbGluZygpLCB0Ll9zY3JvbGxWaWV3LmlzU2Nyb2xsaW5nKCkpO1xyXG4gICAgICAgICAgICB0LmFkaGVyZSgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodC5fc2xpZGVNb2RlID09IFNsaWRlVHlwZS5QQUdFKSB7XHJcbiAgICAgICAgICAgIGlmICh0Ll9iZWdhblBvcyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wYWdlQWRoZXJlKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0LmFkaGVyZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8vIOinpuaRuOaXtlxyXG4gICAgX29uVG91Y2hTdGFydChldiwgY2FwdHVyZUxpc3RlbmVycykge1xyXG4gICAgICAgIGlmICh0aGlzLl9zY3JvbGxWaWV3Ll9oYXNOZXN0ZWRWaWV3R3JvdXAoZXYsIGNhcHR1cmVMaXN0ZW5lcnMpKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgbGV0IGlzTWUgPSBldi5ldmVudFBoYXNlID09PSBjYy5FdmVudC5BVF9UQVJHRVQgJiYgZXYudGFyZ2V0ID09PSB0aGlzLm5vZGU7XHJcbiAgICAgICAgaWYgKCFpc01lKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtTm9kZSA9IGV2LnRhcmdldDtcclxuICAgICAgICAgICAgd2hpbGUgKGl0ZW1Ob2RlLl9saXN0SWQgPT0gbnVsbCAmJiBpdGVtTm9kZS5wYXJlbnQpXHJcbiAgICAgICAgICAgICAgICBpdGVtTm9kZSA9IGl0ZW1Ob2RlLnBhcmVudDtcclxuICAgICAgICAgICAgdGhpcy5fc2Nyb2xsSXRlbSA9IGl0ZW1Ob2RlLl9saXN0SWQgIT0gbnVsbCA/IGl0ZW1Ob2RlIDogZXYudGFyZ2V0OztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy/op6bmkbjmiqzotbfml7YuLlxyXG4gICAgX29uVG91Y2hVcCgpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgdC5fc2Nyb2xsUG9zID0gbnVsbDtcclxuICAgICAgICBpZiAodC5fc2xpZGVNb2RlID09IFNsaWRlVHlwZS5BREhFUklORykge1xyXG4gICAgICAgICAgICBpZiAodC5hZGhlcmluZylcclxuICAgICAgICAgICAgICAgIHQuX2FkaGVyaW5nQmFycmllciA9IHRydWU7XHJcbiAgICAgICAgICAgIHQuYWRoZXJlKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0Ll9zbGlkZU1vZGUgPT0gU2xpZGVUeXBlLlBBR0UpIHtcclxuICAgICAgICAgICAgaWYgKHQuX2JlZ2FuUG9zICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIHQuX3BhZ2VBZGhlcmUoKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHQuYWRoZXJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2Nyb2xsSXRlbSA9IG51bGw7XHJcbiAgICB9LFxyXG5cclxuICAgIF9vblRvdWNoQ2FuY2VsbGVkKGV2LCBjYXB0dXJlTGlzdGVuZXJzKSB7XHJcbiAgICAgICAgbGV0IHQgPSB0aGlzO1xyXG4gICAgICAgIGlmICh0Ll9zY3JvbGxWaWV3Ll9oYXNOZXN0ZWRWaWV3R3JvdXAoZXYsIGNhcHR1cmVMaXN0ZW5lcnMpIHx8IGV2LnNpbXVsYXRlKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcblxyXG4gICAgICAgIHQuX3Njcm9sbFBvcyA9IG51bGw7XHJcbiAgICAgICAgaWYgKHQuX3NsaWRlTW9kZSA9PSBTbGlkZVR5cGUuQURIRVJJTkcpIHtcclxuICAgICAgICAgICAgaWYgKHQuYWRoZXJpbmcpXHJcbiAgICAgICAgICAgICAgICB0Ll9hZGhlcmluZ0JhcnJpZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICB0LmFkaGVyZSgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodC5fc2xpZGVNb2RlID09IFNsaWRlVHlwZS5QQUdFKSB7XHJcbiAgICAgICAgICAgIGlmICh0Ll9iZWdhblBvcyAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICB0Ll9wYWdlQWRoZXJlKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0LmFkaGVyZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3Njcm9sbEl0ZW0gPSBudWxsO1xyXG4gICAgfSxcclxuICAgIC8v5b2T5bC65a+45pS55Y+YXHJcbiAgICBfb25TaXplQ2hhbmdlZCgpIHtcclxuICAgICAgICBpZiAodGhpcy5jaGVja0luaXRlZChmYWxzZSkpXHJcbiAgICAgICAgICAgIHRoaXMuX29uU2Nyb2xsaW5nKCk7XHJcbiAgICB9LFxyXG4gICAgLy/lvZNJdGVt6Ieq6YCC5bqUXHJcbiAgICBfb25JdGVtQWRhcHRpdmUoaXRlbSkge1xyXG4gICAgICAgIGlmICh0aGlzLmNoZWNrSW5pdGVkKGZhbHNlKSkge1xyXG4gICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICAoIXRoaXMuX3NpemVUeXBlICYmIGl0ZW0ud2lkdGggIT0gdGhpcy5faXRlbVNpemUud2lkdGgpXHJcbiAgICAgICAgICAgICAgICB8fCAodGhpcy5fc2l6ZVR5cGUgJiYgaXRlbS5oZWlnaHQgIT0gdGhpcy5faXRlbVNpemUuaGVpZ2h0KVxyXG4gICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5fY3VzdG9tU2l6ZSlcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jdXN0b21TaXplID0ge307XHJcbiAgICAgICAgICAgICAgICBsZXQgdmFsID0gdGhpcy5fc2l6ZVR5cGUgPyBpdGVtLmhlaWdodCA6IGl0ZW0ud2lkdGg7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fY3VzdG9tU2l6ZVtpdGVtLl9saXN0SWRdICE9IHZhbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1c3RvbVNpemVbaXRlbS5fbGlzdElkXSA9IHZhbDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNpemVDb250ZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb250ZW50LmNoaWxkcmVuLmZvckVhY2goY2hpbGQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVJdGVtUG9zKGNoaWxkKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyDlpoLmnpzlvZPliY3mraPlnKjov5DooYwgc2Nyb2xsVG/vvIzogq/lrprkvJrkuI3lh4bnoa7vvIzlnKjov5nph4zlgZrkv67mraNcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTmFOKHRoaXMuX3Njcm9sbFRvTGlzdElkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zY3JvbGxQb3MgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnVuc2NoZWR1bGUodGhpcy5fc2Nyb2xsVG9Tbyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2Nyb2xsVG8odGhpcy5fc2Nyb2xsVG9MaXN0SWQsIE1hdGgubWF4KDAsIHRoaXMuX3Njcm9sbFRvRW5kVGltZSAtICgobmV3IERhdGUoKSkuZ2V0VGltZSgpIC8gMTAwMCkpKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy9QQUdF57KY6ZmEXHJcbiAgICBfcGFnZUFkaGVyZSgpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgaWYgKCF0LmN5Y2xpYyAmJiAodC5lbGFzdGljVG9wID4gMCB8fCB0LmVsYXN0aWNSaWdodCA+IDAgfHwgdC5lbGFzdGljQm90dG9tID4gMCB8fCB0LmVsYXN0aWNMZWZ0ID4gMCkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBsZXQgY3VyUG9zID0gdC5fc2l6ZVR5cGUgPyB0LnZpZXdUb3AgOiB0LnZpZXdMZWZ0O1xyXG4gICAgICAgIGxldCBkaXMgPSAodC5fc2l6ZVR5cGUgPyB0Lm5vZGUuaGVpZ2h0IDogdC5ub2RlLndpZHRoKSAqIHQucGFnZURpc3RhbmNlO1xyXG4gICAgICAgIGxldCBjYW5Ta2lwID0gTWF0aC5hYnModC5fYmVnYW5Qb3MgLSBjdXJQb3MpID4gZGlzO1xyXG4gICAgICAgIGlmIChjYW5Ta2lwKSB7XHJcbiAgICAgICAgICAgIGxldCB0aW1lSW5TZWNvbmQgPSAuNTtcclxuICAgICAgICAgICAgc3dpdGNoICh0Ll9hbGlnbkNhbGNUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6Ly/ljZXooYxIT1JJWk9OVEFM77yITEVGVF9UT19SSUdIVO+8ieOAgee9keagvFZFUlRJQ0FM77yITEVGVF9UT19SSUdIVO+8iVxyXG4gICAgICAgICAgICAgICAgY2FzZSA0Oi8v5Y2V5YiXVkVSVElDQUzvvIhCT1RUT01fVE9fVE9Q77yJ44CB572R5qC8SE9SSVpPTlRBTO+8iEJPVFRPTV9UT19UT1DvvIlcclxuICAgICAgICAgICAgICAgICAgICBpZiAodC5fYmVnYW5Qb3MgPiBjdXJQb3MpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdC5wcmVQYWdlKHRpbWVJblNlY29uZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNjLmxvZygnX3BhZ2VBZGhlcmUgICBQUFBQUFBQUFBQUFBQUFAnKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Lm5leHRQYWdlKHRpbWVJblNlY29uZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNjLmxvZygnX3BhZ2VBZGhlcmUgICBOTk5OTk5OTk5OTk5OTk4nKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMjovL+WNleihjEhPUklaT05UQUzvvIhSSUdIVF9UT19MRUZU77yJ44CB572R5qC8VkVSVElDQUzvvIhSSUdIVF9UT19MRUZU77yJXHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6Ly/ljZXliJdWRVJUSUNBTO+8iFRPUF9UT19CT1RUT03vvInjgIHnvZHmoLxIT1JJWk9OVEFM77yIVE9QX1RPX0JPVFRPTe+8iVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0Ll9iZWdhblBvcyA8IGN1clBvcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0LnByZVBhZ2UodGltZUluU2Vjb25kKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Lm5leHRQYWdlKHRpbWVJblNlY29uZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmICh0LmVsYXN0aWNUb3AgPD0gMCAmJiB0LmVsYXN0aWNSaWdodCA8PSAwICYmIHQuZWxhc3RpY0JvdHRvbSA8PSAwICYmIHQuZWxhc3RpY0xlZnQgPD0gMCkge1xyXG4gICAgICAgICAgICB0LmFkaGVyZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0Ll9iZWdhblBvcyA9IG51bGw7XHJcbiAgICB9LFxyXG4gICAgLy/nspjpmYRcclxuICAgIGFkaGVyZSgpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgaWYgKCF0LmNoZWNrSW5pdGVkKCkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBpZiAodC5lbGFzdGljVG9wID4gMCB8fCB0LmVsYXN0aWNSaWdodCA+IDAgfHwgdC5lbGFzdGljQm90dG9tID4gMCB8fCB0LmVsYXN0aWNMZWZ0ID4gMClcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIHQuYWRoZXJpbmcgPSB0cnVlO1xyXG4gICAgICAgIC8vIGlmICghdC5fdmlydHVhbClcclxuICAgICAgICB0Ll9jYWxjTmVhcmVzdEl0ZW0oKTtcclxuICAgICAgICBsZXQgb2Zmc2V0ID0gKHQuX3NpemVUeXBlID8gdC5fdG9wR2FwIDogdC5fbGVmdEdhcCkgLyAodC5fc2l6ZVR5cGUgPyB0Lm5vZGUuaGVpZ2h0IDogdC5ub2RlLndpZHRoKTtcclxuICAgICAgICBsZXQgdGltZUluU2Vjb25kID0gLjc7XHJcbiAgICAgICAgdC5zY3JvbGxUbyh0Lm5lYXJlc3RMaXN0SWQsIHRpbWVJblNlY29uZCwgb2Zmc2V0KTtcclxuICAgIH0sXHJcbiAgICAvL1VwZGF0ZS4uXHJcbiAgICB1cGRhdGUoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuZnJhbWVCeUZyYW1lUmVuZGVyTnVtIDw9IDAgfHwgdGhpcy5fdXBkYXRlRG9uZSlcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIC8vIGNjLmxvZyh0aGlzLmRpc3BsYXlEYXRhLmxlbmd0aCwgdGhpcy5fdXBkYXRlQ291bnRlciwgdGhpcy5kaXNwbGF5RGF0YVt0aGlzLl91cGRhdGVDb3VudGVyXSk7XHJcbiAgICAgICAgaWYgKHRoaXMuX3ZpcnR1YWwpIHtcclxuICAgICAgICAgICAgbGV0IGxlbiA9ICh0aGlzLl91cGRhdGVDb3VudGVyICsgdGhpcy5mcmFtZUJ5RnJhbWVSZW5kZXJOdW0pID4gdGhpcy5kaXNwbGF5SXRlbU51bSA/IHRoaXMuZGlzcGxheUl0ZW1OdW0gOiAodGhpcy5fdXBkYXRlQ291bnRlciArIHRoaXMuZnJhbWVCeUZyYW1lUmVuZGVyTnVtKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgbiA9IHRoaXMuX3VwZGF0ZUNvdW50ZXI7IG4gPCBsZW47IG4rKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGRhdGEgPSB0aGlzLmRpc3BsYXlEYXRhW25dO1xyXG4gICAgICAgICAgICAgICAgaWYgKGRhdGEpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY3JlYXRlT3JVcGRhdGVJdGVtKGRhdGEpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fdXBkYXRlQ291bnRlciA+PSB0aGlzLmRpc3BsYXlJdGVtTnVtIC0gMSkgeyAvL+acgOWQjuS4gOS4qlxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RvbmVBZnRlclVwZGF0ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNvdW50ZXIgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURvbmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuX3Njcm9sbFZpZXcuaXNTY3JvbGxpbmcoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9uZUFmdGVyVXBkYXRlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURvbmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RlbFJlZHVuZGFudEl0ZW0oKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9mb3JjZVVwZGF0ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhbGNOZWFyZXN0SXRlbSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnNsaWRlTW9kZSA9PSBTbGlkZVR5cGUuUEFHRSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJQYWdlTnVtID0gdGhpcy5uZWFyZXN0TGlzdElkO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ291bnRlciArPSB0aGlzLmZyYW1lQnlGcmFtZVJlbmRlck51bTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl91cGRhdGVDb3VudGVyIDwgdGhpcy5fbnVtSXRlbXMpIHtcclxuICAgICAgICAgICAgICAgIGxldCBsZW4gPSAodGhpcy5fdXBkYXRlQ291bnRlciArIHRoaXMuZnJhbWVCeUZyYW1lUmVuZGVyTnVtKSA+IHRoaXMuX251bUl0ZW1zID8gdGhpcy5fbnVtSXRlbXMgOiAodGhpcy5fdXBkYXRlQ291bnRlciArIHRoaXMuZnJhbWVCeUZyYW1lUmVuZGVyTnVtKTtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IG4gPSB0aGlzLl91cGRhdGVDb3VudGVyOyBuIDwgbGVuOyBuKyspIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jcmVhdGVPclVwZGF0ZUl0ZW0yKG4pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ291bnRlciArPSB0aGlzLmZyYW1lQnlGcmFtZVJlbmRlck51bTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURvbmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2FsY05lYXJlc3RJdGVtKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5zbGlkZU1vZGUgPT0gU2xpZGVUeXBlLlBBR0UpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJQYWdlTnVtID0gdGhpcy5uZWFyZXN0TGlzdElkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5Yib5bu65oiW5pu05pawSXRlbe+8iOiZmuaLn+WIl+ihqOeUqO+8iVxyXG4gICAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5pWw5o2uXHJcbiAgICAgKi9cclxuICAgIF9jcmVhdGVPclVwZGF0ZUl0ZW0oZGF0YSkge1xyXG4gICAgICAgIGxldCBpdGVtID0gdGhpcy5nZXRJdGVtQnlMaXN0SWQoZGF0YS5pZCk7XHJcbiAgICAgICAgaWYgKCFpdGVtKSB7IC8v5aaC5p6c5LiN5a2Y5ZyoXHJcbiAgICAgICAgICAgIGxldCBjYW5HZXQgPSB0aGlzLl9wb29sLnNpemUoKSA+IDA7XHJcbiAgICAgICAgICAgIGlmIChjYW5HZXQpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0gPSB0aGlzLl9wb29sLmdldCgpO1xyXG4gICAgICAgICAgICAgICAgLy8gY2MubG9nKCfku47msaDkuK3lj5blh7o6OiAgIOaXp2lkID0nLCBpdGVtLl9saXN0SWQsICfvvIzmlrBpZCA9JywgZGF0YS5pZCwgaXRlbSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpdGVtID0gY2MuaW5zdGFudGlhdGUodGhpcy5faXRlbVRtcCk7XHJcbiAgICAgICAgICAgICAgICAvLyBjYy5sb2coJ+aWsOW7ujo6JywgZGF0YS5pZCwgaXRlbSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGl0ZW0uX2xpc3RJZCAhPSBkYXRhLmlkKSB7XHJcbiAgICAgICAgICAgICAgICBpdGVtLl9saXN0SWQgPSBkYXRhLmlkO1xyXG4gICAgICAgICAgICAgICAgaXRlbS5zZXRDb250ZW50U2l6ZSh0aGlzLl9pdGVtU2l6ZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaXRlbS5zZXRQb3NpdGlvbihuZXcgY2MudjIoZGF0YS54LCBkYXRhLnkpKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzZXRJdGVtU2l6ZShpdGVtKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50LmFkZENoaWxkKGl0ZW0pO1xyXG4gICAgICAgICAgICBpZiAoY2FuR2V0ICYmIHRoaXMuX25lZWRVcGRhdGVXaWRnZXQpIHtcclxuICAgICAgICAgICAgICAgIGxldCB3aWRnZXQgPSBpdGVtLmdldENvbXBvbmVudChjYy5XaWRnZXQpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHdpZGdldClcclxuICAgICAgICAgICAgICAgICAgICB3aWRnZXQudXBkYXRlQWxpZ25tZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaXRlbS5zZXRTaWJsaW5nSW5kZXgodGhpcy5jb250ZW50LmNoaWxkcmVuQ291bnQgLSAxKTtcclxuXHJcbiAgICAgICAgICAgIGxldCBsaXN0SXRlbSA9IGl0ZW0uZ2V0Q29tcG9uZW50KExpc3RJdGVtKTtcclxuICAgICAgICAgICAgaXRlbS5saXN0SXRlbSA9IGxpc3RJdGVtO1xyXG4gICAgICAgICAgICBpZiAobGlzdEl0ZW0pIHtcclxuICAgICAgICAgICAgICAgIGxpc3RJdGVtLl9saXN0ID0gdGhpcztcclxuICAgICAgICAgICAgICAgIGxpc3RJdGVtLl9yZWdpc3RlckV2ZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMucmVuZGVyRXZlbnQpIHtcclxuICAgICAgICAgICAgICAgIGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIuZW1pdEV2ZW50cyhbdGhpcy5yZW5kZXJFdmVudF0sIGl0ZW0sIGRhdGEuaWQgJSB0aGlzLl9hY3R1YWxOdW1JdGVtcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuX2ZvcmNlVXBkYXRlICYmIHRoaXMucmVuZGVyRXZlbnQpIHsgLy/lvLrliLbmm7TmlrBcclxuICAgICAgICAgICAgaXRlbS5zZXRQb3NpdGlvbihuZXcgY2MudjIoZGF0YS54LCBkYXRhLnkpKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzZXRJdGVtU2l6ZShpdGVtKTtcclxuICAgICAgICAgICAgLy8gY2MubG9nKCdBREQ6OicsIGRhdGEuaWQsIGl0ZW0pO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5yZW5kZXJFdmVudCkge1xyXG4gICAgICAgICAgICAgICAgY2MuQ29tcG9uZW50LkV2ZW50SGFuZGxlci5lbWl0RXZlbnRzKFt0aGlzLnJlbmRlckV2ZW50XSwgaXRlbSwgZGF0YS5pZCAlIHRoaXMuX2FjdHVhbE51bUl0ZW1zKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9yZXNldEl0ZW1TaXplKGl0ZW0pO1xyXG5cclxuICAgICAgICB0aGlzLl91cGRhdGVMaXN0SXRlbShpdGVtLmxpc3RJdGVtKTtcclxuICAgICAgICBpZiAodGhpcy5fbGFzdERpc3BsYXlEYXRhLmluZGV4T2YoZGF0YS5pZCkgPCAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2xhc3REaXNwbGF5RGF0YS5wdXNoKGRhdGEuaWQpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvL+WIm+W7uuaIluabtOaWsEl0ZW3vvIjpnZ7omZrmi5/liJfooajnlKjvvIlcclxuICAgIF9jcmVhdGVPclVwZGF0ZUl0ZW0yKGxpc3RJZCkge1xyXG4gICAgICAgIGxldCBpdGVtID0gdGhpcy5jb250ZW50LmNoaWxkcmVuW2xpc3RJZF07XHJcbiAgICAgICAgaWYgKCFpdGVtKSB7IC8v5aaC5p6c5LiN5a2Y5ZyoXHJcbiAgICAgICAgICAgIGl0ZW0gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLl9pdGVtVG1wKTtcclxuICAgICAgICAgICAgaXRlbS5fbGlzdElkID0gbGlzdElkO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQuYWRkQ2hpbGQoaXRlbSk7XHJcbiAgICAgICAgICAgIGxldCBsaXN0SXRlbSA9IGl0ZW0uZ2V0Q29tcG9uZW50KExpc3RJdGVtKTtcclxuICAgICAgICAgICAgaXRlbS5saXN0SXRlbSA9IGxpc3RJdGVtO1xyXG4gICAgICAgICAgICBpZiAobGlzdEl0ZW0pIHtcclxuICAgICAgICAgICAgICAgIGxpc3RJdGVtLl9saXN0ID0gdGhpcztcclxuICAgICAgICAgICAgICAgIGxpc3RJdGVtLl9yZWdpc3RlckV2ZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMucmVuZGVyRXZlbnQpIHtcclxuICAgICAgICAgICAgICAgIGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIuZW1pdEV2ZW50cyhbdGhpcy5yZW5kZXJFdmVudF0sIGl0ZW0sIGxpc3RJZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuX2ZvcmNlVXBkYXRlICYmIHRoaXMucmVuZGVyRXZlbnQpIHsgLy/lvLrliLbmm7TmlrBcclxuICAgICAgICAgICAgaXRlbS5fbGlzdElkID0gbGlzdElkO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5yZW5kZXJFdmVudCkge1xyXG4gICAgICAgICAgICAgICAgY2MuQ29tcG9uZW50LkV2ZW50SGFuZGxlci5lbWl0RXZlbnRzKFt0aGlzLnJlbmRlckV2ZW50XSwgaXRlbSwgbGlzdElkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl91cGRhdGVMaXN0SXRlbShpdGVtLmxpc3RJdGVtKTtcclxuICAgICAgICBpZiAodGhpcy5fbGFzdERpc3BsYXlEYXRhLmluZGV4T2YobGlzdElkKSA8IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fbGFzdERpc3BsYXlEYXRhLnB1c2gobGlzdElkKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIF91cGRhdGVMaXN0SXRlbShsaXN0SXRlbSkge1xyXG4gICAgICAgIGlmICghbGlzdEl0ZW0pXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBpZiAodGhpcy5zZWxlY3RlZE1vZGUgPiBTZWxlY3RlZFR5cGUuTk9ORSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHRoaXMuc2VsZWN0ZWRNb2RlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIFNlbGVjdGVkVHlwZS5TSU5HTEU6XHJcbiAgICAgICAgICAgICAgICAgICAgbGlzdEl0ZW0uc2VsZWN0ZWQgPSB0aGlzLnNlbGVjdGVkSWQgPT0gbGlzdEl0ZW0ubm9kZS5fbGlzdElkO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSBTZWxlY3RlZFR5cGUuTVVMVDpcclxuICAgICAgICAgICAgICAgICAgICBsaXN0SXRlbS5zZWxlY3RlZCA9IHRoaXMubXVsdFNlbGVjdGVkLmluZGV4T2YobGlzdEl0ZW0ubm9kZS5fbGlzdElkKSA+PSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8v5LuF6Jma5ouf5YiX6KGo55SoXHJcbiAgICBfcmVzZXRJdGVtU2l6ZShpdGVtKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIGxldCBzaXplO1xyXG4gICAgICAgIGlmICh0aGlzLl9jdXN0b21TaXplICYmIHRoaXMuX2N1c3RvbVNpemVbaXRlbS5fbGlzdElkXSkge1xyXG4gICAgICAgICAgICBzaXplID0gdGhpcy5fY3VzdG9tU2l6ZVtpdGVtLl9saXN0SWRdO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9jb2xMaW5lTnVtID4gMSlcclxuICAgICAgICAgICAgICAgIGl0ZW0uc2V0Q29udGVudFNpemUodGhpcy5faXRlbVNpemUpO1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICBzaXplID0gdGhpcy5fc2l6ZVR5cGUgPyB0aGlzLl9pdGVtU2l6ZS5oZWlnaHQgOiB0aGlzLl9pdGVtU2l6ZS53aWR0aDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHNpemUpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3NpemVUeXBlKVxyXG4gICAgICAgICAgICAgICAgaXRlbS5oZWlnaHQgPSBzaXplO1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICBpdGVtLndpZHRoID0gc2l6ZTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDmm7TmlrBJdGVt5L2N572uXHJcbiAgICAgKiBAcGFyYW0ge051bWJlcnx8Tm9kZX0gbGlzdElkT3JJdGVtXHJcbiAgICAgKi9cclxuICAgIF91cGRhdGVJdGVtUG9zKGxpc3RJZE9ySXRlbSkge1xyXG4gICAgICAgIGxldCBpdGVtID0gaXNOYU4obGlzdElkT3JJdGVtKSA/IGxpc3RJZE9ySXRlbSA6IHRoaXMuZ2V0SXRlbUJ5TGlzdElkKGxpc3RJZE9ySXRlbSk7XHJcbiAgICAgICAgbGV0IHBvcyA9IHRoaXMuZ2V0SXRlbVBvcyhpdGVtLl9saXN0SWQpO1xyXG4gICAgICAgIGl0ZW0uc2V0UG9zaXRpb24ocG9zLngsIHBvcy55KTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOiuvue9ruWkmumAiVxyXG4gICAgICogQHBhcmFtIHtBcnJheX0gYXJncyDlj6/ku6XmmK/ljZXkuKpsaXN0SWTvvIzkuZ/lj6/mmK/kuKpsaXN0SWTmlbDnu4RcclxuICAgICAqIEBwYXJhbSB7Qm9vbGVhbn0gYm9vbCDlgLzvvIzlpoLmnpzkuLpudWxs55qE6K+d77yM5YiZ55u05o6l55SoYXJnc+imhuebllxyXG4gICAgICovXHJcbiAgICBzZXRNdWx0U2VsZWN0ZWQoYXJncywgYm9vbCkge1xyXG4gICAgICAgIGxldCB0ID0gdGhpcztcclxuICAgICAgICBpZiAoIXQuY2hlY2tJbml0ZWQoKSlcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShhcmdzKSkge1xyXG4gICAgICAgICAgICBhcmdzID0gW2FyZ3NdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoYm9vbCA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHQubXVsdFNlbGVjdGVkID0gYXJncztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgbGlzdElkLCBzdWI7XHJcbiAgICAgICAgICAgIGlmIChib29sKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBuID0gYXJncy5sZW5ndGggLSAxOyBuID49IDA7IG4tLSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxpc3RJZCA9IGFyZ3Nbbl07XHJcbiAgICAgICAgICAgICAgICAgICAgc3ViID0gdC5tdWx0U2VsZWN0ZWQuaW5kZXhPZihsaXN0SWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChzdWIgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQubXVsdFNlbGVjdGVkLnB1c2gobGlzdElkKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBuID0gYXJncy5sZW5ndGggLSAxOyBuID49IDA7IG4tLSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxpc3RJZCA9IGFyZ3Nbbl07XHJcbiAgICAgICAgICAgICAgICAgICAgc3ViID0gdC5tdWx0U2VsZWN0ZWQuaW5kZXhPZihsaXN0SWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChzdWIgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Lm11bHRTZWxlY3RlZC5zcGxpY2Uoc3ViLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdC5fZm9yY2VVcGRhdGUgPSB0cnVlO1xyXG4gICAgICAgIHQuX29uU2Nyb2xsaW5nKCk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDmm7TmlrDmjIflrprnmoRJdGVtXHJcbiAgICAgKiBAcGFyYW0ge0FycmF5fSBhcmdzIOWNleS4qmxpc3RJZO+8jOaIluiAheaVsOe7hFxyXG4gICAgICogQHJldHVybnNcclxuICAgICAqL1xyXG4gICAgdXBkYXRlSXRlbShhcmdzKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNoZWNrSW5pdGVkKCkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoYXJncykpIHtcclxuICAgICAgICAgICAgYXJncyA9IFthcmdzXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgbiA9IDAsIGxlbiA9IGFyZ3MubGVuZ3RoOyBuIDwgbGVuOyBuKyspIHtcclxuICAgICAgICAgICAgbGV0IGxpc3RJZCA9IGFyZ3Nbbl07XHJcbiAgICAgICAgICAgIGxldCBpdGVtID0gdGhpcy5nZXRJdGVtQnlMaXN0SWQobGlzdElkKTtcclxuICAgICAgICAgICAgaWYgKGl0ZW0pIHtcclxuICAgICAgICAgICAgICAgIGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIuZW1pdEV2ZW50cyhbdGhpcy5yZW5kZXJFdmVudF0sIGl0ZW0sIGxpc3RJZCAlIHRoaXMuX2FjdHVhbE51bUl0ZW1zKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOabtOaWsOWFqOmDqFxyXG4gICAgICovXHJcbiAgICB1cGRhdGVBbGwoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNoZWNrSW5pdGVkKCkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB0aGlzLm51bUl0ZW1zID0gdGhpcy5udW1JdGVtcztcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOagueaNrkxpc3RJROiOt+WPlkl0ZW1cclxuICAgICAqIEBwYXJhbSB7TnVtYmVyfSBsaXN0SWRcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIGdldEl0ZW1CeUxpc3RJZChsaXN0SWQpIHtcclxuICAgICAgICBmb3IgKGxldCBuID0gdGhpcy5jb250ZW50LmNoaWxkcmVuQ291bnQgLSAxOyBuID49IDA7IG4tLSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb250ZW50LmNoaWxkcmVuW25dLl9saXN0SWQgPT0gbGlzdElkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29udGVudC5jaGlsZHJlbltuXTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5blnKjmmL7npLrljLrln5/lpJbnmoRJdGVtXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICBfZ2V0T3V0c2lkZUl0ZW0oKSB7XHJcbiAgICAgICAgbGV0IGl0ZW0sIGlzT3V0c2lkZTtcclxuICAgICAgICBsZXQgcmVzdWx0ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgbiA9IHRoaXMuY29udGVudC5jaGlsZHJlbkNvdW50IC0gMTsgbiA+PSAwOyBuLS0pIHtcclxuICAgICAgICAgICAgaXRlbSA9IHRoaXMuY29udGVudC5jaGlsZHJlbltuXTtcclxuICAgICAgICAgICAgaXNPdXRzaWRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKGlzT3V0c2lkZSkge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgYyA9IHRoaXMuZGlzcGxheUl0ZW1OdW0gLSAxOyBjID49IDA7IGMtLSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5kaXNwbGF5RGF0YVtjXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxpc3RJZCA9IHRoaXMuZGlzcGxheURhdGFbY10uaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW0uX2xpc3RJZCA9PSBsaXN0SWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNPdXRzaWRlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaXNPdXRzaWRlKSB7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaChpdGVtKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfSxcclxuICAgIC8v5Yig6Zmk5pi+56S65Yy65Z+f5Lul5aSW55qESXRlbVxyXG4gICAgX2RlbFJlZHVuZGFudEl0ZW0oKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3ZpcnR1YWwpIHtcclxuICAgICAgICAgICAgbGV0IGFyciA9IHRoaXMuX2dldE91dHNpZGVJdGVtKCk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IG4gPSBhcnIubGVuZ3RoIC0gMTsgbiA+PSAwOyBuLS0pIHtcclxuICAgICAgICAgICAgICAgIGxldCBpdGVtID0gYXJyW25dO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Njcm9sbEl0ZW0gJiYgaXRlbS5fbGlzdElkID09IHRoaXMuX3Njcm9sbEl0ZW0uX2xpc3RJZClcclxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bvb2wucHV0KGl0ZW0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIGNjLmxvZygn5a2Y5YWlOjonLCBzdHIsICcgICAgcG9vbC5sZW5ndGggPScsIHRoaXMuX3Bvb2wubGVuZ3RoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB3aGlsZSAodGhpcy5jb250ZW50LmNoaWxkcmVuQ291bnQgPiB0aGlzLl9udW1JdGVtcykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVsU2luZ2xlSXRlbSh0aGlzLmNvbnRlbnQuY2hpbGRyZW5bdGhpcy5jb250ZW50LmNoaWxkcmVuQ291bnQgLSAxXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy/liKDpmaTljZXkuKpJdGVtXHJcbiAgICBfZGVsU2luZ2xlSXRlbShpdGVtKSB7XHJcbiAgICAgICAgLy8gY2MubG9nKCdERUw6OicsIGl0ZW0uX2xpc3RJZCwgaXRlbSk7XHJcbiAgICAgICAgaXRlbS5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgaWYgKGl0ZW0uZGVzdHJveSlcclxuICAgICAgICAgICAgaXRlbS5kZXN0cm95KCk7XHJcbiAgICAgICAgaXRlbSA9IG51bGw7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDliqjmlYjliKDpmaRJdGVt77yI5q2k5pa55rOV5Y+q6YCC55So5LqO6Jma5ouf5YiX6KGo77yM5Y2zX3ZpcnR1YWw9dHJ1Ze+8iVxyXG4gICAgICog5LiA5a6a6KaB5Zyo5Zue6LCD5Ye95pWw6YeM6YeN5paw6K6+572u5paw55qEbnVtSXRlbXPov5vooYzliLfmlrDvvIzmr5Xnq5/mnKxMaXN05piv6Z2g5pWw5o2u6amx5Yqo55qE44CCXHJcbiAgICAgKi9cclxuICAgIGFuaURlbEl0ZW0obGlzdElkLCBjYWxsRnVuYywgYW5pVHlwZSkge1xyXG4gICAgICAgIGxldCB0ID0gdGhpcztcclxuXHJcbiAgICAgICAgaWYgKCF0LmNoZWNrSW5pdGVkKCkgfHwgdC5jeWNsaWMgfHwgIXQuX3ZpcnR1YWwpXHJcbiAgICAgICAgICAgIHJldHVybiBjYy5lcnJvcignVGhpcyBmdW5jdGlvbiBpcyBub3QgYWxsb3dlZCB0byBiZSBjYWxsZWQhJyk7XHJcblxyXG4gICAgICAgIGlmICh0Ll9hbmlEZWxSdW5pbmcpXHJcbiAgICAgICAgICAgIHJldHVybiBjYy53YXJuKCdQbGVhc2Ugd2FpdCBmb3IgdGhlIGN1cnJlbnQgZGVsZXRpb24gdG8gZmluaXNoIScpO1xyXG5cclxuICAgICAgICBsZXQgaXRlbSA9IHQuZ2V0SXRlbUJ5TGlzdElkKGxpc3RJZCk7XHJcbiAgICAgICAgaWYgKCFpdGVtKSB7XHJcbiAgICAgICAgICAgIGNhbGxGdW5jKGxpc3RJZCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdC5fYW5pRGVsUnVuaW5nID0gdHJ1ZTtcclxuICAgICAgICBsZXQgY3VyTGFzdElkID0gdC5kaXNwbGF5RGF0YVt0LmRpc3BsYXlEYXRhLmxlbmd0aCAtIDFdLmlkO1xyXG4gICAgICAgIGxldCByZXNldFNlbGVjdGVkSWQgPSBpdGVtLmxpc3RJdGVtLnNlbGVjdGVkO1xyXG4gICAgICAgIGl0ZW0ubGlzdEl0ZW0uc2hvd0FuaShhbmlUeXBlLCAoKSA9PiB7XHJcbiAgICAgICAgICAgIC8v5Yik5pat5pyJ5rKh5pyJ5LiL5LiA5Liq77yM5aaC5p6c5pyJ55qE6K+d77yM5Yib5bu657KX5p2lXHJcbiAgICAgICAgICAgIGxldCBuZXdJZDtcclxuICAgICAgICAgICAgaWYgKGN1ckxhc3RJZCA8IHQuX251bUl0ZW1zIC0gMikge1xyXG4gICAgICAgICAgICAgICAgbmV3SWQgPSBjdXJMYXN0SWQgKyAxO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChuZXdJZCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgbmV3RGF0YSA9IHQuX2NhbGNJdGVtUG9zKG5ld0lkKTtcclxuICAgICAgICAgICAgICAgIHQuZGlzcGxheURhdGEucHVzaChuZXdEYXRhKTtcclxuICAgICAgICAgICAgICAgIGlmICh0Ll92aXJ0dWFsKVxyXG4gICAgICAgICAgICAgICAgICAgIHQuX2NyZWF0ZU9yVXBkYXRlSXRlbShuZXdEYXRhKTtcclxuICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICB0Ll9jcmVhdGVPclVwZGF0ZUl0ZW0yKG5ld0lkKTtcclxuICAgICAgICAgICAgfSBlbHNlXHJcbiAgICAgICAgICAgICAgICB0Ll9udW1JdGVtcy0tO1xyXG4gICAgICAgICAgICBpZiAodC5zZWxlY3RlZE1vZGUgPT0gU2VsZWN0ZWRUeXBlLlNJTkdMRSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc2V0U2VsZWN0ZWRJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHQuX3NlbGVjdGVkSWQgPSAtMTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodC5fc2VsZWN0ZWRJZCAtIDEgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHQuX3NlbGVjdGVkSWQtLTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0LnNlbGVjdGVkTW9kZSA9PSBTZWxlY3RlZFR5cGUuTVVMVCAmJiB0Lm11bHRTZWxlY3RlZC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzdWIgPSB0Lm11bHRTZWxlY3RlZC5pbmRleE9mKGxpc3RJZCk7XHJcbiAgICAgICAgICAgICAgICAvLyBsZXQgdG1wO1xyXG4gICAgICAgICAgICAgICAgaWYgKHN1YiA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdC5tdWx0U2VsZWN0ZWQuc3BsaWNlKHN1YiwgMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvL+WkmumAieeahOaVsOaNru+8jOWcqOWFtuWQjueahOWFqOmDqOWHj+S4gFxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgbiA9IHQubXVsdFNlbGVjdGVkLmxlbmd0aCAtIDE7IG4gPj0gMDsgbi0tKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGlkID0gdC5tdWx0U2VsZWN0ZWRbbl07XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlkID49IGxpc3RJZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgdC5tdWx0U2VsZWN0ZWRbbl0tLTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodC5fY3VzdG9tU2l6ZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHQuX2N1c3RvbVNpemVbbGlzdElkXSlcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgdC5fY3VzdG9tU2l6ZVtsaXN0SWRdO1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld0N1c3RvbVNpemUgPSB7fTtcclxuICAgICAgICAgICAgICAgIGxldCBzaXplO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaWQgaW4gdC5fY3VzdG9tU2l6ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNpemUgPSB0Ll9jdXN0b21TaXplW2lkXTtcclxuICAgICAgICAgICAgICAgICAgICBpZCA9IHBhcnNlSW50KGlkKTtcclxuICAgICAgICAgICAgICAgICAgICBuZXdDdXN0b21TaXplW2lkIC0gKGlkID49IGxpc3RJZCA/IDEgOiAwKV0gPSBzaXplO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdC5fY3VzdG9tU2l6ZSA9IG5ld0N1c3RvbVNpemU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy/lkI7pnaLnmoRJdGVt5ZCR5YmN5oC855qE5Yqo5pWIXHJcbiAgICAgICAgICAgIGxldCBzZWMgPSAuMjMzMztcclxuICAgICAgICAgICAgbGV0IGFjdHMsIGhhdmVDQjtcclxuICAgICAgICAgICAgZm9yIChsZXQgbiA9IG5ld0lkICE9IG51bGwgPyBuZXdJZCA6IGN1ckxhc3RJZDsgbiA+PSBsaXN0SWQgKyAxOyBuLS0pIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0gPSB0LmdldEl0ZW1CeUxpc3RJZChuKTtcclxuICAgICAgICAgICAgICAgIGlmIChpdGVtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHBvc0RhdGEgPSB0Ll9jYWxjSXRlbVBvcyhuIC0gMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0cyA9IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmV3IGNjLm1vdmVUbyhzZWMsIG5ldyBjYy52Mihwb3NEYXRhLngsIHBvc0RhdGEueSkpLFxyXG4gICAgICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG4gPD0gbGlzdElkICsgMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYXZlQ0IgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RzLnB1c2gobmV3IGNjLkNhbGxGdW5jKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHQuX2FuaURlbFJ1bmluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbEZ1bmMobGlzdElkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAoYWN0cy5sZW5ndGggPiAxKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnJ1bkFjdGlvbihuZXcgY2MuU2VxdWVuY2UoYWN0cykpO1xyXG4gICAgICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5ydW5BY3Rpb24oYWN0c1swXSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKCFoYXZlQ0IpIHtcclxuICAgICAgICAgICAgICAgIHQuX2FuaURlbFJ1bmluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgY2FsbEZ1bmMobGlzdElkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIHRydWUpO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5rua5Yqo5YiwLi5cclxuICAgICAqIEBwYXJhbSB7TnVtYmVyfSBsaXN0SWQg57Si5byV77yI5aaC5p6cPDDvvIzliJnmu5rliLDpppbkuKpJdGVt5L2N572u77yM5aaC5p6cPj1fbnVtSXRlbXPvvIzliJnmu5rliLDmnIDmnKtJdGVt5L2N572u77yJXHJcbiAgICAgKiBAcGFyYW0ge051bWJlcn0gdGltZUluU2Vjb25kIOaXtumXtFxyXG4gICAgICogQHBhcmFtIHtOdW1iZXJ9IG9mZnNldCDntKLlvJXnm67moIfkvY3nva7lgY/np7vvvIwwLTFcclxuICAgICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3ZlclN0cmVzcyDmu5rliqjlkI7mmK/lkKblvLrosIPor6VJdGVt77yI6L+Z5Y+q5piv5Liq5a6e6aqM5Yqf6IO977yJXHJcbiAgICAgKi9cclxuICAgIHNjcm9sbFRvKGxpc3RJZCwgdGltZUluU2Vjb25kLCBvZmZzZXQsIG92ZXJTdHJlc3MpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgaWYgKCF0LmNoZWNrSW5pdGVkKCkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB0Ll9zY3JvbGxWaWV3LnN0b3BBdXRvU2Nyb2xsKCk7XHJcbiAgICAgICAgaWYgKHRpbWVJblNlY29uZCA9PSBudWxsKSAgIC8v6buY6K6kMC41XHJcbiAgICAgICAgICAgIHRpbWVJblNlY29uZCA9IC41O1xyXG4gICAgICAgIGVsc2UgaWYgKHRpbWVJblNlY29uZCA8IDApXHJcbiAgICAgICAgICAgIHRpbWVJblNlY29uZCA9IDA7XHJcbiAgICAgICAgaWYgKGxpc3RJZCA8IDApXHJcbiAgICAgICAgICAgIGxpc3RJZCA9IDA7XHJcbiAgICAgICAgZWxzZSBpZiAobGlzdElkID49IHQuX251bUl0ZW1zKVxyXG4gICAgICAgICAgICBsaXN0SWQgPSB0Ll9udW1JdGVtcyAtIDE7XHJcbiAgICAgICAgLy8g5Lul6Ziy6K6+572u5LqGbnVtSXRlbXPkuYvlkI5sYXlvdXTnmoTlsLrlr7jov5jmnKrmm7TmlrBcclxuICAgICAgICBpZiAoIXQuX3ZpcnR1YWwgJiYgdC5fbGF5b3V0ICYmIHQuX2xheW91dC5lbmFibGVkKVxyXG4gICAgICAgICAgICB0Ll9sYXlvdXQudXBkYXRlTGF5b3V0KCk7XHJcblxyXG4gICAgICAgIGxldCBwb3MgPSB0LmdldEl0ZW1Qb3MobGlzdElkKTtcclxuICAgICAgICBsZXQgdGFyZ2V0WCwgdGFyZ2V0WTtcclxuXHJcbiAgICAgICAgc3dpdGNoICh0Ll9hbGlnbkNhbGNUeXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgMTovL+WNleihjEhPUklaT05UQUzvvIhMRUZUX1RPX1JJR0hU77yJ44CB572R5qC8VkVSVElDQUzvvIhMRUZUX1RPX1JJR0hU77yJXHJcbiAgICAgICAgICAgICAgICB0YXJnZXRYID0gcG9zLmxlZnQ7XHJcbiAgICAgICAgICAgICAgICBpZiAob2Zmc2V0ICE9IG51bGwpXHJcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0WCAtPSB0Lm5vZGUud2lkdGggKiBvZmZzZXQ7XHJcbiAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0WCAtPSB0Ll9sZWZ0R2FwO1xyXG4gICAgICAgICAgICAgICAgcG9zID0gbmV3IGNjLnYyKHRhcmdldFgsIDApO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgMjovL+WNleihjEhPUklaT05UQUzvvIhSSUdIVF9UT19MRUZU77yJ44CB572R5qC8VkVSVElDQUzvvIhSSUdIVF9UT19MRUZU77yJXHJcbiAgICAgICAgICAgICAgICB0YXJnZXRYID0gcG9zLnJpZ2h0IC0gdC5ub2RlLndpZHRoO1xyXG4gICAgICAgICAgICAgICAgaWYgKG9mZnNldCAhPSBudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldFggKz0gdC5ub2RlLndpZHRoICogb2Zmc2V0O1xyXG4gICAgICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldFggKz0gdC5fcmlnaHRHYXA7XHJcbiAgICAgICAgICAgICAgICBwb3MgPSBuZXcgY2MudjIodGFyZ2V0WCArIHQuY29udGVudC53aWR0aCwgMCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAzOi8v5Y2V5YiXVkVSVElDQUzvvIhUT1BfVE9fQk9UVE9N77yJ44CB572R5qC8SE9SSVpPTlRBTO+8iFRPUF9UT19CT1RUT03vvIlcclxuICAgICAgICAgICAgICAgIHRhcmdldFkgPSBwb3MudG9wO1xyXG4gICAgICAgICAgICAgICAgaWYgKG9mZnNldCAhPSBudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldFkgKz0gdC5ub2RlLmhlaWdodCAqIG9mZnNldDtcclxuICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXRZICs9IHQuX3RvcEdhcDtcclxuICAgICAgICAgICAgICAgIHBvcyA9IG5ldyBjYy52MigwLCAtdGFyZ2V0WSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSA0Oi8v5Y2V5YiXVkVSVElDQUzvvIhCT1RUT01fVE9fVE9Q77yJ44CB572R5qC8SE9SSVpPTlRBTO+8iEJPVFRPTV9UT19UT1DvvIlcclxuICAgICAgICAgICAgICAgIHRhcmdldFkgPSBwb3MuYm90dG9tICsgdC5ub2RlLmhlaWdodDtcclxuICAgICAgICAgICAgICAgIGlmIChvZmZzZXQgIT0gbnVsbClcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXRZIC09IHQubm9kZS5oZWlnaHQgKiBvZmZzZXQ7XHJcbiAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0WSAtPSB0Ll9ib3R0b21HYXA7XHJcbiAgICAgICAgICAgICAgICBwb3MgPSBuZXcgY2MudjIoMCwgLXRhcmdldFkgKyB0LmNvbnRlbnQuaGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgdmlld1BvcyA9IHQuY29udGVudC5nZXRQb3NpdGlvbigpO1xyXG4gICAgICAgIHZpZXdQb3MgPSBNYXRoLmFicyh0Ll9zaXplVHlwZSA/IHZpZXdQb3MueSA6IHZpZXdQb3MueCk7XHJcblxyXG4gICAgICAgIGxldCBjb21wYXJlUG9zID0gdC5fc2l6ZVR5cGUgPyBwb3MueSA6IHBvcy54O1xyXG4gICAgICAgIGxldCBydW5TY3JvbGwgPSBNYXRoLmFicygodC5fc2Nyb2xsUG9zICE9IG51bGwgPyB0Ll9zY3JvbGxQb3MgOiB2aWV3UG9zKSAtIGNvbXBhcmVQb3MpID4gLjU7XHJcbiAgICAgICAgLy8gY2MubG9nKHJ1blNjcm9sbCwgdC5fc2Nyb2xsUG9zLCB2aWV3UG9zLCBjb21wYXJlUG9zKVxyXG5cclxuICAgICAgICB0Ll9zY3JvbGxWaWV3LnN0b3BBdXRvU2Nyb2xsKCk7XHJcblxyXG4gICAgICAgIGlmIChydW5TY3JvbGwpIHtcclxuICAgICAgICAgICAgdC5fc2Nyb2xsUG9zID0gY29tcGFyZVBvcztcclxuICAgICAgICAgICAgdC5fc2Nyb2xsVG9MaXN0SWQgPSBsaXN0SWQ7XHJcbiAgICAgICAgICAgIHQuX3Njcm9sbFRvRW5kVGltZSA9ICgobmV3IERhdGUoKSkuZ2V0VGltZSgpIC8gMTAwMCkgKyB0aW1lSW5TZWNvbmQ7XHJcbiAgICAgICAgICAgIHQuX3Njcm9sbFZpZXcuc2Nyb2xsVG9PZmZzZXQocG9zLCB0aW1lSW5TZWNvbmQpO1xyXG4gICAgICAgICAgICAvLyBjYy5sb2cobGlzdElkLCB0LmNvbnRlbnQud2lkdGgsIHQuY29udGVudC5nZXRQb3NpdGlvbigpLCBwb3MpO1xyXG4gICAgICAgICAgICB0Ll9zY3JvbGxUb1NvID0gdC5zY2hlZHVsZU9uY2UoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCF0Ll9hZGhlcmluZ0JhcnJpZXIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0LmFkaGVyaW5nID0gdC5fYWRoZXJpbmdCYXJyaWVyID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0Ll9zY3JvbGxQb3MgPVxyXG4gICAgICAgICAgICAgICAgICAgIHQuX3Njcm9sbFRvTGlzdElkID1cclxuICAgICAgICAgICAgICAgICAgICB0Ll9zY3JvbGxUb0VuZFRpbWUgPVxyXG4gICAgICAgICAgICAgICAgICAgIHQuX3Njcm9sbFRvU28gPVxyXG4gICAgICAgICAgICAgICAgICAgIG51bGw7XHJcbiAgICAgICAgICAgICAgICAvL2NjLmxvZygnMjIyMjIyMjIyMicsIHQuX2FkaGVyaW5nQmFycmllcilcclxuICAgICAgICAgICAgICAgIGlmIChvdmVyU3RyZXNzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdC5zY3JvbGxUb0xpc3RJZCA9IGxpc3RJZDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaXRlbSA9IHQuZ2V0SXRlbUJ5TGlzdElkKGxpc3RJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5ydW5BY3Rpb24obmV3IGNjLnNlcXVlbmNlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IGNjLnNjYWxlVG8oLjEsIDEuMDUpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IGNjLnNjYWxlVG8oLjEsIDEpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIHRpbWVJblNlY29uZCArIC4xKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aW1lSW5TZWNvbmQgPD0gMCkge1xyXG4gICAgICAgICAgICAgICAgdC5fb25TY3JvbGxpbmcoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOiuoeeul+W9k+WJjea7muWKqOeql+acgOi/keeahEl0ZW1cclxuICAgICAqL1xyXG4gICAgX2NhbGNOZWFyZXN0SXRlbSgpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgdC5uZWFyZXN0TGlzdElkID0gbnVsbDtcclxuICAgICAgICBsZXQgZGF0YSwgY2VudGVyO1xyXG5cclxuICAgICAgICBpZiAodC5fdmlydHVhbClcclxuICAgICAgICAgICAgdC5fY2FsY1ZpZXdQb3MoKTtcclxuXHJcbiAgICAgICAgbGV0IHZUb3AsIHZSaWdodCwgdkJvdHRvbSwgdkxlZnQ7XHJcbiAgICAgICAgdlRvcCA9IHQudmlld1RvcDtcclxuICAgICAgICB2UmlnaHQgPSB0LnZpZXdSaWdodDtcclxuICAgICAgICB2Qm90dG9tID0gdC52aWV3Qm90dG9tO1xyXG4gICAgICAgIHZMZWZ0ID0gdC52aWV3TGVmdDtcclxuXHJcbiAgICAgICAgbGV0IGJyZWFrRm9yID0gZmFsc2U7XHJcbiAgICAgICAgZm9yIChsZXQgbiA9IDA7IG4gPCB0LmNvbnRlbnQuY2hpbGRyZW5Db3VudCAmJiAhYnJlYWtGb3I7IG4gKz0gdC5fY29sTGluZU51bSkge1xyXG4gICAgICAgICAgICBkYXRhID0gdGhpcy5fdmlydHVhbCA/IHRoaXMuZGlzcGxheURhdGFbbl0gOiB0aGlzLl9jYWxjRXhpc3RJdGVtUG9zKG4pO1xyXG4gICAgICAgICAgICBjZW50ZXIgPSB0aGlzLl9zaXplVHlwZSA/ICgoZGF0YS50b3AgKyBkYXRhLmJvdHRvbSkgLyAyKSA6IChjZW50ZXIgPSAoZGF0YS5sZWZ0ICsgZGF0YS5yaWdodCkgLyAyKTtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLl9hbGlnbkNhbGNUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6Ly/ljZXooYxIT1JJWk9OVEFM77yITEVGVF9UT19SSUdIVO+8ieOAgee9keagvFZFUlRJQ0FM77yITEVGVF9UT19SSUdIVO+8iVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLnJpZ2h0ID49IHZMZWZ0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmVhcmVzdExpc3RJZCA9IGRhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2TGVmdCA+IGNlbnRlcilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmVhcmVzdExpc3RJZCArPSB0aGlzLl9jb2xMaW5lTnVtO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVha0ZvciA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iFJJR0hUX1RPX0xFRlTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iFJJR0hUX1RPX0xFRlTvvIlcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5sZWZ0IDw9IHZSaWdodCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5lYXJlc3RMaXN0SWQgPSBkYXRhLmlkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodlJpZ2h0IDwgY2VudGVyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uZWFyZXN0TGlzdElkICs9IHRoaXMuX2NvbExpbmVOdW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrRm9yID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6Ly/ljZXliJdWRVJUSUNBTO+8iFRPUF9UT19CT1RUT03vvInjgIHnvZHmoLxIT1JJWk9OVEFM77yIVE9QX1RPX0JPVFRPTe+8iVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLmJvdHRvbSA8PSB2VG9wKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmVhcmVzdExpc3RJZCA9IGRhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2VG9wIDwgY2VudGVyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uZWFyZXN0TGlzdElkICs9IHRoaXMuX2NvbExpbmVOdW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrRm9yID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6Ly/ljZXliJdWRVJUSUNBTO+8iEJPVFRPTV9UT19UT1DvvInjgIHnvZHmoLxIT1JJWk9OVEFM77yIQk9UVE9NX1RPX1RPUO+8iVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLnRvcCA+PSB2Qm90dG9tKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmVhcmVzdExpc3RJZCA9IGRhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2Qm90dG9tID4gY2VudGVyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uZWFyZXN0TGlzdElkICs9IHRoaXMuX2NvbExpbmVOdW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrRm9yID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy/liKTmlq3mnIDlkI7kuIDkuKpJdGVt44CC44CC44CC77yI5ZOO77yM6L+Z5Lqb5Yik5pat55yf5b+D5oG25b+D77yM5Yik5pat5LqG5YmN6Z2i55qE6L+Y6KaB5Yik5pat5pyA5ZCO5LiA5Liq44CC44CC44CC5LiA5byA5aeL5ZGi77yM5bCx5Y+q5pyJ5LiA5Liq5biD5bGA77yI5Y2V5YiX5biD5bGA77yJ77yM6YKj5pe25YCZ5Luj56CB5omN5LiJ55m+6KGM77yM5ZCO5p2l5bCx5oOz552A5a6M5ZaE5ZWK77yM6Im5Li7ov5nlnZHnnJ/mt7HvvIznjrDlnKjov5nooYzmlbDpg73kuIDljYPkupTkuoY9ID18fO+8iVxyXG4gICAgICAgIGRhdGEgPSB0aGlzLl92aXJ0dWFsID8gdGhpcy5kaXNwbGF5RGF0YVt0aGlzLmRpc3BsYXlJdGVtTnVtIC0gMV0gOiB0aGlzLl9jYWxjRXhpc3RJdGVtUG9zKHRoaXMuX251bUl0ZW1zIC0gMSk7XHJcbiAgICAgICAgaWYgKGRhdGEgJiYgZGF0YS5pZCA9PSB0Ll9udW1JdGVtcyAtIDEpIHtcclxuICAgICAgICAgICAgY2VudGVyID0gdC5fc2l6ZVR5cGUgPyAoKGRhdGEudG9wICsgZGF0YS5ib3R0b20pIC8gMikgOiAoY2VudGVyID0gKGRhdGEubGVmdCArIGRhdGEucmlnaHQpIC8gMik7XHJcbiAgICAgICAgICAgIHN3aXRjaCAodC5fYWxpZ25DYWxjVHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iExFRlRfVE9fUklHSFTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iExFRlRfVE9fUklHSFTvvIlcclxuICAgICAgICAgICAgICAgICAgICBpZiAodlJpZ2h0ID4gY2VudGVyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Lm5lYXJlc3RMaXN0SWQgPSBkYXRhLmlkO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOi8v5Y2V6KGMSE9SSVpPTlRBTO+8iFJJR0hUX1RPX0xFRlTvvInjgIHnvZHmoLxWRVJUSUNBTO+8iFJJR0hUX1RPX0xFRlTvvIlcclxuICAgICAgICAgICAgICAgICAgICBpZiAodkxlZnQgPCBjZW50ZXIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQubmVhcmVzdExpc3RJZCA9IGRhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6Ly/ljZXliJdWRVJUSUNBTO+8iFRPUF9UT19CT1RUT03vvInjgIHnvZHmoLxIT1JJWk9OVEFM77yIVE9QX1RPX0JPVFRPTe+8iVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh2Qm90dG9tIDwgY2VudGVyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0Lm5lYXJlc3RMaXN0SWQgPSBkYXRhLmlkO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0Oi8v5Y2V5YiXVkVSVElDQUzvvIhCT1RUT01fVE9fVE9Q77yJ44CB572R5qC8SE9SSVpPTlRBTO+8iEJPVFRPTV9UT19UT1DvvIlcclxuICAgICAgICAgICAgICAgICAgICBpZiAodlRvcCA+IGNlbnRlcilcclxuICAgICAgICAgICAgICAgICAgICAgICAgdC5uZWFyZXN0TGlzdElkID0gZGF0YS5pZDtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBjYy5sb2coJ3QubmVhcmVzdExpc3RJZCA9JywgdC5uZWFyZXN0TGlzdElkKTtcclxuICAgIH0sXHJcbiAgICAvL+S4iuS4gOmhtVxyXG4gICAgcHJlUGFnZSh0aW1lSW5TZWNvbmQpIHtcclxuICAgICAgICAvLyBjYy5sb2coJ/CfkYgnKTtcclxuICAgICAgICBpZiAoIXRoaXMuY2hlY2tJbml0ZWQoKSlcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aW1lSW5TZWNvbmQgPT0gbnVsbClcclxuICAgICAgICAgICAgdGltZUluU2Vjb25kID0gLjU7XHJcbiAgICAgICAgdGhpcy5za2lwUGFnZSh0aGlzLmN1clBhZ2VOdW0gLSAxLCB0aW1lSW5TZWNvbmQpO1xyXG4gICAgfSxcclxuICAgIC8v5LiL5LiA6aG1XHJcbiAgICBuZXh0UGFnZSh0aW1lSW5TZWNvbmQpIHtcclxuICAgICAgICAvLyBjYy5sb2coJ/CfkYknKTtcclxuICAgICAgICBpZiAoIXRoaXMuY2hlY2tJbml0ZWQoKSlcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aW1lSW5TZWNvbmQgPT0gbnVsbClcclxuICAgICAgICAgICAgdGltZUluU2Vjb25kID0gLjU7XHJcbiAgICAgICAgdGhpcy5za2lwUGFnZSh0aGlzLmN1clBhZ2VOdW0gKyAxLCB0aW1lSW5TZWNvbmQpO1xyXG4gICAgfSxcclxuICAgIC8v6Lez6L2s5Yiw56ys5Yeg6aG1XHJcbiAgICBza2lwUGFnZShwYWdlTnVtLCB0aW1lSW5TZWNvbmQpIHtcclxuICAgICAgICBsZXQgdCA9IHRoaXM7XHJcbiAgICAgICAgaWYgKCF0LmNoZWNrSW5pdGVkKCkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBpZiAodC5fc2xpZGVNb2RlICE9IFNsaWRlVHlwZS5QQUdFKVxyXG4gICAgICAgICAgICByZXR1cm4gY2MuZXJyb3IoJ1RoaXMgZnVuY3Rpb24gaXMgbm90IGFsbG93ZWQgdG8gYmUgY2FsbGVkLCBNdXN0IFNsaWRlTW9kZSA9IFBBR0UhJyk7XHJcbiAgICAgICAgaWYgKHBhZ2VOdW0gPCAwIHx8IHBhZ2VOdW0gPj0gdC5fbnVtSXRlbXMpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBpZiAodC5jdXJQYWdlTnVtID09IHBhZ2VOdW0pXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAvLyBjYy5sb2cocGFnZU51bSk7XHJcbiAgICAgICAgdC5jdXJQYWdlTnVtID0gcGFnZU51bTtcclxuICAgICAgICBpZiAodC5wYWdlQ2hhbmdlRXZlbnQpIHtcclxuICAgICAgICAgICAgY2MuQ29tcG9uZW50LkV2ZW50SGFuZGxlci5lbWl0RXZlbnRzKFt0LnBhZ2VDaGFuZ2VFdmVudF0sIHBhZ2VOdW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0LnNjcm9sbFRvKHBhZ2VOdW0sIHRpbWVJblNlY29uZCk7XHJcbiAgICB9LFxyXG4gICAgLy/orqHnrpcgQ3VzdG9tU2l6Ze+8iOi/meS4quWHveaVsOi/mOaYr+S/neeVmeWQp++8jOafkOS6m+e9leingeeahOaDheWGteeahOehrui/mOaYr+mcgOimgeaJi+WKqOiuoeeul2N1c3RvbVNpemXnmoTvvIlcclxuICAgIGNhbGNDdXN0b21TaXplKG51bUl0ZW1zKSB7XHJcbiAgICAgICAgbGV0IHQgPSB0aGlzO1xyXG4gICAgICAgIGlmICghdC5jaGVja0luaXRlZCgpKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgaWYgKCF0Ll9pdGVtVG1wKVxyXG4gICAgICAgICAgICByZXR1cm4gY2MuZXJyb3IoJ1Vuc2V0IHRlbXBsYXRlIGl0ZW0hJyk7XHJcbiAgICAgICAgaWYgKCF0LnJlbmRlckV2ZW50KVxyXG4gICAgICAgICAgICByZXR1cm4gY2MuZXJyb3IoJ1Vuc2V0IFJlbmRlci1FdmVudCEnKTtcclxuICAgICAgICB0Ll9jdXN0b21TaXplID0ge307XHJcbiAgICAgICAgbGV0IHRlbXAgPSBjYy5pbnN0YW50aWF0ZSh0Ll9pdGVtVG1wKTtcclxuICAgICAgICB0LmNvbnRlbnQuYWRkQ2hpbGQodGVtcCk7XHJcbiAgICAgICAgZm9yIChsZXQgbiA9IDA7IG4gPCBudW1JdGVtczsgbisrKSB7XHJcbiAgICAgICAgICAgIGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIuZW1pdEV2ZW50cyhbdC5yZW5kZXJFdmVudF0sIHRlbXAsIG4pO1xyXG4gICAgICAgICAgICBpZiAodGVtcC5oZWlnaHQgIT0gdC5faXRlbVNpemUuaGVpZ2h0IHx8IHRlbXAud2lkdGggIT0gdC5faXRlbVNpemUud2lkdGgpIHtcclxuICAgICAgICAgICAgICAgIHQuX2N1c3RvbVNpemVbbl0gPSB0Ll9zaXplVHlwZSA/IHRlbXAuaGVpZ2h0IDogdGVtcC53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIU9iamVjdC5rZXlzKHQuX2N1c3RvbVNpemUpLmxlbmd0aClcclxuICAgICAgICAgICAgdC5fY3VzdG9tU2l6ZSA9IG51bGw7XHJcbiAgICAgICAgdGVtcC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgaWYgKHRlbXAuZGVzdHJveSlcclxuICAgICAgICAgICAgdGVtcC5kZXN0cm95KCk7XHJcbiAgICAgICAgcmV0dXJuIHQuX2N1c3RvbVNpemU7XHJcbiAgICB9LFxyXG5cclxufSk7Il19