
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/configManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'cff79PEXYZE7bSATJdY9Bq+', 'configManager');
// Script/configManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PClass = /** @class */ (function () {
    function PClass() {
    }
    return PClass;
}());
;
var leveldata = /** @class */ (function () {
    function leveldata() {
    }
    return leveldata;
}());
var configManager = /** @class */ (function () {
    function configManager(pc) {
    }
    Object.defineProperty(configManager, "instance", {
        get: function () {
            if (!configManager._instance) {
                configManager._instance = new configManager(new PClass());
            }
            return configManager._instance;
        },
        enumerable: true,
        configurable: true
    });
    configManager.prototype.load = function (callback) {
        this.loadConfigReses(function () { window["aa"] = configManager._instance; callback(); });
    };
    configManager.prototype.loadConfigReses = function (successFun) {
        if (successFun === void 0) { successFun = function () { }; }
        var that = this;
        cc.loader.loadResDir("GameData", function (err, jsons, urls) {
            if (err) {
                cc.error(err.message || err);
                return;
            }
            for (var i = 0; i < jsons.length; ++i) {
                var jsonAsset = jsons[i];
                var url = urls[i];
                var name = url.split("/")[1];
                that[name] = jsonAsset.json;
            }
            successFun();
        });
    };
    return configManager;
}());
exports.default = configManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxjb25maWdNYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7SUFBQTtJQUFlLENBQUM7SUFBRCxhQUFDO0FBQUQsQ0FBZixBQUFnQixJQUFBO0FBQUEsQ0FBQztBQUNqQjtJQUFBO0lBS0EsQ0FBQztJQUFELGdCQUFDO0FBQUQsQ0FMQSxBQUtDLElBQUE7QUFDRDtJQVFJLHVCQUFZLEVBQVU7SUFFdEIsQ0FBQztJQVJELHNCQUFrQix5QkFBUTthQUExQjtZQUNJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFO2dCQUMxQixhQUFhLENBQUMsU0FBUyxHQUFHLElBQUksYUFBYSxDQUFDLElBQUksTUFBTSxFQUFFLENBQUMsQ0FBQzthQUM3RDtZQUNELE9BQU8sYUFBYSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxDQUFDOzs7T0FBQTtJQU1NLDRCQUFJLEdBQVgsVUFBWSxRQUFpQjtRQUN6QixJQUFJLENBQUMsZUFBZSxDQUFDLGNBQVcsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQSxDQUFBLENBQUMsQ0FBQyxDQUFBO0lBQ3RGLENBQUM7SUFDTyx1Q0FBZSxHQUF2QixVQUF3QixVQUFzQjtRQUF0QiwyQkFBQSxFQUFBLDJCQUFxQixDQUFDO1FBQzFDLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsVUFBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUk7WUFDOUMsSUFBSSxHQUFHLEVBQUU7Z0JBQ0wsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxDQUFDO2dCQUM3QixPQUFPO2FBQ1Y7WUFDRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDbkMsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN6QixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xCLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDO2FBRS9CO1lBQ0QsVUFBVSxFQUFFLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0wsb0JBQUM7QUFBRCxDQWpDQSxBQWlDQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgUENsYXNzIHsgfTtcclxuY2xhc3MgbGV2ZWxkYXRhe1xyXG4gICAgcHVibGljIGlkOm51bWJlcjtcclxuICAgIHB1YmxpYyBuYW1lOnN0cmluZztcclxuICAgIHB1YmxpYyBwb3NYOm51bWJlcjtcclxuICAgIHB1YmxpYyBwb3NZOm51bWJlcjtcclxufVxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBjb25maWdNYW5hZ2VyIHtcclxuICAgIHByaXZhdGUgc3RhdGljIF9pbnN0YW5jZTogY29uZmlnTWFuYWdlcjtcclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0IGluc3RhbmNlKCk6IGNvbmZpZ01hbmFnZXIge1xyXG4gICAgICAgIGlmICghY29uZmlnTWFuYWdlci5faW5zdGFuY2UpIHtcclxuICAgICAgICAgICAgY29uZmlnTWFuYWdlci5faW5zdGFuY2UgPSBuZXcgY29uZmlnTWFuYWdlcihuZXcgUENsYXNzKCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gY29uZmlnTWFuYWdlci5faW5zdGFuY2U7XHJcbiAgICB9XHJcbiAgICBjb25zdHJ1Y3RvcihwYzogUENsYXNzKSB7XHJcbiAgICAgICBcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIGxvYWQoY2FsbGJhY2s6RnVuY3Rpb24pOnZvaWR7XHJcbiAgICAgICAgdGhpcy5sb2FkQ29uZmlnUmVzZXMoZnVuY3Rpb24oKXt3aW5kb3dbXCJhYVwiXT1jb25maWdNYW5hZ2VyLl9pbnN0YW5jZTsgY2FsbGJhY2soKX0pXHJcbiAgICB9XHJcbiAgICBwcml2YXRlIGxvYWRDb25maWdSZXNlcyhzdWNjZXNzRnVuID0gKCkgPT4geyB9KSB7XHJcbiAgICAgICAgdmFyIHRoYXQgPSB0aGlzO1xyXG4gICAgICAgIGNjLmxvYWRlci5sb2FkUmVzRGlyKFwiR2FtZURhdGFcIiwgKGVyciwganNvbnMsIHVybHMpID0+IHtcclxuICAgICAgICAgICAgaWYgKGVycikge1xyXG4gICAgICAgICAgICAgICAgY2MuZXJyb3IoZXJyLm1lc3NhZ2UgfHwgZXJyKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGpzb25zLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQganNvbkFzc2V0ID0ganNvbnNbaV07XHJcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gdXJsc1tpXTtcclxuICAgICAgICAgICAgICAgIGxldCBuYW1lID0gdXJsLnNwbGl0KFwiL1wiKVsxXTtcclxuICAgICAgICAgICAgICAgIHRoYXRbbmFtZV0gPSBqc29uQXNzZXQuanNvbjtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHN1Y2Nlc3NGdW4oKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufSJdfQ==