
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Event/EventSetting.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '462d3puY3lC74e8bV91PuGR', 'EventSetting');
// Script/Event/EventSetting.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EventMode;
(function (EventMode) {
    var EventSetting = /** @class */ (function () {
        function EventSetting() {
            this._initNum = 1;
            this._initString = "abc";
            console.log(this._initString);
        }
        return EventSetting;
    }());
    EventMode.EventSetting = EventSetting;
})(EventMode = exports.EventMode || (exports.EventMode = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxFdmVudFxcRXZlbnRTZXR0aW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBYyxTQUFTLENBUXRCO0FBUkQsV0FBYyxTQUFTO0lBQ25CO1FBR0k7WUFGUSxhQUFRLEdBQVUsQ0FBQyxDQUFDO1lBQ3JCLGdCQUFXLEdBQVMsS0FBSyxDQUFDO1lBRTdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2xDLENBQUM7UUFDTCxtQkFBQztJQUFELENBTkEsQUFNQyxJQUFBO0lBTlksc0JBQVksZUFNeEIsQ0FBQTtBQUNMLENBQUMsRUFSYSxTQUFTLEdBQVQsaUJBQVMsS0FBVCxpQkFBUyxRQVF0QiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBtb2R1bGUgRXZlbnRNb2Rle1xyXG4gICAgZXhwb3J0IGNsYXNzIEV2ZW50U2V0dGluZ3tcclxuICAgICAgICBwcml2YXRlIF9pbml0TnVtOm51bWJlciA9IDE7XHJcbiAgICAgICAgcHVibGljIF9pbml0U3RyaW5nOnN0cmluZyA9XCJhYmNcIjtcclxuICAgICAgICBjb25zdHJ1Y3Rvcigpe1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLl9pbml0U3RyaW5nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19